package hillbillies.model.factory.subclassesStatement;

import be.kuleuven.cs.som.annotate.Immutable;
import hillbillies.model.Unit;
import hillbillies.model.factory.Expression;
import hillbillies.model.factory.Statement;
import hillbillies.model.factory.subclassesExpression.positionExpression.BoulderPosition;
import hillbillies.model.factory.subclassesExpression.positionExpression.HerePosition;
import hillbillies.model.factory.subclassesExpression.positionExpression.LiteralPosition;
import hillbillies.model.factory.subclassesExpression.positionExpression.LogPosition;
import hillbillies.part3.programs.SourceLocation;
import ogp.framework.util.ModelException;

public class Work extends Statement {

	private Expression<int[]> position;

	public Work(Expression<int[]> position, SourceLocation sourceLocation) {
		super(sourceLocation);
		this.position = position;
	}

	@Immutable
	public Expression<int[]> getPosition(){
		return this.position;
	}
	
	@Override
	public void execute(Unit unit) {
			int[] integerPosition = new int[3];
			integerPosition = (int[])(this.position).execute(unit);
			unit.workAt(integerPosition[0], integerPosition[1], integerPosition[2]);
	}

	@Override
	public Statement getNext(Unit unit) {
		return null;
	}

}
