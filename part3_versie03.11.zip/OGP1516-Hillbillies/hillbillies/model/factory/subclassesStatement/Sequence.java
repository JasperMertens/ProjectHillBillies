package hillbillies.model.factory.subclassesStatement;

import java.util.List;
import hillbillies.model.Unit;
import hillbillies.model.UnreachablePositionException;
import hillbillies.model.factory.Statement;
import hillbillies.part3.programs.SourceLocation;

public class Sequence extends Statement {

	private List<Statement> statements;
	private int index = 0;

	public Sequence(List<Statement> statements, SourceLocation sourceLocation) throws IllegalArgumentException {
		super(sourceLocation);
		if (statements.size() == 0)
			throw new IllegalArgumentException();
		this.statements = statements;
	}

	@Override
	public void execute(Unit unit) throws IllegalArgumentException, UnreachablePositionException {
		this.statements.get(this.index).execute(unit);
	}
	
	@Override
	public Statement getNext(Unit unit) {
		if (this.index == (this.statements.size()-1)) {
			this.index = 0;
			return null;
		}
		this.index++;
		return this.statements.get(this.index);
	}
	
}
