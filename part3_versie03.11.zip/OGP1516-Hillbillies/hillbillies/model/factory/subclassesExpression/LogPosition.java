package hillbillies.model.factory.subclassesExpression;

import hillbillies.model.Log;
import hillbillies.model.Unit;
import hillbillies.model.factory.Expression;
import hillbillies.part3.programs.SourceLocation;

public class LogPosition extends Expression<int[], Unit> {

	public LogPosition(SourceLocation sourceLocation) {
		super(sourceLocation);
	}
	
	@Override
	public int[] execute(Unit unit) {
		Unit.NearestResource<Log> nearestResource = unit.new NearestResource<>();
		Log log = new Log(null);
		return nearestResource.getNearestResource(log).getCurrentCubeCoordinate();
	}
}
