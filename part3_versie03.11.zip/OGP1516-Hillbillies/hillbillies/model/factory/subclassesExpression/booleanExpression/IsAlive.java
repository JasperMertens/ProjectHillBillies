package hillbillies.model.factory.subclassesExpression.booleanExpression;

import hillbillies.model.Unit;
import hillbillies.model.factory.Expression;
import hillbillies.part3.programs.SourceLocation;

public class IsAlive extends Expression<Boolean> {

	private Expression<Unit> unitToCheck;

	public IsAlive(Expression<Unit> unit, SourceLocation sourceLocation) {
		super(sourceLocation);
		this.unitToCheck = unit;
	}

	@Override
	public Boolean execute(Unit unit) {
		return this.unitToCheck.execute(unit).isAlive();
	}
}
