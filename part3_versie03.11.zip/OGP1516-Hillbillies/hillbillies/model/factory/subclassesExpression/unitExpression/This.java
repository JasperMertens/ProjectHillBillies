package hillbillies.model.factory.subclassesExpression.unitExpression;

import hillbillies.model.Unit;
import hillbillies.model.factory.Expression;
import hillbillies.part3.programs.SourceLocation;

public class This extends Expression<Unit> {

	public This(SourceLocation sourceLocation) {
		super(sourceLocation);
	}

	@Override
	public Unit execute(Unit unit) {
		return unit;
	}

}
