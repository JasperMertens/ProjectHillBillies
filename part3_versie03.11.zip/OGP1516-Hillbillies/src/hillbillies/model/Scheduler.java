package hillbillies.model;

import java.util.Collection;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.function.Predicate;
import java.util.stream.Collectors;



public class Scheduler {

//	TODO general method to check if all tasks satisfy some condition
//	method to give task to specific unit

	private List<Task> taskList = new LinkedList<>();
	private Faction faction; 
	
	public Scheduler(Faction faction){
		this.setFaction(faction);
	}
	
	public Faction getFaction() {
		return faction;
	}

	public void setFaction(Faction faction) {
		this.faction = faction;
	}

	public void addTask(Task task) {
		Integer taskPriority = task.getPriority();
		LinkedList<Task> iterateList = new LinkedList<>();
		iterateList.addAll(this.taskList);
		task.addScheduler(this);
		if (iterateList.size() == 0 ){
			taskList.add(task);
			System.out.println("First task added to the list of tasks");
		}
		else {
			for (Task comparingTask : iterateList) {
				if (taskPriority > comparingTask.getPriority()){
					taskList.add(taskList.indexOf(comparingTask), task);
					System.out.println("Inserts a task of equal or higher priority");
				}
				else if (taskList.indexOf(comparingTask) == iterateList.size()-1){
					((LinkedList<Task>) taskList).addLast(task);
					System.out.println("Added a task at the end of the list");
				}
			}
		}
		
	}
	public void addTask(Collection<Task> tasks){
		for (Task task : tasks) {
			this.addTask(task);
		}
	}
	public void removeTask(Task task) {
		taskList.remove(task);
	}
	public void removeTask(Collection<Task> tasks) {
		taskList.removeAll(tasks);
	}

	public void replaceTask(Task originalTask, Task newTask){
		if (!originalTask.isBeingExecuted())
			this.unmarkUnit(originalTask.getUnit());
		this.removeTask(originalTask);
		this.addTask(newTask);
	}
	
	public boolean containsTask(Task givenTask){
		if (taskList.contains(givenTask)){
			return true;
		}
		return false;
	}
	public boolean containsTask(Collection<Task> givenTask){
		if (taskList.containsAll(givenTask)){
			return true;
		}
		return false;
	}
	
	public Task returnHighestPriorityTask() {
		for (Task task : this.taskList){
			if (!task.isBeingExecuted())
				return task;
		}
		return null;
	}
	
	public List<Task> returnAllTasks(){
		return this.taskList; 
	}
	
	public List<Task> returnFilteredTasks(Predicate<Task> predicate) {
		List<Task> allTasks = this.returnAllTasks();
		return allTasks.stream().filter(predicate).collect(Collectors.toList());
	}
	
	private void markUnit(Unit unit, Task task){
		task.setUnit(unit);
		unit.setTaskToDo(task);
	}
	
	public void unmarkUnit(Unit unit){
		Task markedTask = unit.getTaskToDo();
		markedTask.getUnit().standStill();
		markedTask.setUnit(null);
		unit.setTaskToDo(null);
	}
	
	public void giveTask(Unit unit) {
		Task task = this.returnHighestPriorityTask();
		if (task != null) {
			this.markUnit(unit, task);
		}
	}
	
	public Iterator<Task> iterator() {
		return new Iterator<Task>(){

			@Override
			public boolean hasNext() {
				return iteratorIndex < taskList.size()-1;
			}

			@Override
			public Task next() {
				if (!hasNext()){
					this.iteratorIndex = 0;
					throw new NoSuchElementException();
				}
				this.iteratorIndex ++;
				return taskList.get(iteratorIndex-1);
			}
			private Integer iteratorIndex = 0;
		};
	}
}
