package hillbillies.model.factory.subclassesExpression.positionExpression;

import hillbillies.model.Cube;
import hillbillies.model.Unit;
import hillbillies.model.factory.Expression;
import hillbillies.part3.programs.SourceLocation;

public class BoulderPosition extends Expression<int[]> {

	public BoulderPosition(SourceLocation sourceLocation) {
		super(sourceLocation);
	}
	
	@Override
	public int[] execute(Unit unit) {
		Cube boulderPosition = unit.getWorld().getNearestCubeSatisfying(unit.getVectorPosition(), 
				(Cube c) -> c.containsBoulder());
		return boulderPosition.getCoordinates();
	}

}
