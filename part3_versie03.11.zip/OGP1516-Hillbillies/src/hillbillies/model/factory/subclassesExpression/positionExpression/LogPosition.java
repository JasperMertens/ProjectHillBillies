package hillbillies.model.factory.subclassesExpression.positionExpression;

import hillbillies.model.Cube;
import hillbillies.model.Unit;
import hillbillies.model.factory.Expression;
import hillbillies.part3.programs.SourceLocation;

public class LogPosition extends Expression<int[]> {

	public LogPosition(SourceLocation sourceLocation) {
		super(sourceLocation);
	}
	
	@Override
	public int[] execute(Unit unit) {
		Cube logPosition = unit.getWorld().getNearestCubeSatisfying(unit.getVectorPosition(), 
				(Cube c) -> c.containsLog());
		return logPosition.getCoordinates();
	}
}
