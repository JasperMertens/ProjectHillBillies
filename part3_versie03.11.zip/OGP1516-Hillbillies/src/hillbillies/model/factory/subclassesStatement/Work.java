package hillbillies.model.factory.subclassesStatement;

import be.kuleuven.cs.som.annotate.Immutable;
import hillbillies.model.Unit;
import hillbillies.model.factory.Expression;
import hillbillies.model.factory.Statement;
import hillbillies.part3.programs.SourceLocation;

public class Work extends Statement {

	private Expression<int[]> position;

	public Work(Expression<int[]> position, SourceLocation sourceLocation) {
		super(sourceLocation);
		this.position = position;
	}

	@Immutable
	public Expression<int[]> getPosition(){
		return this.position;
	}
	
	@Override
	public void execute(Unit unit) {
			int[] integerPosition = new int[3];
			integerPosition = (int[])(this.position).execute(unit);
			unit.workAt(integerPosition[0], integerPosition[1], integerPosition[2]);
	}
	
	@Override
	public String getRead() {
		return this.position.getVariableName();
	}
}
