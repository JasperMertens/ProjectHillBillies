package hillbillies.model.factory.subclassesStatement;

import java.util.Map;

import hillbillies.model.IllegalPositionException;
import hillbillies.model.Unit;
import hillbillies.model.UnreachablePositionException;
import hillbillies.model.factory.Expression;
import hillbillies.model.factory.Statement;
import hillbillies.part3.programs.SourceLocation;

public class IfStatement extends Statement {

	private Expression<Boolean> condition;
	private Statement ifBody;
	private Statement elseBody;

	public IfStatement(Expression<Boolean> condition, Statement ifBody, Statement elseBody, SourceLocation sourceLocation) {
		super(sourceLocation);
		if (ifBody == null)
			throw new IllegalArgumentException();
		this.condition = condition;
		this.ifBody = ifBody;
		this.elseBody = elseBody;
	}

	@Override
	public void execute(Unit unit) throws IllegalArgumentException, IllegalPositionException, UnreachablePositionException {
		if (condition.execute(unit))
			this.ifBody.execute(unit);
		else if (condition.execute(unit) && this.elseBody !=null)
			this.elseBody.execute(unit);
	}

	@Override
	public Statement getNext(Unit unit) {
		Statement result = null;
		if (condition.execute(unit))
			result = this.ifBody.getNext(unit);
		else if (this.elseBody != null)
			result = this.elseBody.getNext(unit);
		return result;
	}

	@Override
	public boolean containsBreakOutOfLoop() {
		if (this.elseBody != null)
			return (this.ifBody.containsBreakOutOfLoop() ||  this.elseBody.containsBreakOutOfLoop());
		return this.ifBody.containsBreakOutOfLoop();
	}
	
	@Override
	public boolean containsInvalidRead(Map<String, Integer> assignMap) {
		if (this.elseBody != null)
			return (this.ifBody.containsInvalidRead(assignMap) || this.elseBody.containsInvalidRead(assignMap));
		return this.ifBody.containsInvalidRead(assignMap);
	}
	
	@Override
	public String getRead() {
		return this.condition.getVariableName();
	}

}
