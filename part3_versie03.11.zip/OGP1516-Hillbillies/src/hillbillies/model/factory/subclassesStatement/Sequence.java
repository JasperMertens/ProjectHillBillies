package hillbillies.model.factory.subclassesStatement;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import hillbillies.model.Unit;
import hillbillies.model.UnreachablePositionException;
import hillbillies.model.factory.Statement;
import hillbillies.part3.programs.SourceLocation;

public class Sequence extends Statement {

	private List<Statement> statements;
	private int index = 0;
	private int size;

	public Sequence(List<Statement> statements, SourceLocation sourceLocation) throws IllegalArgumentException {
		super(sourceLocation);
		this.size = statements.size();
		this.statements = statements;
	}
	
	@Override
	public int size(){
		return this.size;
	}
	
	@Override
	public void execute(Unit unit) throws IllegalArgumentException, UnreachablePositionException, IllegalStateException {
		if (this.size()==0)
			throw new IllegalStateException();
		this.statements.get(this.index).execute(unit);
		if (this.index == (this.statements.size()-1)) {
			this.index = 0;
		}
		this.index++;
	}
	
	@Override
	public Statement getNext(Unit unit) {
		if (this.index == (this.statements.size()))
			return null;
		else if (this.statements.get(this.index).getNext(unit) != null)
			return this.statements.get(this.index).getNext(unit);
		else
			return this;
	}
	
	@Override
	public boolean containsBreakOutOfLoop() {
		for (Statement statement : this.statements) {
			if (statement.containsBreakOutOfLoop())
				return true;
		}
		return false;
	}
	
	@Override
	public boolean containsInvalidRead(Map<String, Integer> assignMap) {
		Map<String, Integer> readMap = new HashMap<>();
		Map<String, Integer> nextAssignMap = new HashMap<>();
		int i = 0;
		while (i < this.size()) {
			Statement statement = this.statements.get(i);
			if (!assignMap.containsKey(statement.getAssignment())) {
				assignMap.put(statement.getAssignment(), i);
				nextAssignMap.put(statement.getAssignment(), -1);
			}
			if (!readMap.containsKey(statement.getRead()))
				readMap.put(statement.getRead(), i);
			if (statement.containsInvalidRead(nextAssignMap))
				return true;
			i++;
		}
		Iterator<String> iter = readMap.keySet().iterator();
		while (iter.hasNext()) {
			String variableName = (String) iter.next();
			if ((assignMap.isEmpty()) || (readMap.get(variableName) <= assignMap.get(variableName)))
				return true;
		}
		return false;
	}
}
