package hillbillies.model.factory;

public interface IExpression {

	default public String getVariableName(){
		return null;
	}
}
