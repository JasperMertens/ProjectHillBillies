package hillbillies.model;

import static org.junit.Assert.*;

import java.util.function.Predicate;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import hillbillies.part2.facade.Facade;
import hillbillies.part2.listener.DefaultTerrainChangeListener;
import ogp.framework.util.ModelException;

public class WorldTest {
	
	private Facade facade;

	private static final int TYPE_AIR = 0;
	private static final int TYPE_ROCK = 1;
	private static final int TYPE_TREE = 2;
	private static final int TYPE_WORKSHOP = 3;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		this.facade = new Facade();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testGetNearestWorkshop() throws ModelException {
		int[][][] types = new int[3][3][3];
		types[1][1][0] = TYPE_ROCK;
		types[1][1][1] = TYPE_TREE;
		types[1][1][1] = TYPE_WORKSHOP;
		types[1][2][1] = TYPE_WORKSHOP;
		int[] workshopCoordinates = new int[]{1,1,1};

		World world = facade.createWorld(types, new DefaultTerrainChangeListener());
		Vector vector = new Vector(0,0,0);
		Cube nearestWorkshop = world.getNearestCubeSatisfying(vector, 
				new Predicate<Cube>() {
			 @Override
			    public boolean test(Cube c) {
			        return c.getTerrainType() == TYPE_WORKSHOP;
			    }
		});
		assertArrayEquals(nearestWorkshop.getCoordinates(), workshopCoordinates);
	}

}
