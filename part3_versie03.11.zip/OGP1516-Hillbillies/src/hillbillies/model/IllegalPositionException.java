package hillbillies.model;

import be.kuleuven.cs.som.annotate.Basic;
import be.kuleuven.cs.som.annotate.Immutable;

/**
 * A class for signaling illegal positions for a Unit.
 * 
 * @author Jasper, Zeno
 * @version 1.0
 *
 */

public class IllegalPositionException extends RuntimeException {
	public IllegalPositionException(Vector position, World world) {
		this.position = position;
		this.world = world;
	}

	/**
	 * Return the position registered for this illegal position exception
	 * 
	 * @return
	 */
	@Basic
	@Immutable
	public Vector getPosition() {
		return this.position;
	}

	/**
	 * Variable registering the position involved in this illegal position
	 * exception
	 */
	private final Vector position;
	
	/**
	 * Return the world registered for this illegal position exception
	 * 
	 * @return
	 */
	@Basic
	@Immutable
	public World getWorld() {
		return this.world;
	}

	/**
	 * Variable registering the world involved in this illegal position
	 * exception
	 */
	private final World world;
	

	/**
	 * This aspect is of no concern to us, but Java requires it.
	 */
	private static final long serialVersionUID = 2003001L;

}
