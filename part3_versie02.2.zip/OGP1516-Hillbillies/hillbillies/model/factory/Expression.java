package hillbillies.model.factory;

public abstract class Expression {
	
}
