package hillbillies.model.factory.subclassesExpression;

import be.kuleuven.cs.som.annotate.*;
import hillbillies.model.factory.Expression;

public class Value extends Expression {

	private Object value;
	
	public Value(Object value){
		this.value = value;
	}
	
	@Immutable
	public Object getValue() {
		return value;
	}
}
