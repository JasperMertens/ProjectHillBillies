package hillbillies.model;

import java.util.Collection;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.NoSuchElementException;



public class Scheduler {

//	TODO general method to check if all tasks satisfy some condition
//	method to give task to specific unit

	private LinkedList<Task> taskList = new LinkedList<>();
	private Faction faction; 
	
	public Scheduler(Faction faction){
		this.setFaction(faction);
	}
	
	public Faction getFaction() {
		return faction;
	}

	public void setFaction(Faction faction) {
		this.faction = faction;
	}

	public void addTask(Task task) {
		Integer taskPriority = task.getPriority();
		for (Task comparingTask : taskList) {
			if (taskPriority >= comparingTask.getPriority()){
				taskList.add(taskList.indexOf(comparingTask), task);	
			}
			else if (taskList.indexOf(comparingTask) == taskList.size()-1)
				taskList.addLast(task);
		}
		
		taskList.add(task);
	}
	public void addTask(Collection<Task> tasks){
		for (Task task : tasks) {
			this.addTask(task);
		}
	}
	public void removeTask(Task task) {
		taskList.remove(task);
	}
	public void removeTask(Collection<Task> tasks) {
		taskList.removeAll(tasks);
	}

	public void replaceTask(Task originalTask, Task newTask){
		this.removeTask(originalTask);
		this.addTask(newTask);
	}
	
	public boolean containsTask(Task givenTask){
		if (taskList.contains(givenTask)){
			return true;
		}
		return false;
	}
	public boolean containsTask(Collection<Task> givenTask){
		if (taskList.containsAll(givenTask)){
			return true;
		}
		return false;
	}
	
	public Task returnHighestPriorityTask() throws IllegalStateException{
		if (taskList.isEmpty())
			throw new IllegalStateException();
		return taskList.getFirst();
	}
	
	public LinkedList<Task> returnAllTasks(){
		return taskList; 
	}
	
	public void markUnit(Unit unit, Task task){
		task.setUnit(unit);
		unit.setTaskToDo(task);
	}
	
	public void unmarkUnit(Unit unit){
		Task markedTask = unit.getTaskToDo();
		// if markedTask == null, automatically throws a NullpointerExc)
		markedTask.setUnit(null);
		unit.setTaskToDo(null);
	}
	
	public Iterator<Task> iterator() {
		return new Iterator<Task>(){

			@Override
			public boolean hasNext() {
				return iteratorIndex < taskList.size()-1;
			}

			@Override
			public Task next() {
				if (!hasNext())
					throw new NoSuchElementException();
				this.iteratorIndex ++;
				return taskList.get(iteratorIndex-1);
			}
			private Integer iteratorIndex = 0;
		};
	}
}
