package hillbillies.model.factory.subclassesExpression;

import hillbillies.model.factory.Expression;
import hillbillies.part3.programs.SourceLocation;

public class LiteralPosition extends Expression {

	private int[] position;

	public LiteralPosition(int x, int y, int z, SourceLocation sourceLocation) {
		super(sourceLocation);
		this.position = new int[]{x,y,z};
	}

	@Override
	public int[] execute() {
		return this.position;
	}

}
