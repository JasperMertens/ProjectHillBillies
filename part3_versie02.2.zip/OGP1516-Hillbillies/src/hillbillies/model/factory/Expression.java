package hillbillies.model.factory;

import hillbillies.part3.programs.SourceLocation;

public abstract class Expression {
	
	private SourceLocation sourceLocation;
	
	protected Expression(SourceLocation sourceLocation) {
		this.sourceLocation = sourceLocation;
	}

	public SourceLocation getSourceLocation() {
		return this.sourceLocation;
	}
	
	public void setSourceLocation(SourceLocation sourceLocation) {
		this.sourceLocation = sourceLocation;
	}
	
	// TODO generic maken
	public abstract Object execute();
}
