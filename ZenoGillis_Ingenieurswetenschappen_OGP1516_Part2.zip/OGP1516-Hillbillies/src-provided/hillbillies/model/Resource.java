package hillbillies.model;

import java.util.Random;

/**
 * A class of Resources, with given position and World where they exist.
 * 
 * @version 1.0
 * @author Zeno Gillis, Jasper Mertens
 */
public abstract class Resource extends WorldObject{

	protected Resource(Vector position) {
		super(position);
		this.setRandomWeight();
	}

	private void setRandomWeight() {
		Random rand = new Random();
		int randomWeight = rand.nextInt(41) + 10;
		this.weight = randomWeight;
	}
	
	@Override
	public boolean canHaveAsPosition(Vector position, World world) {
		Cube cube = world.getCube(position.getRoundDown());
		return super.canHaveAsPosition(position, world) && world.isAboveSolidGround(cube);
	}

	@Override
	protected boolean canFall() {
		Cube currentCube = this.world.getCube(this.getCurrentCubeCoordinate());
		if (this.world.isAboveSolidGround(currentCube))
			return false;
		return true;
	}

}
