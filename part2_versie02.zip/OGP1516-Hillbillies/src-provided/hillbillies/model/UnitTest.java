package hillbillies.model;

import static org.junit.Assert.*;

import org.junit.*;

public class UnitTest {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public final void moveToAdjacent_LegalCase(){
		int[] position = new int[]{1,0,0};
		Unit unit = new Unit("Jos", position, 30, 30, 30, 30, false);
		unit.moveToAdjacent(1, 0, 0);
		Vector other = new Vector(2.5,0.5,0.5);
		for (int i = 0; i < 10; i++) {
			unit.advanceTime(0.2);
		}
		System.out.println(unit.getVectorPosition().getX());
		System.out.println(unit.getVectorPosition().getY());
		System.out.println(unit.getVectorPosition().getZ());
		Boolean bool = unit.getVectorPosition().isIdenticalTo(other);
		assertTrue(bool == true);
	}

}
