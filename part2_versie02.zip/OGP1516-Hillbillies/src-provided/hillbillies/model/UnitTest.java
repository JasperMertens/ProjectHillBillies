package hillbillies.model;

import static org.junit.Assert.*;

import org.junit.*;

import hillbillies.part2.facade.Facade;
import hillbillies.part2.facade.IFacade;
import ogp.framework.util.ModelException;


import hillbillies.model.Unit;
import hillbillies.model.World;
import hillbillies.part2.listener.DefaultTerrainChangeListener;


public class UnitTest {
	
	private Facade facade;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}


	@Before
	public void setup() {
		this.facade = new Facade();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public final void moveToAdjacent_LegalCase() throws ModelException{
		int[] position = new int[]{1,0,0};
		IFacade facade = new Facade();
		int nbX = 20;
		int nbY = 20;
		int nbZ = 30;

		World world = facade.createWorld(new int[nbX][nbY][nbZ], new DefaultTerrainChangeListener());
		Unit unit = new Unit("Jos", position, 30, 30, 30, 30, false);
		facade.addUnit(unit, world);
		unit.moveToAdjacent(1, 0, 0);
		Vector other = new Vector(2.5,0.5,0.5);
		for (int i = 0; i < 10; i++) {
			unit.advanceTime(0.2);
		}
		Boolean bool = unit.getVectorPosition().isIdenticalTo(other);
		assertTrue(bool == true);
	}
	
	@Test(expected=ModelException.class)
	public void testUnitName_NameTooShort() throws ModelException {
		facade.createUnit("E", new int[] { 1, 1, 1 }, 50, 50, 50, 50, false);
	}
	
	@Test(expected=ModelException.class)
	public void testUnitName_NameDoesntStartWithCapital() throws ModelException {
		facade.createUnit("hillbilly", new int[] { 1, 1, 1 }, 50, 50, 50, 50, false);
	}
	
	@Test(expected=ModelException.class)
	public void testUnitName_NameDoesntStartWithCapital_AndIsShort() throws ModelException {
		facade.createUnit("h", new int[] { 1, 1, 1 }, 50, 50, 50, 50, false);
	}
	
	@Test
	public void testSetValidName() throws ModelException {
		Unit unit = facade.createUnit("TestUnit", new int[] { 1, 1, 1 }, 50, 50, 50, 50, false);
		facade.setName(unit, "James O'Hare");
		assertEquals("This should be a valid name", "James O'Hare", facade.getName(unit));
	}
	
	@Test(expected=ModelException.class)
	public void testSetInValidName() throws ModelException {
		Unit unit = facade.createUnit("TestUnit", new int[] { 1, 1, 1 }, 50, 50, 50, 50, false);
		facade.setName(unit, "James*O'Hare");
	}

}
