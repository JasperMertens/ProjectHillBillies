package hillbillies.model;

import java.util.ArrayList;

import be.kuleuven.cs.som.annotate.*;

/**
 * A class of Cubes that exist in a World, with a position and a terrain type.
 * 
 * @invar The position and terrain type of each Cube must be a valid
 *          position and terrain type for a Cube in respect to its World.
 *        | World.isValidCube()
 * 
 * @version 1.0
 * @author Zeno Gillis, Jasper Mertens
 *
 */
public class Cube {
	
	/**
	 * Constants for naming the different terrain types.
	 */
	static final int AIR = 0;
	static final int ROCK = 1;
	static final int TREE = 2;
	static final int WORKSHOP = 3;
	
	/**
	 * Constants containing the value of the X-, Y- and Z-coordinates of the Cube respectively.
	 */
	private final int X;
	private final int Y;
	private final int Z;
	
	/**
	 * A constant registering the World in which this Cube exists.
	 */
	private final World world;
	
	/**
	 * A variable registering the type of terrain for this Cube.
	 */
	private int terrainType;
	
	
	/**
	 * Initialize a new Cube with given coordinates and terrain type and the World where it exists.
	 * 
	 * @param world
	 * 			The World in where this Cube exists.
	 * @param x
	 * 			The X-coordinate for this Cube.
	 * @param y
	 * 			The Y-coordinate for this Cube.
	 * @param z
	 * 			The Z-coordinate for this Cube.
	 * @param terrainType
	 * 			The type of terrain for this Cube.
	 * @post   The X-coordinate of this new Cube is equal to
	 *		   the given x.
	 *       | new.X == x;
	 * @post   The Y-coordinate of this new Cube is equal to
	 *		   the given y.
	 *       | new.X == x;
	 * @post   The Z-coordinate of this new Cube is equal to
	 *		   the given z.
	 *       | new.Z == z;
	 * @post   The terrain type of this new Cube is equal to
	 *		   the given terrain type.
	 *       | new.terrainType == terrainType;
	 * @throws NullPointerException
	 * 			The given World is not an effective World.
	 * 			| world == null
	 * @throws IllegalArgumentException
	 * 			The given arguments for a Cube are not valid arguments for a Cube in the given World.
	 * 			| ! world.isValidCube(x, y, z, terrainType)
	 */
	public Cube(World world, int x, int y, int z, int terrainType) 
			throws NullPointerException, IllegalArgumentException {
		if (!world.canHaveAsCube(x, y, z, terrainType))
			throw new IllegalArgumentException();
		this.world = world;
		this.X = x;
		this.Y = y;
		this.Z = z;
		this.setTerrainType(terrainType);
	}
	
	/**
	 * Return the coordinates of this Cube as an array of integers.
	 * @return
	 * 			|result == new int[]{this.X, this.Y, this.Z};
	 */
	@Immutable @Raw
	public int[] getCoordinates() {
		int[] intList = new int[]{this.X, this.Y, this.Z};
		return intList;
	}
	
	@Immutable @Raw
	public Vector getPosition() {
		Vector vectorPosition = new Vector(this.X, this.Y, this.Z);
		return vectorPosition;
	}
	
	/**
	 * Set the terrain type of this Cube to the given terrain type and update the GUI if needed.
	 * 
	 * @param terrainType
	 * 			The new terrain type for this Cube.
	 */
	@Raw
	public void setTerrainType(int terrainType) {
		if (terrainType != this.getTerrainType()) {
			this.world.getModelListener().notifyTerrainChanged(this.X, this.Y, this.Z);
			if (this.isSolid() && !isSolidTerrain(terrainType))
				this.world.getConnectedToBorder().changeSolidToPassable(this.X, this.Y, this.Z);
			else if (!this.isSolid() && isSolidTerrain(terrainType))
				this.world.getConnectedToBorder().changePassableToSolid(this.X, this.Y, this.Z);
			
			this.terrainType = terrainType;
		}
	}
	
	/**
	 * Return the type of terrain for this Cube.
	 * @return
	 */
	@Basic @Raw
	public int getTerrainType() {
		return this.terrainType;
	}
	
	/**
	 * Return whether the given terrain is solid terrain.
	 * 
	 * @param terrain
	 * 		| The terrain to check.
	 * @return	True if and only if the type of terrain is ROCK or TREE.
	 * 		| result == (terrain == ROCK) || (terrain == TREE)
	 */
	public static boolean isSolidTerrain(int terrain) {
		return ((terrain == ROCK) || (terrain == TREE));
	}
	
	/**
	 * Return whether this Cube is solid.
	 * @effect Return true if the terrain type of this Cube is solid.
	 * 		| isSolidTerrain(this.getTerrainType())
	 */
	public boolean isSolid() {
		terrainType = this.getTerrainType();
		return (isSolidTerrain(terrainType));
	}
	
	/**
	 * Return all the neighbouring Cubes of this Cube as an array of Cubes.
	 * 
	 * @return	An array of Cubes, containing all the cubes that exist in the World of this Cube
	 * 			and that neighbour this Cube.
	 * 			| for (other_Cube : all_Cubes) {
	 * 			|	if ((other_Cube.X == this_Cube.X � 1) ||
	 * 			|		(other_Cube.Y == this_Cube.Y � 1) ||
	 * 			|		(other_Cube.Z == this_Cube.Z � 1))
	 * 			|		cubeList.add(other_Cube);
	 * 			| result == cubeList;
	 */
	public ArrayList<Cube> getNeighbouringCubes() {
		ArrayList<Cube> cubeList = new ArrayList<>();
		Vector cubePosition = this.getPosition();
		for (int i=-1; i<2; i++) {
			for (int j=-1; j<2; j++) {
				for (int k=-1; k<2; k++) {
					Vector vectorTerm = new Vector(i, j, k);
					Vector vectorResult = cubePosition.addVector(vectorTerm);
					int[] coordinates = vectorResult.getRoundDown();
					if (this.world.containsCube(coordinates[0],
												coordinates[1],
												coordinates[2])) {
						Cube neighbour = this.world.getCube(coordinates);
						cubeList.add(neighbour);
					}
				}
			}
		}
		return cubeList;
	}
}
