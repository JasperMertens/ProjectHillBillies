package hillbillies.model;

import be.kuleuven.cs.som.annotate.Basic;
import be.kuleuven.cs.som.annotate.Immutable;

/**
 * A class for signaling illegal names for a Unit.
 * 
 * @author Jasper, Zeno
 * @version 1.0
 *
 */
public class IllegalNameException extends RuntimeException {



	public IllegalNameException(String name) {
		this.name = name;

	}

	/**
	 * Return the name registered for this illegal name exception
	 * 
	 * @return
	 */
	// Is dit immutable?
	@Basic
	@Immutable
	public String getName() {
		return this.name;
	}

	/**
	 * Variable registering the name involved in this illegal name
	 * exception
	 */
	// Waarom final?
	private final String name;
	

	/**
	 * This aspect is of no concern to us, but Java requires it.
	 */
	private static final long serialVersionUID = 2003001L;

}
