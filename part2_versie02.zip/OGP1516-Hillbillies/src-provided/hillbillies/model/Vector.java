package hillbillies.model;

import be.kuleuven.cs.som.annotate.*;

/**
 * A class of vectors containing three coordinates: X, Y, Z.
 * 
 * @version 2.0
 * @author Zeno Gillis, Jasper Mertens
 */
public class Vector {

	/**
	 * A variable storing a value for the X dimension.
	 */
	private double X;
	/**
	 * A variable storing a value for the Y dimension.
	 */
	private double Y;
	/**
	 * A variable storing a value for the Z dimension.
	 */
	private double Z;

	/**
	 * Initialize a new Vector with given coordinates: X, Y, Z.
	 * 
	 * @param x
	 *           The X coordinate for this new Vector.
	 * @param y
	 *           The Y coordinate for this new Vector.
	 * @param z
	 *           The Z coordinate for this new Vector.
	 *
	 * @effect The X coordinate of this new Vector is set to
	 *      the given x coordinate.
	 *      | this.setX(x)
	 * @effect The Y coordinate of this new Vector is set to
	 *      the given y coordinate.
	 *      | this.setY(y)
	 * @effect The Z coordinate of this new Vector is set to
	 *      the given x coordinate.
	 *      | this.setZ(z)
	 */
	// Wat als null?
	public Vector(double x, double y, double z) {
		this.setX(x);
		this.setY(y);
		this.setZ(z);
//		System.out.println("constructing" + " " + x + " " + y + " " + z);
	}
	
	/**
	 * Initialize this new Vector with given coordinate list.
	 * 
	 * @param  coordinateList
	 *         The list of floating point coordinates for this new Vector.
	 * @post   The coordinateList of this new Vector is equal to the given
	 *         list of coordinates.
	 *       | new.getCoordinates() == coordinate_list
	 */
	public Vector(double[] coordinateList) {
		this.setX(coordinateList[0]);
		this.setY(coordinateList[1]);
		this.setZ(coordinateList[2]);
	}

	/**
	 * Initialize this new Vector with given coordinate list.
	 * 
	 * @param  coordinateList
	 *         The list of integer coordinates for this new Vector.
	 * @post   The coordinateList of this new Vector is equal to the given
	 *         list of coordinates.
	 *       | new.getCoordinates() == coordinate_list
	 */
	public Vector(int[] coordinateList) {
		this.setX(coordinateList[0]);
		this.setY(coordinateList[1]);
		this.setZ(coordinateList[2]);
	}
	
	/**
	 * Return the coordinates of this Vector as an array of doubles.
	 */
	@Basic @Immutable
	public double[] getCoordinates() {
		double[] coordinateList = new double[]{	this.getX(),
												this.getY(),
												this.getZ()};
		return coordinateList;
	}
	
	/**
	 * Returns the X coordinate of the current Vector.
	 * @return
	 */
	@Basic
	public double getX() {
		return this.X;
	}
	
	/**
	 * Set the X coordinate of the current Vector to the given x coordinate.
	 */
	@Basic
	public void setX(double x) {
	this.X = x;
	}
	
	
	/**
	 * Returns the Y coordinate of the current Vector.
	 * @return
	 */
	@Basic
	public double getY() {
		return this.Y;
	}
	
	/**
	 * Set the Y coordinate of the current Vector to the given y coordinate.
	 */
	@Basic
	public void setY(double y) {
	this.Y = y;
	}
	
	/**
	 * Returns the Z coordinate of the current Vector.
	 * @return
	 */
	@Basic
	public double getZ() {
		return this.Z;
	}
	
	/**
	 * Set the Z coordinate of the current Vector to the given z coordinate.
	 */
	@Basic
	public void setZ(double z) {
	this.Z = z;
	}
	/**
	 * Get a copy of the current Vector.
	 * @param vector
	 * @return A Vector with as its coordinates the coordinates of the current Vector.
	 * 			| result.getX() == this.getX()
	 *  		| result.getY() == this.getY()
	 *  		| result.getZ() == this.getZ()
	 */
	public Vector getCopy(){
		Vector copy = new Vector(this.getX(),this.getY(),this.getZ());
		return copy;
	}
	
	/**
	 * Return a new Vector that is the result of adding the given other Vector
	 *  to the current Vector.
	 * @param other
	 * 			The other Vector to be added to the current Vector.
	 * @return A Vector with as its coordinates: the sum of the coordinates of the
	 * 			current Vector and the other given Vector.
	 * 			| result.getX() == this.getX() + other.getX()
	 *  		| result.getY() == this.getY() + other.getY()
	 *  		| result.getZ() == this.getZ() + other.getZ()
	 * @throws NullPointerException
	 *			The other Vector is not effective.
	 *       	| other == null
	 */
	public Vector addVector(Vector other) throws NullPointerException {
		double added_X = this.getX() + other.getX();
		double added_Y = this.getY() + other.getY();
		double added_Z = this.getZ() + other.getZ();
		Vector newVector = new Vector(added_X, added_Y, added_Z);
		return newVector;
	}
	
	/**
	 * Return a new Vector that is the result of subtracting the given other Vector
	 * 	 from the current Vector.
	 * @param other
	 * 			The other Vector to be subtracted from the current Vector.
	 * @return A Vector with as its coordinates: the difference between the coordinates of the 
	 * 			current Vector and the other given Vector.
	 * 			| result.getX() == this.getX() - other.getX()
	 *  		| result.getY() == this.getY() - other.getY()
	 *  		| result.getZ() == this.getZ() - other.getZ()
	 * @throws NullPointerException
	 *			The other Vector is not effective.
	 *       	| other == null
	 */
	public Vector subtractVector(Vector other) throws NullPointerException {
		double subtracted_X = this.getX() - other.getX();
		double subtracted_Y = this.getY() - other.getY();
		double subtracted_Z = this.getZ() - other.getZ();
		Vector newVector = new Vector(subtracted_X, subtracted_Y, subtracted_Z);
		return newVector;
	}
	
	/**
	 * Returns a list of integers, namely copies of the coordinates of the current Vector rounded down
	 *  towards zero, to the nearest integer.
	 * @return A list of the coordinates of the current Vector casted to integers.
	 * 			| result[0] == (int) this.getX();
	 * 			| result[1] == (int) this.getY();
	 * 			| result[2] == (int) this.getZ();
	 */
	public int[] getRoundDown() {
		int round_X =(int) this.getX();
		int round_Y =(int) this.getY();
		int round_Z =(int) this.getZ();
		int[] intList = new int[]{round_X, round_Y, round_Z};
		return intList;
	}
	
	/**
	 * Return the magnitude of the current Vector.
	 * @return	Returns the square root of the sum of each coordinate to the power of two.
	 * 			| result == sqrt((this.X)�+(this.Y)�+(this.Z)�)
	 */
	public double getMagnitude() {
		double X_squared = Math.pow(this.getX(), 2);
		double Y_squared = Math.pow(this.getY(), 2);
		double Z_squared = Math.pow(this.getZ(), 2);
		double magnitude = Math.sqrt(	X_squared 
										+ Y_squared
										+ Z_squared);
		return magnitude;
	}
	
	/**
	 * Return the current Vector, multiplied by the given factor.
	 * @param factor
	 * 			The given factor to multiply the coordinates of the current Vector with.
	 * @return A Vector with as its coordinates: the coordinates of the current Vector,
	 * 			 multiplied by the given factor.
	 * 			| result.getX() == this.getX()*factor
	 * 			| result.getY() == this.getY()*factor
	 * 			| result.getZ() == this.getZ()*factor
	 */
	public Vector getMultipleVector(double factor){
		double X_multiplied = this.getX()*factor;
		double Y_multiplied = this.getY()*factor;
		double Z_multiplied = this.getZ()*factor;
		Vector multipliedVector = new Vector(X_multiplied, Y_multiplied, Z_multiplied);
		return multipliedVector;
	}
	
	/**
	 * Return if the current Vector has the same coordinates as the other given Vector.
	 * @param other
	 * 			The other Vector to compare with.
	 * @return Returns true if and only if the coordinates of both Vectors are equal, pairwise.
	 * 			| result == ((this.getX() == other.getX()) && (this.getY() == other.getY())
	 * 			|			&& (this.getZ() == other.getZ()))
	 * @throws NullPointerException
	 * 		The other Vector is not effective.
	 *       	| other == null
	 */
	public boolean isIdenticalTo(Vector other) throws NullPointerException{
		if ((this.getX() == other.getX()) && (this.getY() == other.getY())
				&& (this.getZ() == other.getZ())){
			
			return true;
		}
		return false;
		
	}
}
	

