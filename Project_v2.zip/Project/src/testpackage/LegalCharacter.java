package testpackage;
// Waarom mag private niet?
//beeter array
public enum LegalCharacter {
	
	ACCENT("'"), 
	DOUBLE_ACC("\""),
	SPACE(" "),
	LETTER("Character.LOWERCASE_LETTER")
}
