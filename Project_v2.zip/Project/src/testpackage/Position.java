package testpackage;
import be.kuleuven.cs.som.annotate.Basic;
import be.kuleuven.cs.som.annotate.Raw;

/**
 * A class of positions that are identified by three coordinates, namely X, Y and Z.
 * 
 * @author Zeno, Jasper
 * @version 1.0
 */
public class Position {
	
	private double X;
	private double Y;
	private double Z;
	private static int MAX_X = 50;
	private static int MIN_X = 0;
	private static int MAX_Y = 50;
	private static int MIN_Y = 0;
	private static int MAX_Z = 50;
	private static int MIN_Z = 0;
	
	
	
	/**
	 * Initialize new position with given coordinates: X, Y, Z.
	 * @param x
	 * 			...
	 * @param y
	 * 			...
	 * @param z
	 * 			...
	 * @post	...
	 * 			| new.getX() == x
	 * @post	...
	 * 			| new.geY() == y
	 * @post	...
	 * 			| new.getZ() == z
	 * @throws IllegalArgumentException
	 * 			The given coordinate is not a valid coordinate for the position.
	 */
	// Wat als null?
	public Position(double x, double y, double z) 
		throws IllegalArgumentException {
		if (! isValidPosition(x,y,z))
			throw new IllegalArgumentException();
		this.X = x;
		this.Y = y;
		this.Z = z;
	}
	
	/**
	 * 
	 * @param position
	 */
	public boolean isValidPosition(double x, double y, double z){
		if ((x < MAX_X ) && (y < MAX_Y) && (z < MAX_Z)
			&& (x >= MIN_X ) && (y >= MIN_Y) && (z >= MIN_Z))
			return true;
		else
			return false;
		
	}
	
	/**
	 * Set the Position of this Unit to the given coordinates.
	 * 
	 * @param x
	 *            The new X-coordinate for this Unit.
	 * @param y
	 *            The new Y-coordinate for this Unit.
	 * @param z
	 *            The new Z-coordinate for this Unit.
	 * @post The Position of this new Unit is equal to the given Position. |
	 *       new.getPosition() == position
	 * @throws ExceptionName_Java
	 *             The given Position is not a valid Position for any Unit. | !
	 *             isValidPosition(getPosition())
	 */
	@Raw
	public void setPosition(double x, double y, double z) throws IllegalPositionException {
		if (!isValidPosition(x, y ,z))
			throw new IllegalPositionException(x, y, z);
		this.X = x;
		this.Y = y;
		this.Z = z;
	}
	
	@Basic
	public double getX() {
		return this.X;
	}
	
	public double getY() {
		return this.Y;
	}
	
	public double getZ() {
		return this.Z;
	}
	
	
	
	public Position roundDown() {
		Position roundedPosition = new Position((int)(this.getX()),(int) (this.getY()),(int) (this.getZ()));
		return roundedPosition;
	}
}
	


