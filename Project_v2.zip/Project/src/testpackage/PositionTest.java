package testpackage;
import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 * 
 */

/**
 * @author jasper
 *
 */
public class PositionTest {

	/**
	 * @throws java.lang.Exception
	 */
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}
	

	/**
	 * @throws java.lang.Exception
	 */
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void constructor_NegativePos() throws IllegalArgumentException{
		new Position(7+30,0,0);
		
		
	}

	@Test
	public void roundedPos() {
		Position pos = new Position(40.2, 3.2, 4.9).roundDown();
		assertEquals(40, pos.getX(), 0.01);
		assertEquals(3, pos.getY(), 0.01);
		assertEquals(4, pos.getZ(), 0.01);

	}
}
