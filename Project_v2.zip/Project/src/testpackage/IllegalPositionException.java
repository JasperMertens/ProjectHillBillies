package testpackage;
import be.kuleuven.cs.som.annotate.*;

/**
 * A class for signaling illegal positions for a Unit.
 * @author Jasper, Zeno
 * @version 1.0
 *
 */
public class IllegalPositionException extends RuntimeException {
	
	public IllegalPositionException(double x, double y, double z){
		this.X = x;
		this.Y = y;
		this.Z = z;
		
	}
	/**
	 * Return the value registered for this illegal position exception
	 * @return
	 */
	// Is dit immutable?
	@Basic @Immutable
	public double getX() {
		return this.X;
	}
	
	public double getY() {
		return this.Y;
	}
	
	public double getZ() {
		return this.Z;
	}
	
	/** 
	 * Variable registering the value involved in this illegal position exception
	 */
	private final double X;
	private final double Y;
	private final double Z;
	
	// This aspect is of no concern to us, but Java requires it.
	private static final long serialVersionUID = 2003001L;

}
