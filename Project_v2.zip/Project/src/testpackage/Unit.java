package testpackage;

import java.nio.charset.IllegalCharsetNameException;
import testpackage.Position.*;

import be.kuleuven.cs.som.annotate.*;

/**
 * 
 * @invar The Position of each Unit must be a valid Position for any Unit. |
 *        isValidPosition(getPosition())
 */
public class Unit {

	private int health;
	private int stamina;
	private String name;
	

	public Unit(String name, int weigth, int strength, int agility, int toughness, double x, double y, double z) {
		position.setPosition(x, y, z);

	}

	@Basic
	public String getName() {
		return this.name;
	}

	@Basic
	public void setName(String name) throws IllegalNameException {
		if (!isValidName(name))
			throw new IllegalNameException(name);
		this.name = name;
			
	}
	
	public boolean isValidName(String name) {
		if (Character.isUpperCase(name.charAt(0)) && (name.length() == 2)) {
			
			for (int i = 0;i < name.length(); i++) {
				if ((!Character.isLetter(name.charAt(i)))
						&& (!Character.isSpaceChar(name.charAt(i))) 
						&& (name.charAt(i) != '\''))
					return false;
			}
			
			return true;
		}
		return false;

		
	}

	@Basic
	public int getWeigth() {
		return 1;

	}

	@Basic
	public int getStrength() {
		return 1;

	}

	@Basic
	public int getAgility() {
		return 1;

	}

	@Basic
	public int getToughness() {
		return 1;
	}

	/**
	 * Return the Position of this Unit.
	 */
	@Basic
	@Raw
	public Position getPositionUnit() {
		return this.position;
	}
	
	
	/**
	 * Return the Position of the cube in which the Unit rests.
	 * 
	 * @return
	 */
	public Position getPositionCube() {
		return getPositionUnit().roundDown();
	}

	/**
	 * Check whether the given Position is a valid Position for any Unit.
	 * 
	 * @param Position
	 *            The Position to check.
	 * @return | result ==
	 */
	// Is dat hier wel nodig?
	public static boolean isValidPosition(Position position) {
		return false;
	}

	/**
	 * Variable registering the Position of this Unit.
	 */
	private Position position;

}
