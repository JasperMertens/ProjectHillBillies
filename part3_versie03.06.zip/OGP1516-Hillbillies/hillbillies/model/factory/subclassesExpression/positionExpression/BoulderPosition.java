package hillbillies.model.factory.subclassesExpression.positionExpression;

import hillbillies.model.Boulder;
import hillbillies.model.Unit;
import hillbillies.model.factory.Expression;
import hillbillies.part3.programs.SourceLocation;

public class BoulderPosition extends Expression<int[]> {

	public BoulderPosition(SourceLocation sourceLocation) {
		super(sourceLocation);
	}
	
	@Override
	public int[] execute(Unit unit) {
		Unit.NearestResource<Boulder> nearestResource = unit.new NearestResource<>();
		Boulder boulder = new Boulder(null);
		return nearestResource.getNearestResource(boulder).getCurrentCubeCoordinate();
	}

}
