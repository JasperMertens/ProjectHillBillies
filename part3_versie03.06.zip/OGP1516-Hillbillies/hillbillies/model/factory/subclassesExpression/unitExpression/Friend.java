package hillbillies.model.factory.subclassesExpression.unitExpression;

import java.util.Set;

import hillbillies.model.Unit;
import hillbillies.model.factory.Expression;
import hillbillies.part3.programs.SourceLocation;

public class Friend extends Expression<Unit> {

	public Friend(SourceLocation sourceLocation) {
		super(sourceLocation);
	}

	@Override
	public Unit execute(Unit unit) {
		Set<Unit> friends = unit.getFaction().getUnits();
		friends.remove(unit);
		return (Unit) friends.toArray()[0];
	}
}
