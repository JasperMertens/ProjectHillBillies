package hillbillies.part3.programs;


import java.util.*;


import hillbillies.model.*;
import hillbillies.model.factory.Expression;
import hillbillies.model.factory.Statement;
import hillbillies.model.factory.subclassesExpression.*;
import hillbillies.model.factory.subclassesExpression.booleanExpression.AndExpression;
import hillbillies.model.factory.subclassesExpression.booleanExpression.CarryItem;
import hillbillies.model.factory.subclassesExpression.booleanExpression.FalseExpression;
import hillbillies.model.factory.subclassesExpression.booleanExpression.IsAlive;
import hillbillies.model.factory.subclassesExpression.booleanExpression.IsEnemy;
import hillbillies.model.factory.subclassesExpression.booleanExpression.IsFriend;
import hillbillies.model.factory.subclassesExpression.booleanExpression.IsPassable;
import hillbillies.model.factory.subclassesExpression.booleanExpression.IsSolid;
import hillbillies.model.factory.subclassesExpression.booleanExpression.NotExpression;
import hillbillies.model.factory.subclassesExpression.booleanExpression.OrExpression;
import hillbillies.model.factory.subclassesExpression.booleanExpression.TrueExpression;
import hillbillies.model.factory.subclassesExpression.positionExpression.BoulderPosition;
import hillbillies.model.factory.subclassesExpression.positionExpression.HerePosition;
import hillbillies.model.factory.subclassesExpression.positionExpression.LiteralPosition;
import hillbillies.model.factory.subclassesExpression.positionExpression.LogPosition;
import hillbillies.model.factory.subclassesExpression.positionExpression.NextToPosition;
import hillbillies.model.factory.subclassesExpression.positionExpression.PositionOf;
import hillbillies.model.factory.subclassesExpression.unitExpression.Any;
import hillbillies.model.factory.subclassesExpression.unitExpression.Enemy;
import hillbillies.model.factory.subclassesExpression.unitExpression.Friend;
import hillbillies.model.factory.subclassesExpression.unitExpression.This;
import hillbillies.model.factory.subclassesStatement.*;

@SuppressWarnings("rawtypes")
public class TaskFactory implements ITaskFactory<Expression<?>, Statement, Task> {

	@Override
	public List<Task> createTasks(String name, int priority, Statement activity, List<int[]> selectedCubes) {
		List<Task> taskList = new ArrayList<Task>();
		if (selectedCubes.size() == 0){
			taskList.add(new Task(name, priority, activity));
			return taskList;
		}
		else{
			int i = 0;
			while (i < selectedCubes.size()) {
				taskList.add(new Task(name, priority, activity));
				i ++;
			}
			return taskList;
		}
	}

	@Override
	public Statement createAssignment(String variableName, Expression value, SourceLocation sourceLocation) {
		return new Assignment(variableName, value, sourceLocation);
	}

	@Override
	public Statement createWhile(Expression condition, Statement body, SourceLocation sourceLocation) {
		return new WhileStatement(condition, body, sourceLocation);
	}

	@Override
	public Statement createIf(Expression condition, Statement ifBody, Statement elseBody,
			SourceLocation sourceLocation) {
		return new IfStatement(condition, ifBody, elseBody, sourceLocation);
	}

	@Override
	public Statement createBreak(SourceLocation sourceLocation) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Statement createPrint(Expression value, SourceLocation sourceLocation) {
		return new PrintStatement(value, sourceLocation);
	}

	@Override
	public Statement createSequence(List<Statement> statements, SourceLocation sourceLocation) {
		return new Sequence(statements, sourceLocation);
	}

	@Override
	public Statement createMoveTo(Expression position, SourceLocation sourceLocation) {
		return new MoveTo(position, sourceLocation);
	}

	@Override
	public Statement createWork(Expression position, SourceLocation sourceLocation) {
		return new Work(position, sourceLocation);
	}

	@Override
	public Statement createFollow(Expression unit, SourceLocation sourceLocation) {
		return new Follow(unit, sourceLocation);
	}

	@Override
	public Statement createAttack(Expression unit, SourceLocation sourceLocation) {
		return new Attack(unit, sourceLocation);
	}

	@Override
	public Expression createReadVariable(String variableName, SourceLocation sourceLocation) {
		// TODO Auto-generated method stub
		// interface met Value om map in op te slaan van alle variabelen?
		return new ReadVariable(variableName, sourceLocation);
	}

	@Override
	public Expression createIsSolid(Expression position, SourceLocation sourceLocation) {
		return new IsSolid(position, sourceLocation);
	}

	@Override
	public Expression createIsPassable(Expression position, SourceLocation sourceLocation) {
		return new IsPassable(position, sourceLocation);
	}

	@Override
	public Expression createIsFriend(Expression unit, SourceLocation sourceLocation) {
		return new IsFriend(unit, sourceLocation);
	}

	@Override
	public Expression createIsEnemy(Expression unit, SourceLocation sourceLocation) {
		return new IsEnemy(unit, sourceLocation);
	}

	@Override
	public Expression createIsAlive(Expression unit, SourceLocation sourceLocation) {
		return new IsAlive(unit, sourceLocation);
	}

	@Override
	public Expression createCarriesItem(Expression unit, SourceLocation sourceLocation) {
		return new CarryItem(unit,sourceLocation);
	}

	@Override
	public Expression createNot(Expression expression, SourceLocation sourceLocation) {
		return new NotExpression(expression, sourceLocation);
	}

	@Override
	public Expression createAnd(Expression left, Expression right, SourceLocation sourceLocation) {
		return new AndExpression(left, right, sourceLocation);
	}

	@Override
	public Expression createOr(Expression left, Expression right, SourceLocation sourceLocation) {
		return new OrExpression(left, right, sourceLocation);
	}

	@Override
	public Expression createHerePosition(SourceLocation sourceLocation) {
		return new HerePosition(sourceLocation);
	}

	@Override
	public Expression createLogPosition(SourceLocation sourceLocation) {
		return new LogPosition(sourceLocation);
	}

	@Override
	public Expression createBoulderPosition(SourceLocation sourceLocation) {
		return new BoulderPosition(sourceLocation);
	}

	@Override
	public Expression createWorkshopPosition(SourceLocation sourceLocation) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Expression createSelectedPosition(SourceLocation sourceLocation) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Expression createNextToPosition(Expression position, SourceLocation sourceLocation) {
		return new NextToPosition(position, sourceLocation);
	}

	@Override
	public Expression createPositionOf(Expression unit, SourceLocation sourceLocation) {
		return new PositionOf(unit, sourceLocation);
	}

	@Override
	public Expression createLiteralPosition(int x, int y, int z, SourceLocation sourceLocation) {
		return new LiteralPosition(x,y,z, sourceLocation);
	}

	@Override
	public Expression createThis(SourceLocation sourceLocation) {
		return new This(sourceLocation);
	}

	@Override
	public Expression createFriend(SourceLocation sourceLocation) {
		return new Friend(sourceLocation);
	}

	@Override
	public Expression createEnemy(SourceLocation sourceLocation) {
		return new Enemy(sourceLocation);
	}

	@Override
	public Expression createAny(SourceLocation sourceLocation) {
		return new Any(sourceLocation);
	}

	@Override
	public Expression createTrue(SourceLocation sourceLocation) {
		return new TrueExpression(sourceLocation);
	}

	@Override
	public Expression createFalse(SourceLocation sourceLocation) {
		return new FalseExpression(sourceLocation);
	}
}
