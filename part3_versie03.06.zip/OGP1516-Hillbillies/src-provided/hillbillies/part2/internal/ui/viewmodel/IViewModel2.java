package hillbillies.part2.internal.ui.viewmodel;

import hillbillies.part1.internal.ui.viewmodel.IViewModel1;

public interface IViewModel2 extends IViewModel1 {

	void focusObject(Object object);

}
