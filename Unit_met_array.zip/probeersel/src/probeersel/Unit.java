package probeersel;

import java.lang.reflect.Array;
import java.util.Arrays;

import be.kuleuven.cs.som.annotate.*;

/**
 * 
 * @invar The position of each Unit must be a valid position for any Unit. |
 *        isValidPosition(getPosition())
 * @invar The position of each Unit must be a valid position for any Unit. |
 *        isValidPosition(getPosition())
 */

public class Unit {

	/**
	 * Variable registering the position of this Unit.
	 */
	private double[] position;
	/**
	 * Constants marking the borders of the game world.
	 */
	private static final int MAX_X = 50;
	private static final int MIN_X = 0;
	private static final int MAX_Y = 50;
	private static final int MIN_Y = 0;
	private static final int MAX_Z = 50;
	private static final int MIN_Z = 0;

	private int health;
	private int stamina;
	private String name;
	private int weight;
	private int strength;
	private int agility;
	private int toughness;
	private int MAX_CONDITION = (int) (200 * (weight * toughness / 10000) + 1);

	/**
	 * Initialize this new Unit with given position.
	 *
	 * @param position
	 *            The position for this new Unit.
	 * @effect The position of this new Unit is set to the given position. |
	 *         this.setPosition(position)
	 */
	public Unit(String name, int weight, int strength, int agility, int toughness, double[] position)
			throws IllegalArgumentException {
		this.setPosition(position);
		this.setWeight(weight);
		this.setStrength(strength);
		this.setAgility(agility);
		this.setToughness(toughness);
	}

	/**
	 * Return the position of this Unit.
	 */
	@Basic
	@Raw
	public double[] getPosition() {
		return Arrays.copyOf(position, position.length);
	}

	/**
	 * Check whether the given position is a valid position for any Unit.
	 * 
	 * @param position
	 *            The position to check.
	 * @return | result == (Array.getDouble(position, 0) < MAX_X) &&
	 *         (Array.getDouble(position, 1) < MAX_Y) &&
	 *         (Array.getDouble(position, 2) < MAX_Z) &&
	 *         (Array.getDouble(position, 0) >= MIN_X) &&
	 *         (Array.getDouble(position, 1) >= MIN_Y) &&
	 *         (Array.getDouble(position, 2) >= MIN_Z)
	 */
	public static boolean isValidPosition(double[] position) {
		if ((Array.getDouble(position, 0) < MAX_X) && (Array.getDouble(position, 1) < MAX_Y)
				&& (Array.getDouble(position, 2) < MAX_Z) && (Array.getDouble(position, 0) >= MIN_X)
				&& (Array.getDouble(position, 1) >= MIN_Y) && (Array.getDouble(position, 2) >= MIN_Z))
			return true;
		else
			return false;
	}

	/**
	 * Set the position of this Unit to the given position.
	 * 
	 * @param position
	 *            The new position for this Unit.
	 * @post The position of this new Unit is equal to the given position. |
	 *       new.getPosition() == position
	 * @throws Illegal
	 *             The given position is not a valid position for any Unit. | !
	 *             isValidPosition(getPosition())
	 */
	@Raw
	public void setPosition(double[] position) throws IllegalArgumentException {
		if (!isValidPosition(position))
			throw new IllegalArgumentException();
		this.position = Arrays.copyOf(position, position.length);
	}
	/**
	 * Return the weight of this Unit.
	 */
	@Basic
	public int getWeigth() {
		return this.weight;
	}

	/**
	 * Set the weight of this Unit to the given weight.
	 * 
	 * @param weight
	 * 			The new weight for this Unit.
	 */
	@Basic
	public void setWeight(int weight) {
		if (!isValidWeight(weight))
			this.weight = (this.strength + this.agility)/2;
		else
			this.weight = ConstrainAttribute(weight);
	}

	/**
	 * 
	 * @param weight
	 * @return
	 */
	private boolean isValidWeight(int weight) {
		if (weight >= (this.strength + this.agility) / 2)
			return true;
		else
			return false;
	}

	@Basic
	public int getStrength() {
		return this.strength;

	}

	@Basic
	public void setStrength(int strength) {
		this.strength = ConstrainAttribute(strength);
	}

	@Basic
	public int getAgility() {
		return this.agility;

	}

	@Basic
	public void setAgility(int agility) {

		this.agility = ConstrainAttribute(agility);
	}

	@Basic
	public int getToughness() {
		return this.toughness;
	}

	@Basic
	public void setToughness(int toughness) {

		this.toughness = ConstrainAttribute(toughness);
	}
	
	// NOMINAAL
	@Basic
	public int getMaxCondition() {
		return this.MAX_CONDITION;
	}

	// NOMINAAL
	@Basic
	public boolean isValidCondition(int condition) {
		if ((condition >= 0) && (condition <= this.getMaxCondition()))
			return true;
		else
			return false;
	}
	
	/**
	 * 
	 * @param attr
	 * @return
	 */
	// WAT ALS null?
	public int ConstrainAttribute(int attr) {
		if (attr < 25)
			return 25;
		if (attr > 100)
			return 100;
		else
			return attr;
	}

}
