package hillbillies.model.factory;

import hillbillies.part3.programs.SourceLocation;

public abstract class Statement {
	
	private SourceLocation sourceLocation;
	
	protected Statement(SourceLocation sourceLoc){
		this.sourceLocation = sourceLoc;
	}
}
