package hillbillies.model.factory.subclassesStatement;

import hillbillies.model.factory.*;
import hillbillies.model.factory.subclassesExpression.Value;
import hillbillies.part3.programs.SourceLocation;

public class Assignment extends Statement {
	
	private String name;
	private Value value;

	public Assignment(String name, Value value, SourceLocation sourceLocation){
		super(sourceLocation);
		this.name = name; 
		this.value = value; 

	}
	
	public String getName(){
		return this.name;
	}
	public Value getValue(){
		return this.value;
	}
}
