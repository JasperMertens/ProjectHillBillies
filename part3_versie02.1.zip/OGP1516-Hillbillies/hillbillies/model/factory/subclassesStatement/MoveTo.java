package hillbillies.model.factory.subclassesStatement;

import hillbillies.model.factory.*;
import hillbillies.model.factory.subclassesExpression.Position;
import hillbillies.part3.programs.SourceLocation;

public class MoveTo extends Statement {

	private Expression position;

	protected MoveTo(Expression position, SourceLocation sourceLoc) {
		super(sourceLoc);
		this.position = new Position(position);
	}
	public Expression getPosition(){
		return this.position;
	}

}
