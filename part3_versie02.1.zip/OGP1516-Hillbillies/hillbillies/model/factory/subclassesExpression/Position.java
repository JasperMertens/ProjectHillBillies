package hillbillies.model.factory.subclassesExpression;

import hillbillies.model.factory.Expression;

public class Position extends Expression {

	public Position(Expression position) {
		// TODO Auto-generated constructor stub
		
	}

}
