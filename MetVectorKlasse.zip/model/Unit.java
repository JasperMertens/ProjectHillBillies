package hillbillies.model;

import java.util.*;
import be.kuleuven.cs.som.annotate.*;


// Niet vergeten | goed te zetten
/**
 * 
 * @invar The position of each Unit must be a valid position for any Unit. 
 *        	| isValidPosition(getPosition())
 * @invar The position of each Unit must be a valid position for any Unit. 
 *        	| isValidPosition(getPosition())
 * @invar The name of each Unit must be a valid name for any Unit. 
 *       	 | isValidName(getName())
 * @invar The health of each Unit must be a valid health for any Unit. 
 *       	 | isValidHealth(getHealth())
 * @invar The stamina of each Unit must be a valid stamina for any Unit. 
 *       	 | isValidStamina(getStamina())
 * @invar The orientation of each Unit must be a valid orientation for any Unit.
 *       	 | isValidOrientation(getOrientation())
 * @invar Each Unit can have its targetPosition as targetPosition. 
 *       	 | canHaveAsTargetPosition(this.getTargetPosition())
 * @invar The status of each Unit must be a valid status for any Unit. 
 *      	  | isValidStatus(getStatus())
// * @invar The time of each Unit must be a valid time for any Unit. 
// *       	 | isValidTime(getTime())
 * @invar The defaultBehavior of each Unit must be a valid defaultBehavior for any Unit.
 *		 	 | isValidDefaultBehavior(getDefaultBehavior())
 *
 * 
 * @author Zeno, Jasper
 * @version 2.0
 * 
 */

public class Unit {
	/**
	  * Variable registering the position of this Unit as a Vector.
	  */
	 private Vector vectorPosition;

	 /**
	  * Variable registering all legal statuses of this Unit.
	  */
	 private final static ArrayList<String> legalStatus = new ArrayList<>();

	 /**
	  * Constants marking the borders of the game world and length of one cube.
	 */
	 private static final int MAX_X = 50;
	 private static final int MIN_X = 0;
	 private static final int MAX_Y = 50;
	 private static final int MIN_Y = 0;
	 private static final int MAX_Z = 50;
	 private static final int MIN_Z = 0;
	 private static final int cubeLength = 1;

	 /**
	  * Variable registering the health of this Unit.
	  */
	 private int health;
	 /**
	  * Variable registering the stamina of this Unit.
	  */
	 private int stamina;
	 /**
	  * Variable registering the name of this Unit.
	  */
	 private String name;
	 /**
	  * Variable that multiplies the walking speed.
	  */
	 private int sprint = 1;
	 /**
	  * Variable registering the velocity of this Unit as a Vector.
	  */
	 private Vector currentVelocity;
	 /**
	  * Variable registering the base velocity of this Unit. This may change when
	  * a Unit develops his strength and/or agility and/or weight.
	  */
	 private double baseVelocity = 0.75 * (getStrength() + getAgility()) / (getWeight());
	 /**
	  * Variable registering the weight of this unit.
	  */
	 private int weight;
	 /**
	  * Variable registering the strength of this unit.
	  */
	 private int strength;
	 /**
	  * Variable registering the agility of this unit.
	  */
	 private int agility;
	 /**
	  * Variable registering the toughness of this unit.
	  */
	 private int toughness;
	 /**
	  * Variable registering the orientation of this Unit.
	  */
	 private float orientation;

	 /**
	  * Variable registering the maximal health and stamina of this Unit.
	  */
	 private int maxCondition;
	 /**
	  * Constant registering the maximal initial value for an attribute of this Unit.
	 */
	 private final int MAX_INIT_ATTR = 100;
	 /**
	  * Constant registering the maximal initial value for an attribute of this Unit.
	 */
	 private final int MIN_INIT_ATTR = 25;

	 /**
	  * Variable registering the status of this Unit, set initially to standing.
	 */
	 private String status = "standing";

//	 /**
//	  * Variable registering the time of this Unit.
//	  */
//	 private static double time = 0;
	 /**
	  * Variable registering if a Unit is moving to an adjacent cube.
	  */
	 private boolean isMovingToAdjacent = false;
	 /**
	  * Variable registering if a Unit is moving to a position.
	  */
	 private boolean isMovingTo = false;

	 /**
	  * Variable registering the target position where a Unit is moving to .
	  */
	 private int[] targetPosition = null;
	 /**
	  * Variable registering if a Unit is moving to an adjacent cube.
	  */
	 private double[] targetAdjacent;
	 /**
	  * Constant registering the duration after which a Unit should rest.
	  */
	 private double autoRest = 180;
	 /**
	  * Variable registering if a Unit has initiated rest.
	  */
	 private boolean initialRest = false;
	 /**
	  * Variable registering the time for a Unit to retrieve one health point.
	  */
	 // Time to gain one HP
	 private double healthRate;
	 /**
	  * Variable registering the time for a Unit to retrieve one stamina point.
	  */
	 // Time to gain one SP
	 private double staminaRate;
	
	private float activityTime;
	private static ArrayList<String> defaultBehavior = new ArrayList<>();
	private Random randomGenerator;
	/**
	 * Variable registering the defaultBehavior of this Unit.
	 */
	private boolean defaultBehaviorEnabled;

	/**
	 * Initialize this new Unit with given position.
	 *
	 * @param position
	 *            The position for this new Unit.
	 * @effect The position of this new Unit is set to the given position. 
	 *         	| this.setPosition(position)
	 *         
	 *      Initialize this new Unit with given weight.
	 * 
	 * @param weight
	 *            The weight for this new Unit.
	 * @post If the given weight is a valid weight for any Unit, the weight of
	 *       this new Unit is equal to the given weight. 
	 *       Otherwise, 
	 *       if the weight of this new Unit is less than 25, the weight of this new
	 *       Unit is equal to 25 or
	 *        if the weight of this new Unit is greater
	 *       than 100, the weight of this new Unit is equal to 100 
	 *       | if(isValidWeight(propertyName_Java)) | then new.getWeight() ==
	 *       |	propertyName_Java 
	 *       | else if weight < 25 
	 *       | 	then new.getWeight() == 25
	 *       | else if weight > 100 
	 *       | 	then new.getWeight() == 100
	 * 
	 *       Initialize this new Unit with given strength.
	 * 
	 * @param strength
	 *            The strength for this new Unit.
	 * @post If the given strength is a valid strength for any Unit, the
	 *       strength of this new Unit is equal to the given strength.
	 *       Otherwise,
	 *        if the strength of this new Unit is less than 25, the
	 *       strength of this new Unit is equal to 25 or if the strength of this
	 *       new Unit is greater than 100, the strength of this new Unit is
	 *       equal to 100 
	 *       | if(isValidstrength(propertyName_Java)) 
	 *       | 	then new.getStrength() == propertyName_Java 
	 *       | else if strength < 25 
	 *       | then new.getStrength() == 25 
	 *       | else if strength > 100 
	 *       | then new.getStrength() == 100
	 *       
	 * 
	 *       Initialize this new Unit with given agility.
	 * 
	 * @param agility
	 *            The agility for this new Unit.
	 * @post If the given agility is a valid agility for any Unit, the agility
	 *       of this new Unit is equal to the given agility. Otherwise, if the
	 *       agility of this new Unit is less than 25, the agility of this new
	 *       Unit is equal to 25 or if the agility of this new Unit is greater
	 *       than 100, the agility of this new Unit is equal to 100 
	 *       | if(isValidAgility(propertyName_Java)) 
	 *       | 	then new.getAgility() == propertyName_Java
	 *       | else if Agility < 25 
	 *       |	 then new.getAgility() == 25 
	 *       | else if Agility > 100 
	 *       | 	then new.getAgility() == 100
	 * 
	 *       Initialize this new Unit with given toughness.
	 * 
	 * @param toughness
	 *            The toughness for this new Unit.
	 * @post If the given toughness is a valid toughness for any Unit, the
	 *       toughness of this new Unit is equal to the given toughness.
	 *       Otherwise, if the toughness of this new Unit is less than 25, the
	 *       toughness of this new Unit is equal to 25 or if the toughness of
	 *       this new Unit is greater than 100, the toughness of this new Unit
	 *       is equal to 100 
	 *       | if(isValidToughness(propertyName_Java)) 
	 *       | 	then new.getToughness() == propertyName_Java 
	 *       | else if Toughness < 25 
	 *       |	then new.getToughness() == 25 
	 *       | else if Toughness > 100 
	 *       | 	then new.getToughness() == 100
	 *       
	 *         Initialize this new Unit with given health.
	 * 
	 * @param health
	 *            The health for this new Unit.
	 * @pre The given health must be a valid health for any Unit. 
	 *       | isValidHealth(health)
	 * @post The health of this new Unit is equal to the given health. 
	 *       | new.getHealth() == health
	 *
	 *
	 *       Initialize this new Unit with given stamina.
	 * 
	 * @param stamina
	 *            The stamina for this new Unit.
	 * @pre The given stamina must be a valid stamina for any Unit. 
	 *      | isValidStamina(stamina)
	 * @post The stamina of this new Unit is equal to the given stamina. 
	 *       | new.getStamina() == stamina 
	 *       
	 *       Initialize this new Unit with given name.
	 *
	 * @param name
	 *            The name for this new Unit.
	 * @effect The name of this new Unit is set to the given name.
	 *         | this.setName(name)
	 * 
	 * 
	 * 
	 */
	@Raw
	public Unit(String name, int[] position, int weight, int agility, int strength, int toughness,
			boolean enableDefaultBehavior) throws IllegalArgumentException {
		double[] doublePosition = new double[] { position[0], position[1], position[2] };
		setVectorPosition(doublePosition);
		setWeight(ConstrainAttribute(weight));
		setStrength(ConstrainAttribute(strength));
		setAgility(ConstrainAttribute(agility));
		setToughness(ConstrainAttribute(toughness));
		setOrientation((float) (Math.PI/2));
		setLegalStatus();
		setMaxCondition((int) (200 * (getWeight() * getToughness() / 10000) + 1));
		setDefaultBehavior();
		
			
		
	}

	/**
	 * Return the position of this Unit as an array of coordinates.
	 */
	@Basic
	@Raw
	public double[] getPositionUnit() {
		return this.vectorPosition.getCoordinates();
	}

	/**
	 * Check whether the given position is a valid position for any Unit.
	 * 
	 * @param position
	 *            The position to check.
	 * @return 	Return true if and only if the given position lies within the borders of the game world.
	 * 			| result == (Array.getDouble(position, 0) < MAX_X) &&
	 *         	|(Array.getDouble(position, 1) < MAX_Y) &&
	 *         	|(Array.getDouble(position, 2) < MAX_Z) &&
	 *         	|(Array.getDouble(position, 0) >= MIN_X) &&
	 *         	|(Array.getDouble(position, 1) >= MIN_Y) &&
	 *         	|(Array.getDouble(position, 2) >= MIN_Z)
	 */
	private static boolean isValidPosition(double[] position) {
		if ((position[0] < MAX_X) && (position[1] < MAX_Y)
				&& (position[2] < MAX_Z) && (position[0] >= MIN_X)
				&& (position[1] >= MIN_Y) && (position[2] >= MIN_Z))
			return true;
		else
			return false;
	}

	/**
	 * Set the position of this Unit to the given position.
	 * 
	 * @param position
	 *            The new position for this Unit.
	 * @post The position of this new Unit is equal to the given position. 
	 *        | new.getPosition() == position
	 * @throws Illegal
	 *             The given position is not a valid position for any Unit.
	 *             | !isValidPosition(getPosition())
	 */
	@Raw
	@Basic
	private void setVectorPosition(double[] position) throws IllegalArgumentException {
		if (!isValidPosition(position))
			throw new IllegalArgumentException();
		this.vectorPosition = new Vector(position);
	}

	/**
	 * Return the position of the cube surrounding the given position.
	 * 
	 * @param position
	 * @return
	 */
	@Basic
	@Raw
	private static int[] getPositionCube(double[] position) {
//		int[] roundedPosition = new int[3];
//		for (int i = 0; i < position.length; i++) {
//			roundedPosition[i] = (int) (position[i]);
//			System.out.println(roundedPosition);
//		}
//		System.out.println(roundedPosition);
//		return roundedPosition;
//	}
		Vector vectorPosition = new Vector(position);
		return vectorPosition.getRoundDown();
	}

	/**
	 * Return the position of the cube surrounding the Unit.
	 * @return
	 */
	@Basic
	public int[] getCubeCoordinate() {
		return this.vectorPosition.getRoundDown(); 
	}
	/**
	 * Return the center of the cube surrounding the given position.
	 * 
	 * @param positionInCube
	 * 
	 */
	@Basic
	private double[] getCentreCube(double[] positionInCube) {
		double xValueCube = getPositionCube(positionInCube)[0];
		double yValueCube = getPositionCube(positionInCube)[1];
		double zValueCube = getPositionCube(positionInCube)[2];

		double xCentreCube = (cubeLength / 2) + xValueCube;
		double yCentreCube = (cubeLength / 2) + yValueCube;
		double zCentreCube = (cubeLength / 2) + zValueCube;

		double[] centreCube = new double[] { xCentreCube, yCentreCube, zCentreCube };
		return centreCube;
	}

	/**
	 * Return the weight of this Unit.
	 */
	@Basic
	@Raw
	public int getWeight() {
		return this.weight;
	}

	/**
	 * Set the weight of this Unit to the given weight.
	 * 
	 * @param weight
	 *            The new weight for this Unit.
	 *
	 * @post If the given weight is a valid weight, the weight of this Unit is
	 *       equal to the given weight. 
	 *       | if (isValidWeight(weight)) 
	 *       | then new.getWeight() == weight
	 * @post If the given weight is not a valid weight, the weight of this Unit
	 *       is set to the mean value of the strength and agility of this Unit.
	 *       | if (! isValidWeight(weight)) 
	 *       | then new.getWeight() == (this.strength + this.agility)/2
	 */
	@Basic @Raw
	public void setWeight(int weight) {
		if (!isValidWeight(weight))
			this.weight = (this.strength + this.agility) / 2;
		else
			this.weight = weight;
	}

	/**
	 * Return the given attribute, constrained to the legal initial values.
	 * 
	 * @param attribute
	 *            The new attribute for a Unit.
	 * @post If the given attribute exceeds the maximal initial value, the
	 *       attribute is set to the maximal initial value. 
	 *       | if(attribute>MAX_INITIAL) 
	 *       | 	then return MAX_INITIAL ........
	 * @post If the given attribute is smaller then the minimal initial value, the
	 *       attribute is set to the minimal initial value.
	 *       | if(attribute<MIN_INITIAL)
	 *       |	then return MIN_INITAL
	 * @post If the given attribute adheres to the legal initial values, simply return the
	 * 			attribute.
	 * 		| if( MIN_INITIAL<=attribute<= MAX_INITIAL)
	 * 		|	then return attribute
	 * @return
	 */
	@Raw
	// Not static because in the future there might be a hero Unit that starts with bigger values
	// 		as attributes.
	private int ConstrainAttribute(int attribute) {
		if (attribute < this.getMinInitAttr())
			return this.getMinInitAttr();
		if (attribute > this.getMaxInitAttr())
			return this.getMaxInitAttr();
		else
			return attribute;
	}
	/**
	 * Return the minimal value for an attribute.
	 * @return
	 */
	@Basic
	private int getMinInitAttr() {
		return this.MIN_INIT_ATTR;
	}
	/**
	 * Return the maximal value for an attribute.
	 * @return
	 */
	@Basic
	private int getMaxInitAttr() {
		return this.MAX_INIT_ATTR;
	}

	/**
	 * Check whether the given weight is a valid weight.
	 * @param weight
	 * @return True if and only if the given weight is greater than
	 * 			the mean value of the Unit's strength and agility.
	 * 			| return == (weight >= (this.strength + this.agility) / 2)
	 */		
	private boolean isValidWeight(int weight) {
		if (weight >= (this.strength + this.agility) / 2)
			return true;
		else
			return false;
	}
	/**
	 * Return the strength of this Unit.
	 */
	@Basic @Raw
	public int getStrength() {
		return this.strength;
	}
	/**
	 * Set the strength of this Unit to the given strength.
	 * @post The strength of this Unit is equal to the given strength.
	 * 		| new.getStrength() == strength
	 * @param strength
	 * 			The new strength for this Unit.
	 */
	@Basic @Raw
	public void setStrength(int strength) {
		this.strength = strength;
	}
	/**
	 * Return the agility of this Unit.
	 */
	@Basic @Raw
	public int getAgility() {
		return this.agility;

	}
	/**
	 * Set the agility of this Unit to the given agility.
	 * @post The agility of this Unit is equal to the given agility.
	 * 		| new.getAgility() == agility
	 * @param agility
	 * 			The new agility for this Unit.
	 */
	@Basic @Raw
	public void setAgility(int agility) {

		this.agility = agility;
	}
	/**
	 * Return the strength of this Unit.
	 */
	@Basic @Raw
	public int getToughness() {
		return this.toughness;
	}
	/**
	 * Set the toughness of this Unit to the given toughness.
	 * @post The toughness of this Unit is equal to the given toughness.
	 * 		| new.getToughness() == toughness
	 * @param toughness
	 * 			The new toughness for this Unit.
	 */
	@Basic @Raw
	public void setToughness(int toughness) {

		this.toughness = toughness;
	}
	/**
	 * Return the maximum value for health and stamina for this Unit.
	 * @return
	 */
	@Basic @Raw
	public int getMaxCondition() {
		return this.maxCondition;
	}
	/**
	 * Set the maximum value for health and stamina for this Unit
	 * 		to the given value.
	 * 
	 * @param condition
	 */
	@Basic
	private void setMaxCondition(int condition) {
		this.maxCondition = condition;
	}

	/**
	 * Return the name of this Unit.
	 */
	@Basic
	@Raw
	public String getName() {
		return this.name;
	}

	/**
	 * Check whether the given name is a valid name for any Unit.
	 * 
	 * @param name
	 *            The name to check.
	 * @return | result == (!Character.isLetter(name.charAt(i))) 
	 * 			|				&& (!Character.isSpaceChar(name.charAt(i)))
				|				&& (name.charAt(i) != '\'')
	 */
	public static boolean isValidName(String name) {
		if (Character.isUpperCase(name.charAt(0)) && (name.length() >= 2)) {

			for (int i = 0; i < name.length(); i++) {
				if ((!Character.isLetter(name.charAt(i))) && (!Character.isSpaceChar(name.charAt(i)))
						&& (name.charAt(i) != '\''))
					return false;
			}

			return true;
		}
		return false;

	}

	/**
	 * Set the name of this Unit to the given name.
	 * 
	 * @param name
	 *            The new name for this Unit.
	 * @post The name of this new Unit is equal to the given name. 
	 *       | new.getName() == name
	 * @throws IllegalNameException
	 *             The given name is not a valid name for any Unit.
	 *             | !isValidName(getName())
	 */
	@Raw
	public void setName(String name) throws IllegalNameException {
		if (!isValidName(name))
			throw new IllegalNameException(name);
		this.name = name;
	}

	/**
	 * Return the health of this Unit.
	 */
	@Basic
	@Raw
	public int getHealth() {
		return this.health;
	}

	/**
	 * Check whether the given condition is a valid condition for any Unit.
	 * 
	 * @param condition
	 *            The condition to check.
	 * @return return == (condition >= 0) && (condition <= this.getMaxCondition())
	 */
	@Basic
	public boolean isValidCondition(int condition) {
		if ((condition >= 0) && (condition <= this.getMaxCondition()))
			return true;
		else
			return false;
	}

	/**
	 * Set the health of this Unit to the given health.
	 * 
	 * @param health
	 *            The new health for this Unit.
	 * @pre The given health must be a valid health for any Unit. 
	 *      | isValidHealth(health)
	 * @post The health of this Unit is equal to the given health. 
	 *       | new.getHealth() == health
	 */
	@Basic
	@Raw
	public void setHealth(int health) {
		assert isValidCondition(health);
		this.health = health;
	}

	/**
	 * Return the stamina of this Unit.
	 */
	@Basic
	@Raw
	public int getStamina() {
		return this.stamina;
	}

	/**
	 * Set the stamina of this Unit to the given stamina.
	 * 
	 * @param stamina
	 *            The new stamina for this Unit.
	 * @pre The given stamina must be a valid stamina for any Unit.
	 *      | isValidStamina(stamina)
	 * @post The stamina of this Unit is equal to the given stamina.
	 *       | new.getStamina() == stamina
	 */
	@Raw
	public void setStamina(int stamina) {
		assert isValidCondition(stamina);
		this.stamina = stamina;
	}


	/**
	 * Return the orientation of this Unit.
	 */
	@Basic
	@Raw
	public float getOrientation() {
		return this.orientation;
	}

	/**
	 * Check whether the given orientation is a valid orientation for any Unit.
	 * 
	 * @param orientation
	 *            The orientation to check.
	 * @return 	Returns true if and only if the value of the orientation lies between
	 * 				0 and 2*PI.
	 * 			| result == (orientation <= 2 * Math.PI) && (orientation >= 0)
	 */
	public static boolean isValidOrientation(float orientation) {
		if ((orientation <= 2 * Math.PI) && (orientation >= 0))
			return true;
		else
			return false;
	}

	/**
	 * Set the orientation of this Unit to the given orientation.
	 * 
	 * @param orientation
	 *            The new orientation for this Unit.
	 * @post If the given orientation is a valid orientation for any Unit, the
	 *       orientation of this new Unit is equal to the given orientation.
	 *       | if (isValidOrientation(orientation)) 
	 *       | 	then new.getOrientation() == orientation
	 *       
	 */
	@Raw
	public void setOrientation(float orientation) {
		if (isValidOrientation(orientation))
			this.orientation = orientation;
		else
			//MATH ABS WEG?! 
			this.orientation = (float) (orientation % (2 * Math.PI));
			System.out.println(orientation);
	}

//	/**
//	 * Return the time of this Unit.
//	 */
//	@Basic
//	@Raw
//	public static double getTime() {
//		return time;
//	}

//	/**
//	 * Check whether the given time is a valid time for any Unit.
//	 * 
//	 * @param time
//	 *            The time to check.
//	 * @return 	Returns true if and only if the given time is positive.
//	 * 			| result == (time >= 0)
//	 */
//	public static boolean isValidTime(double time) {
//		if (time >= 0)
//			return true;
//		return false;
//	}

//	/**
//	 * Set the time of this Unit to the given time.
//	 * 
//	 * @param time
//	 *            The new time for this Unit.
//	 * @post The time of this new Unit is equal to the given time. 
//	 *       | new.getTime() == time
//	 * @throws IllegalArgumentException
//	 *             The given time is not a valid time for any Unit.
//	 *              | !isValidTime(getTime())
//	 */
//	@Raw
//	public static void setTime(double givenTime) throws IllegalArgumentException {
//		if (!isValidTime(givenTime))
//			throw new IllegalArgumentException();
//		time = givenTime;
//	}

	/**
	 * Update the status and the position of a unit, advance the time of the
	 * game world by a given amount .
	 * 
	 * @param time
	 * 			The amount of time to advance the game time with.
	 * 
	 */
	public void advanceTime(double time) throws IllegalArgumentException{
		System.out.println("Advancing Time");
		if (!isValidAdvanceTime(time)) {
			throw new IllegalArgumentException();
		}
		if (getStatus() != "attacked") {
			// Let the Unit rest automatically if three minutes of game time have passed.
			if ((this.autoRest - time) <= 0) {
				this.initialRest = true;
				setStatus("resting");
				this.autoRest = 180 + this.autoRest - time;
			} else
				this.autoRest -= time;
			// If the Unit wants to rest, see to it that the initial rest period is complete.
			if ((initialRest) && (getHealth() < getMaxCondition())) {
				if (getHealthRate() >= time) {
					setHealthRate((getHealthRate() - time));
				} else
					setHealth(getHealth() + 1);
				this.initialRest = false;
				setHealthRate((0.2 * 200) / (getToughness()));
			}
			// Continue to let the Unit rest until he is full health, or does something else.
			if ((isResting()) && (getHealth() < getMaxCondition())) {
				if (getHealthRate() >= time) {
					setHealthRate((getHealthRate() - time));
				} else
					setHealth(getHealth() + 1);
				setHealthRate((0.2 * 200) / (getToughness()));
			}
			// Continue to let the Unit rest until he is full stamina, or does something else.
			if ((isResting()) && (getHealth() == getMaxCondition()) && (getStamina() < getMaxCondition())) {
				if (getStaminaRate() >= time) {
					setStaminaRate((getStaminaRate() - time));
				} else
					setStamina(getStamina() + 1);
				setStaminaRate((0.2 * 100) / this.getToughness());
			}
			// Update the position of a moving Unit, can be interrupted by other tasks
			// 			after the Unit has reached the center of his his target cube.
			// 	Note: A problem is that a Unit will do a working animation while finishing MoveToAdjacent.
			if ((isMoving()) || (getIsMovingToAdjacent())) {
				if (this.sprint == 2) {
					if (getStamina() >= (time * 10)) {
						setStamina((int) (getStamina() - (time * 10)));
					} else
						setStamina(0);
					this.sprint = 1;
				}
				if (!hasArrived(getPositionUnit(), this.targetAdjacent)) {
					updatePosition(time);
					updateOrientation();
				} else
					setVectorPosition(this.targetAdjacent);
					setStatus("standing");
					currentVelocity = new Vector(0,0,0);
					setIsMovingToAdjacent(false);
			}
			// Let the Unit perform it's task for a certain time.
			if (isWorking() || isAttacking()) {
				if (getActivityTime() >= time) {
					setActivityTime((float) (getActivityTime() - time));
				} else
					setActivityTime(0);
				setStatus("standing");
			}
		}
		// Halt all current tasks, because the Unit is attacked.
		else
			setIsMovingToAdjacent(false);
			
//		setTime(getTime() + time);
	}
	/**
	 * Checks if the given time is a valid time.
	 * @param time
	 * 			The time to check
	 * @return Returns true if and only if the given time lies between 0 and 0.2.
	 * 			|result == (0<=time<=0.2)
	 */
	private boolean isValidAdvanceTime(double time) {
		return ((time>= 0) && (time<= 0.2));
	}
	/**
	 * Returns the rate at which this Unit regains health while resting.
	 * @return
	 */
	@Basic
	public double getHealthRate() {
		return this.healthRate;
	}
	/**
	 * Set the health regaining rate of this Unit to the given rate.
	 * @param healthRate
	 * 			The rate at which this Unit regains health while resting.
	 */
	@Basic
	private void setHealthRate(double healthRate) {
		this.healthRate = healthRate;
	}
	/**
	 * Returns the rate at which this Unit regains stamina while resting.
	 * @return
	 */
	@Basic
	public double getStaminaRate() {
		return this.staminaRate;
	}
	/**
	 * Set the stamina regaining rate of this Unit to the given rate.
	 * @param staminaRate
	 * 				The rate at which this Unit regains stamina while resting.
	 */
	@Basic
	private void setStaminaRate(double staminaRate) {
		this.staminaRate = staminaRate;
	}
	/**
	 * Return the time it still takes for this Unit to complete his
	 * 				current activity. 
	 * @return
	 */
	@Basic
	public float getActivityTime() {
		return this.activityTime;
	}
	/**
	 * Set the time it will take for this Unit to complete his activity
	 * @param activityTime 
	 * 				The time it will takes for this Unit to complete his
	 * 				current activity. 
	 */
	private void setActivityTime(float activityTime) {
		this.activityTime = activityTime;
	}
	/**
	 * Update the orientation of the Unit according to the Unit's velocity.
	 */
	private void updateOrientation() {
		double xVelocity = this.getCurrentVelocity()[0];
		double yVelocity = this.getCurrentVelocity()[1];
		float orientation = (float) (Math.atan2(yVelocity, xVelocity));

		this.setOrientation(orientation);
	}

	/**
	 * Update the position of the Unit according to the Unit's velocity.
	 * @param unit
	 * @param time
	 */
	private void updatePosition(double time) {

		double xValueNow = this.getPositionUnit()[0];
		double yValueNow = this.getPositionUnit()[1];
		double zValueNow = this.getPositionUnit()[2];

		double xVelocity = this.getCurrentVelocity()[0];
		double yVelocity = this.getCurrentVelocity()[1];
		double zVelocity = this.getCurrentVelocity()[2];

		double[] newPosition = new double[] { xValueNow + xVelocity * time, yValueNow + yVelocity * time,
				zValueNow + zVelocity * time };
		
		this.setVectorPosition(newPosition);
		System.out.println("oude positie");
		System.out.println(getPositionUnit()[0]);
		System.out.println(getPositionUnit()[1]);
		System.out.println(getPositionUnit()[2]);
		System.out.println("nieuwe positie");
		System.out.println(newPosition[0]);
		System.out.println(newPosition[1]);
		System.out.println(newPosition[2]);
	}

	/**
	 * Return the base velocity of this Unit.
	 */
	@Basic
	@Raw
	public double getBaseVelocity() {
		return this.baseVelocity;
	}
	/**
	 * Let the Unit start sprinting.
	 */
	public void startSprint() {
		if ((this.status == "moving") && (this.stamina > 0))
			this.sprint = 2;
	}
	/**
	 * Let the Unit stop sprinting.
	 */
	public void stopSprint() {
		this.sprint = 1;
	}
	/**
	 * Return the multiplier of the normal speed.
	 * @return
	 */
	@Basic
	public int getSprint() {
		return this.sprint;
	}
	
	/**
	 * Return the currentVelocity of this Unit as an array of coordinates.
	 */
	@Basic
	@Raw
	public double[] getCurrentVelocity() {
		return this.currentVelocity.getCoordinates();
	}

	/**
	 * Set the currentVelocity of this Unit to the given currentVelocity.
	 * 
	 * @param currentVelocity
	 *            The new currentVelocity for this Unit.
	 * @post The currentVelocity of this new Unit is equal to the given
	 *       	currentVelocity. 
	 *       | new.getCurrentVelocity() == currentVelocity
	 * @throws IllegalArgumentException
	 *             The given adjacentPosition is not a valid adjacentPosition
	 *             for any Unit.
	 *             | !canHaveAsAdjacentPosition(adjacentPosition))
	 */
	@Raw
	public void setCurrentVelocity(double[] adjacentPosition) {
		Vector adjPosVector = new Vector(adjacentPosition);
		Vector subtractedVector = adjPosVector.subtractVector(this.vectorPosition);
		double distance = subtractedVector.getMagnitude();
		
		double Tempcte;
		if (this.getPositionUnit()[2] - adjacentPosition[2] == -1)
			Tempcte = 0.5;
		else if (this.getPositionUnit()[2] - adjacentPosition[2] == 1)
			Tempcte = 1.2;
		else
			Tempcte = 1;
		double factor = Tempcte*this.sprint/distance*this.getBaseVelocity();
		this.currentVelocity = subtractedVector.getMultipleVector(factor);
	}

	/**
	 * Check whether this Unit can have the given targetPosition as its
	 * targetPosition.
	 * 
	 * @param adjacentPosition
	 *            The targetPosition to check.
	 * @return | result == ((isValidPosition(adjacentPosition)) &&
	 *         |(Math.abs((xValueAdj - xValueCube)) == 1) && (Math.abs((yValueAdj
	 *         |- yValueCube)) == 1) && (Math.abs((zValueAdj - zValueCube)) == 1))
	 */
	@Raw
	public boolean canHaveAsAdjacentPosition(double[] adjacentPosition) {

		int xValueAdj = getPositionCube(adjacentPosition)[0];
		int yValueAdj = getPositionCube(adjacentPosition)[1];
		int zValueAdj = getPositionCube(adjacentPosition)[2];
		int xValueUnitCube = getPositionCube(getPositionUnit())[0];
		int yValueUnitCube = getPositionCube(getPositionUnit())[1];
		int zValueUnitCube = getPositionCube(getPositionUnit())[2];
//		System.out.println("x-waarde naburige");
//		System.out.println(xValueAdj);
//		System.out.println("y-waarde naburige");
//		System.out.println(yValueAdj);
//		System.out.println("z-waarde naburige");
//		System.out.println(zValueAdj);
//		System.out.println("x-waarde kubus");
//		System.out.println(xValueUnitCube);
//		System.out.println("y-waarde kubus");
//		System.out.println(yValueUnitCube);
//		System.out.println("z-waarde kubus");
//		System.out.println(zValueUnitCube);
//		System.out.println("xNaburig - xCubeUnit");
//		System.out.println(Math.abs((xValueAdj - xValueUnitCube)));
//		System.out.println("yNaburig - yCubeUnit");
//		System.out.println(Math.abs((yValueAdj - yValueUnitCube)));
//		System.out.println("zNaburig - zCubeUnit");
//		System.out.println(Math.abs((zValueAdj - zValueUnitCube)));
		
		if ((isValidPosition(adjacentPosition)) && ((Math.abs((xValueAdj - xValueUnitCube)) == 1)
				|| (Math.abs((yValueAdj - yValueUnitCube)) == 1) || (Math.abs((zValueAdj - zValueUnitCube)) == 1)))
			return true;
		else
			return false;
	}

	/**
	 * Move this Unit to an adjacent cube.
	 * @param dx
	 * 		The amount to move in the x-direction.
	 * @param dy
	 * 		The amount to move in the y-direction.
	 * @param dz
	 * 		The amount to move in the z-direction.
	 * @post The new position of the Unit is equal to the old position plus the given steps.
	 * 		| new.getPositionUnit() == old.getPositionUnit() + [dx, dy, dz]
	 * @throws IllegalArgumentException
	 * 			The target position is not a legal position
	 * 			|!canHaveAsAdjacentPosition(adjacentPosition)
	 */
	public void moveToAdjacent(int dx, int dy, int dz) throws IllegalArgumentException {
		System.out.println("Am I moving to Adjacent?");
		System.out.println(getIsMovingToAdjacent());
		if 
//		(!getIsMovingToAdjacent()){ 
				(((dx != 0) || (dy != 0) || (dz != 0))) {
			System.out.println("YEA");
			double[] adjacentPosition = new double[] { getPositionUnit()[0] + dx, getPositionUnit()[1] + dy,
					getPositionUnit()[2] + dz };

			if (!canHaveAsAdjacentPosition(adjacentPosition)) {
				System.out.println("Throw?!");
				throw new IllegalArgumentException();
			}
			double[] centreCube = new double[3];

			if (getCentreCube(adjacentPosition) != adjacentPosition) {
				centreCube = getCentreCube(adjacentPosition);
			} else if (getCentreCube(adjacentPosition) == adjacentPosition) {
				centreCube = adjacentPosition;
			}
			this.targetAdjacent = centreCube;
			setIsMovingToAdjacent(true);
			setStatus("moving");
			setCurrentVelocity(adjacentPosition);
			System.out.println(currentVelocity.getCoordinates());
		}
		else 
			System.out.println("NOPE");
	}


	/**
	 * Returns whether the Unit is moving to an Adjacent cube.
	 * 
	 * @return |this.isMovingToAdjacent
	 */
	public boolean getIsMovingToAdjacent() {
		return this.isMovingToAdjacent;
	}

	/**
	 * Set the variable isMovingToAdjacent to the given boolean.
	 * 
	 * @param bool
	 * @post The variable isMovingToAdjacent is equal to the given boolean.
	 *       |new.getIsMovingToAdjacent() == bool
	 */
	public void setIsMovingToAdjacent(boolean bool) {
		this.isMovingToAdjacent = bool;
	}

	public void moveTo(int[] targetPosition) throws IllegalArgumentException {

		double[] doubleTargetPosition = new double[] { targetPosition[0], targetPosition[1], targetPosition[2] };
		System.out.println("Did I get here?");
		if (!isValidPosition(doubleTargetPosition)) {
			throw new IllegalArgumentException();
		}
		System.out.println("Am I moving TO?");
		System.out.println(isMovingTo);
		setTargetPosition(targetPosition);
		if (!isMovingTo) {
			System.out.println("Am I moving?");
			this.isMovingTo = true;
			System.out.println(isMovingTo);
			int xValueTargetCube = getPositionCube(doubleTargetPosition)[0];
			int yValueTargetCube = getPositionCube(doubleTargetPosition)[1];
			int zValueTargetCube = getPositionCube(doubleTargetPosition)[2];

			int xValueUnitCube = getCubeCoordinate()[0];
			int yValueUnitCube = getCubeCoordinate()[1];
			int zValueUnitCube = getCubeCoordinate()[2];

			int x = 0;
			int y = 0;
			int z = 0;


		if (getCubeCoordinate() != getTargetPosition()) {
			System.out.println("Into the while?");
			if (xValueUnitCube == xValueTargetCube) {
				x = 0;
			} else if (xValueUnitCube < xValueTargetCube) {
				x = 1;
			}

			else {
				x = -1;
			}
			if (yValueUnitCube == yValueTargetCube) {
				y = 0;
			} else if (yValueUnitCube < yValueTargetCube) {
				y = 1;
			}

			else {
				y = -1;
			}
			if (zValueUnitCube == zValueTargetCube) {
				z = 0;
			} else if (zValueUnitCube < zValueTargetCube) {
				z = 1;
			}

			else {
				z = -1;
			}
			System.out.println("Going to Adjacent?");
			System.out.println("With");
			System.out.println(x);
			System.out.println(y);
			System.out.println(z);
			this.moveToAdjacent(x, y, z);
			System.out.println("Recursie?!");
			this.moveTo(targetPosition);
			
		}
		setTargetPosition(null);
		this.isMovingTo = false;
		}
	}

	private int[] getTargetPosition() {
		return this.targetPosition;
	}

	private void setTargetPosition(int[] targetPosition) {
		this.targetPosition = targetPosition;

	}

	public boolean isSameAs(String oldStatus, String newStatus) {
		return oldStatus == newStatus;
	}

	private boolean hasArrived(double[] previousPosition, double[] targetPosition) {
		double xDistancePrevToTarget = Math.pow((previousPosition[0] - targetPosition[0]), 2);
		double yDistancePrevToTarget = Math.pow((previousPosition[1] - targetPosition[1]), 2);
		double zDistancePrevToTarget = Math.pow((previousPosition[2] - targetPosition[2]), 2);

		double xDistancePrevToUnit = Math.pow((previousPosition[0] - this.getPositionUnit()[0]), 2);
		double yDistancePrevToUnit = Math.pow((previousPosition[1] - this.getPositionUnit()[1]), 2);
		double zDistancePrevToUnit = Math.pow((previousPosition[2] - this.getPositionUnit()[2]), 2);

		if ((xDistancePrevToUnit + yDistancePrevToUnit + zDistancePrevToUnit) >= (xDistancePrevToTarget
				+ yDistancePrevToTarget + zDistancePrevToTarget))
			return true;
		return false;
	}

	/**
	 * Return the status of this Unit.
	 */
	@Basic
	@Raw
	public String getStatus() {
		return this.status;
	}

	/**
	 * Check whether the given status is a valid status for any Unit.
	 * 
	 * @param status
	 *            The status to check.
	 * @return | result ==
	 */
	public static boolean isValidStatus(String status) {
		if (legalStatus.contains(status))
			return true;
		return false;
	}

	/**
	 * Set the status of this Unit to the given status.
	 * 
	 * @param status
	 *            The new status for this Unit.
	 * @post The status of this new Unit is equal to the given status. |
	 *       new.getStatus() == status
	 * @throws IllegalArgumentException
	 *             The given status is not a valid status for any Unit. | !
	 *             isValidStatus(getStatus())
	 */
	@Raw
	public void setStatus(String status) throws IllegalArgumentException {
		if (!isValidStatus(status))
			throw new IllegalArgumentException();
		this.status = status;
	}

	private void setLegalStatus() {
		legalStatus.add("standing");
		legalStatus.add("resting");
		legalStatus.add("moving");
		legalStatus.add("attacking");
		legalStatus.add("working");
		legalStatus.add("attacked");
	}

	public boolean isWorking() {
		return this.status == "working";

	}

	public boolean isAttacking() {
		return this.status == "attacking";

	}

	public boolean isAttacked() {
		return this.status == "attacked";

	}

	public boolean isResting() {
		return this.status == "resting";

	}

	public boolean isMoving() {
		return this.status == "moving";

	}

	public void work() {
		this.setStatus("working");
		this.setActivityTime(500 / this.getStrength());

	}

	// TIJD
	public void defend(Unit attackUnit) {
		if ((canHaveAsAdjacentPosition(attackUnit.getPositionUnit()))
				|| (getPositionCube(getPositionUnit()) == getPositionCube(attackUnit.getPositionUnit()))) {
			setOrientation((float) (attackUnit.getOrientation() + (Math.PI)));
			double dodgeConstant = (0.2 * getAgility() / attackUnit.getAgility());
			double blockConstant = (0.25
					* ((getStrength() + getAgility()) / (attackUnit.getStrength() + attackUnit.getAgility())));

			if (dodgeConstant >= Math.random()) {
				setRandomPosition(this);
			}

			else if (blockConstant >= Math.random()) {
			} else
				setHealth(attackUnit.getStrength() / 10);
		}
		setStatus("standing");

	}

	/**
	 * 
	 * @param defendUnit
	 * @note The defender's orientation depends on the attacker's orientation.
	 */
	// TIJD
	// Unit op hogere/lagere positie kan unit op hogere of lagere of zelfde
	// positie Kapotmake?
	// Onthouden wie wie aanvalt?
	public void attack(Unit defendUnit) {
		if ((canHaveAsAdjacentPosition(defendUnit.getPositionUnit()))
				|| (getPositionCube(getPositionUnit()) == getPositionCube(defendUnit.getPositionUnit()))) {

			setStatus("attack");
			defendUnit.setStatus("attacked");
			setActivityTime(1);
			double xValueDefender = defendUnit.getPositionUnit()[0];
			double yValueDefender = defendUnit.getPositionUnit()[1];
			double xValueAttacker = getPositionUnit()[0];
			double yValueAttacker = getPositionUnit()[1];

			float orientationAttacker = (float) (Math.atan2((yValueDefender - yValueAttacker),
					(xValueDefender - xValueAttacker)));
			setOrientation(orientationAttacker);
		}
	}

	private static void setRandomPosition(Unit defendUnit) {
		try {
			double xDodgeDistance = 2 * Math.random() - 1;
			double yDodgeDistance = 2 * Math.random() - 1;

			double xValueDefender = defendUnit.getPositionUnit()[0];
			double yValueDefender = defendUnit.getPositionUnit()[1];
			double zValueDefender = defendUnit.getPositionUnit()[2];

			double[] defenderDodgedPosition = new double[] { xValueDefender + xDodgeDistance,
					yValueDefender + yDodgeDistance, zValueDefender };
			defendUnit.setVectorPosition(defenderDodgedPosition);
		} catch (IllegalArgumentException exc) {
			setRandomPosition(defendUnit);
		}
	}

	public void rest() {
		if ((getHealth() < getMaxCondition()) || getStamina() < getMaxCondition())
			setStatus("resting");
	}
	
	private void setDefaultBehavior() {
		defaultBehavior.add("moveToRandom");
		defaultBehavior.add("startSprinting");
		defaultBehavior.add("resting");
		defaultBehavior.add("working");
	}


		/**
		 * Return if the default behavior of this Unit is enabled.
		 */
		@Basic @Raw
		public boolean getDefaultBehavior() {
			return this.defaultBehaviorEnabled;
		}

		/**
		 * Check whether the given defaultBehavior is a valid defaultBehavior for
		 * any Unit.
		 *  
		 * @param  defaultBehavior
		 *         The defaultBehavior to check.
		 * @return 
		 *       | if defaultBehavior == boolean
		 *       | 	then result == true
		 *       | else
		 *       |	result == false
		*/
		public static boolean isValidDefaultBehavior(boolean defaultBehavior) {
			if(boolean.class.equals(defaultBehavior))
				return true;
			else
				return false;
		}

		/**
		 * Set the defaultBehavior of this Unit to the given defaultBehavior.
		 * 
		 * @param  defaultBehavior
		 *         The new defaultBehavior for this Unit.
		 * @post   The defaultBehavior of this new Unit is equal to
		 *         the given defaultBehavior.
		 *       | new.getDefaultBehavior() == defaultBehavior
		 * @throws IllegalArgumentException
		 *         The given defaultBehavior is not a valid defaultBehavior for any
		 *         Unit.
		 *       | ! isValidDefaultBehavior(getDefaultBehavior())
		 */
		@Raw
		public void setDefaultBehavior(boolean defaultBehavior) 
				throws IllegalArgumentException {
			if (! isValidDefaultBehavior(defaultBehavior))
				throw new IllegalArgumentException();
			this.defaultBehaviorEnabled = defaultBehavior;
		}

		public void startDefaultBehavior(){
			int randomIndex = randomGenerator.nextInt(defaultBehavior.size());
			
			int randomXIndex = (randomGenerator.nextInt(MAX_X));
			int randomYIndex = (randomGenerator.nextInt(MAX_Y));
			int randomZIndex = (randomGenerator.nextInt(MAX_Z));
			
			int[] randomPosition = new int[]{randomXIndex,randomYIndex,randomZIndex};
			String randomactivity = defaultBehavior.get(randomIndex);
			
			if (getDefaultBehavior()){
			if ((getStatus() == "standing") && (randomactivity == "moveToRandom")){
					setStatus("moving");
					this.moveTo(randomPosition);
				}
			if ((getStatus() == "standing") && (randomactivity == "resting")){
					setStatus("resting");
					rest();
			}
			if ((getStatus() == "standing") && (randomactivity == "working")){
					setStatus("working");
					work();
				}
			if ((getStatus() == "moving") && (randomactivity == "startSprinting")){
				startSprint();
			}
			}
		}
		public void stopDefaultBehavior() {
			setStatus("standing");
			}

	
}
