package hillbillies.model;


import static org.junit.Assert.*;

import java.util.Arrays;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class VectorTest {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	
	@Test
	public final void constructor_DoubleNumbers() {
		Vector newVector = new Vector(1.0,1.0,1.0);
		assertEquals(1.0, newVector.getX(), 0);
		assertEquals(1.0, newVector.getY(), 0);
		assertEquals(1.0, newVector.getZ(), 0); 
	}
	
	@Test
	public final void constructor_IntegerNumbers() {
		int x = 1;
		int y = 1;
		int z = 1;
		Vector newVector = new Vector(x,y,z);
		assertEquals(1.0, newVector.getX(), 0);
		assertEquals(1.0, newVector.getY(), 0);
		assertEquals(1.0, newVector.getZ(), 0); 
	}
	
	@Test
	public final void constructor_DoubleArray() {
		double[] doubleArray = new double[]{1.0,1.0,1.0};
		Vector newVector = new Vector(doubleArray);
		assertEquals(1.0, newVector.getX(), 0);
		assertEquals(1.0, newVector.getY(), 0);
		assertEquals(1.0, newVector.getZ(), 0);  
	}
	@Test
	public final void constructor_IntegerArray() {
		int[] intArray = new int[]{1,1,1};
		Vector newVector = new Vector(intArray);
		assertEquals(1.0, newVector.getX(), 0);
		assertEquals(1.0, newVector.getY(), 0);
		assertEquals(1.0, newVector.getZ(), 0); 
	}
	
	@Test
	public final void getRoundDown() {
		Vector newVector = new Vector(1.5,-2.9,1.0);
		int[] intList = new int[]{1, -2, 1};
		assertTrue(Arrays.equals(newVector.getRoundDown(), intList));
		assertEquals(1.5, newVector.getX(), 0);
		assertEquals(-2.9, newVector.getY(), 0);
		assertEquals(1.0, newVector.getZ(), 0);
	}
	
	@Test
	public final void vectorCopy() {
		Vector originalVector = new Vector(1.0, 1.0, 1.0);
		Vector copyVector = originalVector.getCopy();
		assertTrue(originalVector.isIdenticalTo(copyVector));
	}
	
	@Test
	public final void vectorAdd_LegalCase() {
		Vector firstVector = new Vector(1.5,-2.9,1.0);
		Vector secondVector = new Vector(1.0,1.0,1.0);
		Vector resultVector = new Vector(2.5, -1.9, 2.0);
		assertTrue(resultVector.isIdenticalTo(firstVector.addVector(secondVector)));
		assertEquals(1.5, firstVector.getX(), 0);
		assertEquals(-2.9, firstVector.getY(), 0);
		assertEquals(1.0, firstVector.getZ(), 0);
		assertEquals(1.0, secondVector.getX(), 0);
		assertEquals(1.0, secondVector.getY(), 0);
		assertEquals(1.0, secondVector.getZ(), 0);
	}
	
	@Test (expected = NullPointerException.class)
	public final void vectorAdd_NonEffectiveVector() throws Exception {
		Vector newVector = new Vector(1.0,1.0,1.0);
		newVector.addVector(null);
	}
	
	@Test
	public final void vectorSubtract_LegalCase() {
		Vector firstVector = new Vector(1.5,-2.9,1.0);
		Vector secondVector = new Vector(1.0,1.0,1.0);
		Vector resultVector = new Vector(0.5, -3.9, 0);
		assertTrue(resultVector.isIdenticalTo(firstVector.subtractVector(secondVector)));
		assertEquals(1.5, firstVector.getX(), 0);
		assertEquals(-2.9, firstVector.getY(), 0);
		assertEquals(1.0, firstVector.getZ(), 0);
		assertEquals(1.0, secondVector.getX(), 0);
		assertEquals(1.0, secondVector.getY(), 0);
		assertEquals(1.0, secondVector.getZ(), 0);
	}
		
	@Test (expected = NullPointerException.class)
	public final void vectorSubtract_NonEffectiveVector() throws Exception {
		Vector newVector = new Vector(1.0,1.0,1.0);
		newVector.subtractVector(null);
	}
	
	@Test
	public final void getMagnitude() {
		Vector newVector = new Vector(1.0,1.0,1.0);
		assertEquals(Math.sqrt(3), newVector.getMagnitude(), 0.001);
	}
	
	@Test
	public final void isIdenticalTo_LegalCase() {
		Vector firstVector = new Vector(1.0, 1.0, 1.0);
		Vector secondVector = new Vector(1, 1, 1);
		assertTrue(firstVector.isIdenticalTo(secondVector));
	}
	
	@Test (expected = NullPointerException.class)
	public final void isIdenticalTo_NonEffectiveVector() throws Exception {
		Vector newVector = new Vector(1.0, 1.0, 1.0);
		newVector.isIdenticalTo(null);
	}
	
	@Test
	public final void getMultipleVector_Identity() {
		Vector firstVector = new Vector(1.0, 1.0, 1.0);
		Vector secondVector = new Vector(1, 1, 1);
		assertTrue(firstVector.isIdenticalTo(secondVector.getMultipleVector(1)));
	}
	
	@Test
	public final void getMultipleVector_NonIdentity() {
		Vector firstVector = new Vector(1.0, 1.0, 1.0);
		Vector secondVector = new Vector(2.0, 2.0, 2.0);
		assertTrue(secondVector.isIdenticalTo(firstVector.getMultipleVector(2)));
	}
	
	@Test
	public final void isPositiveVector() {
		Vector negativeVector = new Vector(1, 3, -2);
		assertFalse(negativeVector.isPositive());
	}
	
	@Test
	public final void getDirection_PositiveYVector() {
		Vector positiveYVector = new Vector(-2, 2, -1);
		assertEquals(3.0/4*Math.PI, positiveYVector.getAngle(), 0.001);
	}
	
	@Test
	public final void getDirection_NegativeYVector() {
		Vector negativeYVector = new Vector(-2, -2, -1);
		assertEquals(-3.0/4*Math.PI, negativeYVector.getAngle(), 0.001);
	}
}
