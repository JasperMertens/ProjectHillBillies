package hillbillies.model.factory.subclassesExpression;

import hillbillies.model.Unit;
import hillbillies.model.factory.Expression;
import hillbillies.part3.programs.SourceLocation;

public class OrExpression extends Expression<Boolean> {


	private Expression<Boolean> left;
	private Expression<Boolean> right;

	public OrExpression(Expression<Boolean> left, Expression<Boolean> right, SourceLocation sourceLocation) {
		super(sourceLocation);
		this.left = left;
		this.right = right;
	}

	@Override
	public Boolean execute(Unit unit) {
		if ((TrueExpression.class.isInstance(this.left)) || (TrueExpression.class.isInstance(this.right)))
			return true;
		else
			return false;
	}
}
