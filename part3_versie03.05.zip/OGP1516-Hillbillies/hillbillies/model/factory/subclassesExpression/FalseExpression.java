package hillbillies.model.factory.subclassesExpression;

import hillbillies.model.Unit;
import hillbillies.model.factory.Expression;
import hillbillies.part3.programs.SourceLocation;

public class FalseExpression extends Expression<Boolean> {

	public FalseExpression(SourceLocation sourceLocation) {
		super(sourceLocation);
	}
	
	@Override
	public Boolean execute(Unit unit){
		return false;
	}
}
