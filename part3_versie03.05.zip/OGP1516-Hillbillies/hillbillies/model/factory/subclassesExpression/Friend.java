package hillbillies.model.factory.subclassesExpression;

import hillbillies.model.Unit;
import hillbillies.model.factory.Expression;
import hillbillies.part3.programs.SourceLocation;

public class Friend extends Expression<Unit> {

	public Friend(SourceLocation sourceLocation) {
		super(sourceLocation);
	}

	@Override
	public Unit execute(Unit unit) {
		// TODO in Faction get any Unit
		return unit;
	}
}
