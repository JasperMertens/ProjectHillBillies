package hillbillies.model.factory.subclassesExpression;

import hillbillies.model.Cube;
import hillbillies.model.Unit;
import hillbillies.model.factory.Expression;
import hillbillies.part3.programs.SourceLocation;

public class IsPassable extends Expression<Boolean> {

	private Expression<int[]> position;

	public IsPassable(Expression<int[]> position, SourceLocation sourceLocation) {
		super(sourceLocation);
		this.position = position;
	}

	@Override
	public Boolean execute(Unit unit) {
		Cube cube = unit.getWorld().getCube(this.position.execute(unit));
		return !cube.isSolid();
	}

}
