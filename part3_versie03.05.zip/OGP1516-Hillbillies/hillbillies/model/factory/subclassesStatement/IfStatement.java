package hillbillies.model.factory.subclassesStatement;

import hillbillies.model.Unit;
import hillbillies.model.factory.Expression;
import hillbillies.model.factory.Statement;
import hillbillies.part3.programs.SourceLocation;

public class IfStatement extends Statement {

	private Expression<Boolean> condition;
	private Statement ifBody;
	private Statement elseBody;

	public IfStatement(Expression<Boolean> condition, Statement ifBody, Statement elseBody, SourceLocation sourceLocation) {
		super(sourceLocation);
		this.condition = condition;
		this.ifBody = ifBody;
		this.elseBody = elseBody;
	}

	@Override
	public void execute(Unit unit) {
		if ((boolean) condition.execute(null))
			this.ifBody.execute(unit);
		else if (!(boolean) condition.execute(null) && this.elseBody !=null)
			this.elseBody.execute(unit);
	}

}
