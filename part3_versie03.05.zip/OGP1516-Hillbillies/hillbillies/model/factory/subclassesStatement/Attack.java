package hillbillies.model.factory.subclassesStatement;

import hillbillies.model.Unit;
import hillbillies.model.factory.Expression;
import hillbillies.model.factory.Statement;
import hillbillies.part3.programs.SourceLocation;
import ogp.framework.util.ModelException;

public class Attack extends Statement {

	private Expression<Unit> unitToAttack;
	
	public Attack(Expression<Unit> unit, SourceLocation sourceLocation) {
		super(sourceLocation);
		this.unitToAttack = unit;
	}

	@Override
	public void execute(Unit unit) {
		try {
			this.getFacade().fight(unit, this.unitToAttack.execute(unit));
		} catch (ModelException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
