package hillbillies.model.factory.subclassesStatement;

import java.util.List;

import hillbillies.model.Unit;
import hillbillies.model.factory.Statement;
import hillbillies.part3.programs.SourceLocation;

public class Sequence extends Statement {

	private List<Statement> statements;

	public Sequence(List<Statement> statements, SourceLocation sourceLocation) {
		super(sourceLocation);
		this.statements = statements;
	}

	@Override
	public void execute(Unit unit) {
		 for (Statement statement : this.statements)
			this.executeElement(statement, unit);
	}
	
	private void executeElement(Statement statement, Unit unit) {
		statement.execute(unit);
		while (!unit.isDoneExecuting()){
		}
	}

}
