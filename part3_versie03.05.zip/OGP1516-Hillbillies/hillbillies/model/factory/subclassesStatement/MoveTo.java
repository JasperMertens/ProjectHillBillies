package hillbillies.model.factory.subclassesStatement;

import be.kuleuven.cs.som.annotate.*;
import hillbillies.model.Unit;
import hillbillies.model.factory.*;
import hillbillies.model.factory.subclassesExpression.BoulderPosition;
import hillbillies.model.factory.subclassesExpression.HerePosition;
import hillbillies.model.factory.subclassesExpression.LiteralPosition;
import hillbillies.model.factory.subclassesExpression.LogPosition;
import hillbillies.part3.programs.SourceLocation;
import ogp.framework.util.ModelException;

public class MoveTo extends Statement {

	private Expression<int[]> position;

	public MoveTo(Expression<int[]> position, SourceLocation sourceLocation) {
		super(sourceLocation);
		this.position = position;
	}
	@Immutable
	public Expression<int[]> getPosition(){
		return this.position;
	}
	@Override
	public void execute(Unit unit) {
		try {
			this.getFacade().moveTo(unit,(int[])(this.getPosition().execute(unit)));
		} catch (ModelException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
