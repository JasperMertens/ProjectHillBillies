package hillbillies.model;

import hillbillies.model.factory.Statement;

public class Task  {

	private String name;
	private Integer taskPriority;
	private Statement activities;
	private Unit unit;

//	TODO name
//	priority
//	activities
//	Assignment to Unit

	public Task(String name, int priority, Statement activity) {

//		if (activity.getLength() == 0)
//			throw new IllegalArgumentException();
		
		this.setName(name);
		this.setPriority(priority);
		this.setActivities(activity); 
	}

	private void setActivities(Statement givenActivities) {
		this.activities = givenActivities;
	}

	// Remove and add back to schedulers to keep the right ordering.
	private void setPriority(Integer priority) {
		this.taskPriority = priority;
	}

	public Integer getPriority() {
		return this.taskPriority;
	}

	private void setName(String name) {
		this.name = name; 
	}
	public String getName(){
		return this.name;
	}
	
	public void setUnit(Unit unit){
		this.unit = unit;
		}

	public Unit getUnit() {
		return this.unit;
	}

	public void reducePriority() {
		this.setPriority(this.getPriority()-1);
	}

	public boolean isBeingExecuted() {
		return this.getUnit()!=null;
	}
	
	public void execute() {
		this.activities.execute(this.getUnit());
	}
}

