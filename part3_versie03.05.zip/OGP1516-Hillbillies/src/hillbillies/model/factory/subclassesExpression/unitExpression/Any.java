package hillbillies.model.factory.subclassesExpression.unitExpression;

import java.util.Set;

import hillbillies.model.Unit;
import hillbillies.model.factory.Expression;
import hillbillies.part3.programs.SourceLocation;

public class Any extends Expression<Unit> {

	public Any(SourceLocation sourceLocation) {
		super(sourceLocation);
	}

	@Override
	public Unit execute(Unit unit) {
		Set<Unit> units = unit.getWorld().getActiveUnits();
		units.remove(unit);
		return (Unit) units.toArray()[0];
	}
}
