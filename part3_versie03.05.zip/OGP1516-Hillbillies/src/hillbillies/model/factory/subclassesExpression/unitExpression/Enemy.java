package hillbillies.model.factory.subclassesExpression.unitExpression;

import java.util.Set;

import hillbillies.model.Faction;
import hillbillies.model.Unit;
import hillbillies.model.factory.Expression;
import hillbillies.part3.programs.SourceLocation;

public class Enemy extends Expression<Unit> {

	public Enemy(SourceLocation sourceLocation) {
		super(sourceLocation);
	}

	@Override
	// TODO aparte methode om een willekeurig element uit een set te halen
	// Deze methode throwt een IllegalArgumentException als hi een lege set krijgt.
	public Unit execute(Unit unit) {
		Set<Faction> factions = unit.getWorld().getActiveFactions();
		factions.remove(unit.getFaction());
		Faction faction = (Faction) factions.toArray()[0];
		Set<Unit> enemies = faction.getUnits();
		enemies.remove(unit);
		return (Unit) enemies.toArray()[0];
	}
}
