package hillbillies.model;

public class Log extends Resource {

	protected Log(World world, Vector position) {
		super(position);
	}

}
