package hillbillies.model;

public class Log extends Resource {

	protected Log(Vector position) {
		super(position);
	}

}
