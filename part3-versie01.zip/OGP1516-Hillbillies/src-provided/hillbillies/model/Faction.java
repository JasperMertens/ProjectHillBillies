package hillbillies.model;

import java.util.*;

import be.kuleuven.cs.som.annotate.*;
/**
 * A class of Factions with given first Unit and the World where to the Faction belongs.
 * 
 * @invar An active Faction shall never contain more than 50 Units and at least one Unit.
 * 
 * @version 1.0
 * @author Zeno Gillis, Jasper Mertens 
 *
 */
public class Faction {
	
	private Set<Unit> unitSet;
	private World world;
	private Scheduler scheduler;
	
	public Faction(World world, Unit firstUnit) {
		this.world = world;
		this.unitSet = new HashSet<>();
		this.addUnit(firstUnit);
		this.scheduler = new Scheduler(this);
	}
	
	public void addUnit(Unit unit) {
		if (this.getNbOfUnits() <= 50) {
			this.unitSet.add(unit);
			unit.setFaction(this);
		}
	}
	
	public void removeUnit(Unit unit) throws IllegalStateException {
		
		if (this.unitSet.size() > 1)
			this.unitSet.remove(unit);
		else if (this.unitSet.size() == 1) {
			this.unitSet.remove(unit);
			this.world.removeFaction(this);
		}
		else
			throw new IllegalStateException();
	}
	
	/**
	 * Return the World of this Faction.
	 * @return
	 */
	@Basic @Immutable
	public World getWorld() {
		return this.world;
	}
	
	public Set<Unit> getUnits() {
		return this.unitSet;
	}
	
	public int getNbOfUnits() {
		return this.unitSet.size();
	}
	
}
