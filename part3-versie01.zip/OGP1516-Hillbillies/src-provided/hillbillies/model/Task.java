package hillbillies.model;

public class Task  {

	private String name;
	private Integer taskPriority;
	private Object[] activities;

//	TODO name
//	priority
//	activities
//	Assignment to Unit

	public Task(String givenName, Integer priority, Object[] givenActivities) 
			throws IllegalArgumentException{
		if (givenActivities.length == 0)
			throw new IllegalArgumentException();
		
		this.setName(givenName);
		this.setPriority(priority);
		this.setActivities(givenActivities); 
	}

	private void setActivities(Object[] givenActivities) {
		this.activities = givenActivities;
	}

	private void setPriority(Integer priority) {
		this.taskPriority = priority;
	}

	private void setName(String name) {
		this.name = name; 
	}
	
	public void setUnit(Unit unit){
		// TODO
		}

	public Integer getPriority() {
		// TODO Auto-generated method stub
		return null;
	}

	public Unit getUnit() {
		// TODO Auto-generated method stub
		return null;
	}
}

