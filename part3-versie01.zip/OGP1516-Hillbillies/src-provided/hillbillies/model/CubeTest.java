package hillbillies.model;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import hillbillies.part2.facade.Facade;
import hillbillies.part2.listener.DefaultTerrainChangeListener;
import ogp.framework.util.ModelException;

public class CubeTest {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	private Facade facade;

	@Before
	public void setUp() throws Exception {
		this.facade = new Facade();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testGetStringPosition() throws ModelException {
		int nbX = 10;
		int nbY = 20;
		int nbZ = 30;

		World world = facade.createWorld(new int[nbX][nbY][nbZ], new DefaultTerrainChangeListener());
		Cube newCube = new Cube(world, 1, 0, 0, 0);
		String c = newCube.getStringPosition();
		assertEquals(c, "x1y0z0");
	}

}
