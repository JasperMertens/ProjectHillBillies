package hillbillies.common.internal.ui.viewparts;

import javafx.scene.Node;

public abstract class ControlArea {

	public abstract Node getRoot();

	public void refresh() {
	}

}
