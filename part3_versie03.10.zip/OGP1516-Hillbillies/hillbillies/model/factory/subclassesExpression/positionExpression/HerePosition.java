package hillbillies.model.factory.subclassesExpression.positionExpression;

import hillbillies.model.Unit;
import hillbillies.model.factory.Expression;
import hillbillies.part3.programs.SourceLocation;

public class HerePosition extends Expression<int[]> {

	public HerePosition(SourceLocation sourceLocation) {
		super(sourceLocation);
	}

	@Override
	public int[] execute(Unit unit) {
		return unit.getCurrentCubeCoordinate();
	}

}
