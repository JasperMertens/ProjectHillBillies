package hillbillies.model.factory.subclassesExpression.positionExpression;

import java.util.ArrayList;

import hillbillies.model.Cube;
import hillbillies.model.Unit;
import hillbillies.model.factory.Expression;
import hillbillies.part3.programs.SourceLocation;

public class NextToPosition extends Expression<int[]> {

	private Expression<int[]> position;

	public NextToPosition(Expression<int[]> position, SourceLocation sourceLocation) {
		super(sourceLocation);
		this.position = position;
	}

	@Override
	//TODO throw exception ipv return null?
	public int[] execute(Unit unit) {
		Cube givenCube = unit.getWorld().getCube(this.position.execute(unit));
		ArrayList<Cube> neighbouringCubes = givenCube.getNeighbouringCubes();
		for (Cube neighbour : neighbouringCubes) {
			if (unit.canHaveAsAdjacentPosition(neighbour.getPosition()))
					return neighbour.getCoordinates();
		}
		return null;
	}
}