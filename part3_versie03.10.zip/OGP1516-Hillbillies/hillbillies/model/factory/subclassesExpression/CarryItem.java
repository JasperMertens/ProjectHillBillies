package hillbillies.model.factory.subclassesExpression;

import hillbillies.model.Unit;
import hillbillies.model.factory.Expression;
import hillbillies.part3.programs.SourceLocation;

public class CarryItem<T> extends Expression<Boolean, T> {

	
	private Expression<Unit, ?> unit;

	public CarryItem(Expression<Unit, ?> unit, SourceLocation sourceLocation) {
		super(sourceLocation);
		this.unit = unit;
	}

	@Override
	public Boolean execute(T t) {
		Unit worldUnit = (Unit) this.unit.execute(null);
		return (worldUnit.isCarryingResource());
	}
}
