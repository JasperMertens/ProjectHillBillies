package hillbillies.model.factory.subclassesExpression;

import hillbillies.model.factory.Expression;
import hillbillies.part3.programs.SourceLocation;

public class OrExpression<T> extends Expression<Boolean, T> {


	private Expression left;
	private Expression right;

	public OrExpression(Expression left, Expression right, SourceLocation sourceLocation) {
		super(sourceLocation);
		this.left = left;
		this.right = right;
	}

	@Override
	public Boolean execute(T t) {
		if ((TrueExpression.class.isInstance(this.left)) || (TrueExpression.class.isInstance(this.right)))
			return true;
		else
			return false;
	}
}
