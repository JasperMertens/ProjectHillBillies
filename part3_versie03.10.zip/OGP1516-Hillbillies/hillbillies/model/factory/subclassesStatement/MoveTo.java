package hillbillies.model.factory.subclassesStatement;

import be.kuleuven.cs.som.annotate.*;
import hillbillies.model.Unit;
import hillbillies.model.UnreachablePositionException;
import hillbillies.model.factory.*;
import hillbillies.model.factory.subclassesExpression.positionExpression.BoulderPosition;
import hillbillies.model.factory.subclassesExpression.positionExpression.HerePosition;
import hillbillies.model.factory.subclassesExpression.positionExpression.LiteralPosition;
import hillbillies.model.factory.subclassesExpression.positionExpression.LogPosition;
import hillbillies.part3.programs.SourceLocation;
import ogp.framework.util.ModelException;

public class MoveTo extends Statement {

	private Expression<int[]> position;

	public MoveTo(Expression<int[]> position, SourceLocation sourceLocation) {
		super(sourceLocation);
		this.position = position;
	}

	@Override
	public void execute(Unit unit) throws IllegalArgumentException {
			try {
				System.out.println(this.position.execute(unit).getClass());
				unit.moveTo((int[])(this.position.execute(unit)));
			} catch (UnreachablePositionException e) {
				// TODO Auto-generated catch block
				// reduce priority end task
				e.printStackTrace();
			}
	}
	
	@Override
	public Statement getNext(Unit unit) {
		return null;
	}
}
