package hillbillies.model;

import static org.junit.Assert.*;

import org.junit.*;

import hillbillies.part2.facade.Facade;
import hillbillies.part2.facade.IFacade;
import ogp.framework.util.ModelException;


import hillbillies.model.Unit;
import hillbillies.model.World;
import hillbillies.part2.listener.DefaultTerrainChangeListener;


public class UnitTest {
	
	private Facade facade;
	private static final int TYPE_AIR = 0;
	private static final int TYPE_ROCK = 1;
	private static final int TYPE_TREE = 2;
	private static final int TYPE_WORKSHOP = 3;
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}


	@Before
	public void setup() {
		this.facade = new Facade();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public  void moveToAdjacent_LegalCase() throws ModelException, IllegalArgumentException, UnreachablePositionException, IllegalPositionException, IllegalNameException{
		int[] position = new int[]{1,0,0};
		IFacade facade = new Facade();
		int nbX = 20;
		int nbY = 20;
		int nbZ = 30;

		World world = facade.createWorld(new int[nbX][nbY][nbZ], new DefaultTerrainChangeListener());
		Unit unit = new Unit("Jos", position, 30, 30, 30, 30, false);
		facade.addUnit(unit, world);
		unit.moveToAdjacent(1, 0, 0);
		Vector other = new Vector(2.5,0.5,0.5);
		for (int i = 0; i < 10; i++) {
			unit.advanceTime(0.2);
		}
		Boolean bool = unit.getVectorPosition().isIdenticalTo(other);
		assertTrue(bool == true);
	}
	
	@Test(expected=ModelException.class)
	public void testUnitName_NameTooShort() throws ModelException {
		facade.createUnit("E", new int[] { 1, 1, 1 }, 50, 50, 50, 50, false);
	}
	
	@Test(expected=ModelException.class)
	public void testUnitName_NameDoesntStartWithCapital() throws ModelException {
		facade.createUnit("hillbilly", new int[] { 1, 1, 1 }, 50, 50, 50, 50, false);
	}
	
	@Test(expected=ModelException.class)
	public void testUnitName_NameDoesntStartWithCapital_AndIsShort() throws ModelException {
		facade.createUnit("h", new int[] { 1, 1, 1 }, 50, 50, 50, 50, false);
	}
	
	@Test
	public void testSetValidName() throws ModelException {
		Unit unit = facade.createUnit("TestUnit", new int[] { 1, 1, 1 }, 50, 50, 50, 50, false);
		facade.setName(unit, "James O'Hare");
		assertEquals("This should be a valid name", "James O'Hare", facade.getName(unit));
	}
	
	@Test(expected=ModelException.class)
	public void testSetInvalidName() throws ModelException {
		Unit unit = facade.createUnit("TestUnit", new int[] { 1, 1, 1 }, 50, 50, 50, 50, false);
		facade.setName(unit, "James*O'Hare");
	}

	@Test
	public void testInitialInvalidAttributes() throws ModelException {
		Unit unit = facade.createUnit("TestUnit", new int[] { 1, 1, 1 }, 0, 120, -2, 25, false);
		int rightweight  = (unit.getStrength() + unit.getAgility())/2;
		assertEquals("This should be an invalid initial weight and should be set to (this.strength + this.agility)/2", rightweight, facade.getWeight(unit));
		assertEquals("This should be an invalid initial agility and should be set to 100", 100, facade.getAgility(unit));
		assertEquals("This should be an invalid initial strength and should be set to 25", 25, facade.getStrength(unit));
		assertEquals("This should be a valid initial toughness", 25, facade.getToughness(unit));
	}
	@Test
	public void testSetInvalidAttributes() throws ModelException {
		Unit unit = facade.createUnit("TestUnit", new int[] { 1, 1, 1 }, 25, 25, 25, 25, false);
		facade.setWeight(unit, 0);
		facade.setAgility(unit, 0);
		facade.setStrength(unit, 101);
		facade.setToughness(unit, 3000);
		assertEquals("This should be an invalid set weight and should be set to 51", 51, facade.getWeight(unit));
		assertEquals("This should be an invalid set agility and should be set to 1", 1, facade.getAgility(unit));
		assertEquals("This should be a valid set strength and should be set to 101", 101, facade.getStrength(unit));
		assertEquals("This should be a valid set toughness and should be set to 200", 200, facade.getToughness(unit));
	}
	
	@Test
	public void testValidInitialPosition() throws ModelException {
		int[] position = new int[]{1,0,0};
		
		IFacade facade = new Facade();
		
		int[][][] types = new int[3][3][3];
		types[1][1][0] = TYPE_ROCK;
		types[1][1][1] = TYPE_TREE;
		types[1][1][2] = TYPE_WORKSHOP;

		World world = facade.createWorld(types, new DefaultTerrainChangeListener());
		
		if (world.getCube(position).getTerrainType() == 0){
			Unit unit = facade.createUnit("TestUnit", position, 50, 50, 50, 50, false);
			facade.addUnit(unit, world);
			assertArrayEquals(position, new int[]{(int)facade.getPosition(unit)[0],(int)facade.getPosition(unit)[1],(int) facade.getPosition(unit)[2]});
		}
		else{
			world.getCube(position).setTerrainType(0);
			Unit unit = facade.createUnit("TestUnit", position, 50, 50, 50, 50, false);
			facade.addUnit(unit, world);
			assertArrayEquals(position, new int[]{(int)facade.getPosition(unit)[0],(int)facade.getPosition(unit)[1],(int) facade.getPosition(unit)[2]});
		}
	}
	
	@Test public void testSpawnUnit() throws ModelException {
		IFacade facade = new Facade();
		int[][][] types = new int[15][15][15];
		for (int x=0; x < 15; x++) {
			for (int y=0; y < 15; y++) {
				for (int z=0; z < 15; z++) {
					types[x][y][z] = TYPE_ROCK;
				}
			}
		}
		types[1][1][0] = TYPE_AIR;
		int[] openPosition = new int[]{1,1,0};

		World world = facade.createWorld(types, new DefaultTerrainChangeListener());
		Unit unit = facade.spawnUnit(world, false);
		int[] unitCubePosition = new int[]{(int)facade.getPosition(unit)[0],(int)facade.getPosition(unit)[1],(int) facade.getPosition(unit)[2]};
		assertArrayEquals(openPosition, unitCubePosition);
	}
	@Test public void testRemoveUnit() throws ModelException {
		IFacade facade = new Facade();
		int[][][] types = new int[15][15][15];
		for (int x=0; x < 15; x++) {
			for (int y=0; y < 15; y++) {
				for (int z=0; z < 15; z++) {
					types[x][y][z] = TYPE_ROCK;
				}
			}
		}
		types[1][1][0] = TYPE_AIR;

		World world = facade.createWorld(types, new DefaultTerrainChangeListener());
		Unit unit = facade.spawnUnit(world, false);
		world.removeUnit(unit);
		assertEquals(world.getActiveUnits().size(), 0);
	}
	@Test public void testKillUnit() throws ModelException {
		IFacade facade = new Facade();
		int[][][] types = new int[15][15][15];
		for (int x=0; x < 15; x++) {
			for (int y=0; y < 15; y++) {
				for (int z=0; z < 15; z++) {
					types[x][y][z] = TYPE_ROCK;
				}
			}
		}
		types[1][1][0] = TYPE_AIR;

		World world = facade.createWorld(types, new DefaultTerrainChangeListener());
		Unit unit = facade.spawnUnit(world, false);
		unit.setHealth(0);
		assertEquals(world.getActiveUnits().size(), 0);
	}
	@Test public void testUnitFalls() throws ModelException, IllegalArgumentException, UnreachablePositionException {
		IFacade facade = new Facade();
		int[][][] types = new int[3][3][3];
		for (int x=0; x < 3; x++) {
			for (int y=0; y < 3; y++) {
				for (int z=0; z < 3; z++) {
					types[x][y][z] = TYPE_AIR;
				}
			}
		}
		types[1][1][1] = TYPE_ROCK;
		types[1][1][0] = TYPE_ROCK;
		 
		World world = facade.createWorld(types, new DefaultTerrainChangeListener());
		Unit unit = facade.createUnit("Tommy", new int[]{1, 1, 2}, 50, 50, 50, 50, false);
		facade.addUnit(unit, world);
		int healthBeforeFalling = facade.getCurrentHitPoints(unit);
		System.out.println("Unit's position is: " + unit.getCurrentCubePosition().getX() +
				"  " + unit.getCurrentCubePosition().getY() + " " + unit.getCurrentCubePosition().getZ());
		facade.workAt(unit, 1, 1, 1);
		for (int i = 0; i < 90; i++) {
			world.advanceTime(0.2);
		}
		int healthAfterFalling = facade.getCurrentHitPoints(unit);
		assertEquals(healthBeforeFalling -10, healthAfterFalling);
	}
	@Test public void testUnitFallsToZeroZLevel() throws ModelException, IllegalArgumentException, UnreachablePositionException {
		IFacade facade = new Facade();
		int[][][] types = new int[3][3][3];
		for (int x=0; x < 3; x++) {
			for (int y=0; y < 3; y++) {
				for (int z=0; z < 3; z++) {
					types[x][y][z] = TYPE_AIR;
				}
			}
		}
		types[1][1][1] = TYPE_ROCK;
		types[1][1][0] = TYPE_ROCK;
		 
		World world = facade.createWorld(types, new DefaultTerrainChangeListener());
		Unit unit = facade.createUnit("Tommy", new int[]{1, 0, 2}, 50, 50, 50, 50, false);
		facade.addUnit(unit, world);
		System.out.println("Unit's position is: " + unit.getCurrentCubePosition().getX() +
				"  " + unit.getCurrentCubePosition().getY() + " " + unit.getCurrentCubePosition().getZ());
		int beforeFallingHealth = unit.getHealth();
		facade.workAt(unit, 1, 1, 1);
		for (int i = 0; i < 90; i++) {
			world.advanceTime(0.2);
		}
		int afterFallingHealth = unit.getHealth();
		assertEquals(0,(int)unit.getCurrentCubePosition().getZ());
		assertEquals(beforeFallingHealth-20,afterFallingHealth);
	}
}
