package hillbillies.model.factory.subclassesExpression;

import hillbillies.model.Unit;
import hillbillies.model.factory.Expression;
import hillbillies.part3.programs.SourceLocation;

public class ReadVariable extends Expression<Expression<?>> {

	private String variableName;
	
	public ReadVariable(String variableName, SourceLocation sourceLocation){
		super(sourceLocation);
		this.variableName = variableName;
	}
	
	@Override
	public Expression<?> execute(Unit unit) {
		Unit.Variable<Object> variable = unit.new Variable<>();
		System.out.println("Reading variable: " + variable.getVariable(this.variableName));
		return variable.getVariable(this.variableName);
	}
}
