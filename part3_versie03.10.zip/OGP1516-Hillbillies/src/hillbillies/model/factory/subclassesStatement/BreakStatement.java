package hillbillies.model.factory.subclassesStatement;

import hillbillies.model.Unit;
import hillbillies.model.factory.Statement;
import hillbillies.part3.programs.SourceLocation;

public class BreakStatement extends Statement {

	public BreakStatement(SourceLocation sourceLocation) throws IllegalArgumentException {
		super(sourceLocation);
	}

	@Override
	public void execute(Unit unit) throws IllegalArgumentException {
		unit.setBreakWhile(true);
	}

	@Override
	public Statement getNext(Unit unit) {
		// TODO Auto-generated method stub
		return null;
	}

}
