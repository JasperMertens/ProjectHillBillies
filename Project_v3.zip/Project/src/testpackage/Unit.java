package testpackage;

import be.kuleuven.cs.som.annotate.*;

/**
 * 
 * @invar The Position of each Unit must be a valid Position for any Unit. |
 *        isValidPosition(getPosition())
 * @invar The Weight of each Unit must at all times be at least
 *        (strength+agility)/2
 * @invar The Health and Stamina of each Unit must at all times be greater than
 *        or equal to zero and less or equal to the respective maximum number.
 */
public class Unit {

	private int health;
	private int stamina;
	private String name;
	private int weight;
	private int strength;
	private int agility;
	private int toughness;
	private int MAX_CONDITION = (int) (200 * (weight * toughness / 10000) + 1);
	private static final int MAX_X = 50;
	private static final int MIN_X = 0;
	private static final int MAX_Y = 50;
	private static final int MIN_Y = 0;
	private static final int MAX_Z = 50;
	private static final int MIN_Z = 0;

	public Unit(String name, int weight, int strength, int agility, int toughness, double x, double y, double z) {
		this.setPosition(x, y, z);
		this.setWeight(weight);
		this.setStrength(strength);
		this.setAgility(agility);
		this.setToughness(toughness);

	}

	/**
	 * 
	 * @param attr
	 * @return
	 */
	// WAT ALS null?
	public int ConstrainAttribute(int attr) {
		if (attr < 25)
			return 25;
		if (attr > 100)
			return 100;
		else
			return attr;
	}

	@Basic
	public String getName() {
		return this.name;
	}

	@Basic
	public void setName(String name) throws IllegalNameException {
		if (!isValidName(name))
			throw new IllegalNameException(name);
		this.name = name;

	}

	public boolean isValidName(String name) {
		if (Character.isUpperCase(name.charAt(0)) && (name.length() == 2)) {

			for (int i = 0; i < name.length(); i++) {
				if ((!Character.isLetter(name.charAt(i))) && (!Character.isSpaceChar(name.charAt(i)))
						&& (name.charAt(i) != '\''))
					return false;
			}

			return true;
		}
		return false;

	}

	@Basic
	public int getWeigth() {
		return this.weight;

	}

	/**
	 * 
	 * @param weight
	 */
	@Basic
	public void setWeight(int weight) {
		if (!isValidWeight(weight))
			this.weight = (this.strength + this.agility) / 2;
		this.weight = ConstrainAttribute(weight);
	}

	/**
	 * 
	 * @param weight
	 * @return
	 */
	private boolean isValidWeight(int weight) {
		if (weight >= (this.strength + this.agility) / 2)
			return true;
		else
			return false;
	}

	@Basic
	public int getStrength() {
		return this.strength;

	}

	@Basic
	public void setStrength(int strength) {
		this.strength = ConstrainAttribute(strength);
	}

	@Basic
	public int getAgility() {
		return this.agility;

	}

	@Basic
	public void setAgility(int agility) {

		this.agility = ConstrainAttribute(agility);
	}

	@Basic
	public int getToughness() {
		return this.toughness;
	}

	@Basic
	public void setToughness(int toughness) {

		this.toughness = ConstrainAttribute(toughness);
	}

	// NOMINAAL
	@Basic
	public int getHealth() {
		return this.health;
	}

	/**
	 * 
	 * @param health
	 */
	// NOMINAAL
	@Basic
	public void setHealth(int health) {
		assert isValidCondition(health);
		this.health = health;
	}

	// NOMINAAL
	@Basic
	public int getMaxCondition() {
		return this.MAX_CONDITION;
	}

	// NOMINAAL
	@Basic
	public boolean isValidCondition(int condition) {
		if ((condition >= 0) && (condition <= this.getMaxCondition()))
			return true;
		else
			return false;
	}

	// NOMINAAL
	@Basic
	public int getStamina() {
		return this.stamina;
	}

	/**
	 * 
	 * @param health
	 */
	// NOMINAAL
	@Basic
	public void setStamina(int stamina) {
		assert isValidCondition(stamina);
		this.stamina = stamina;
	}

	/**
	 * Return the Position of this Unit.
	 */
	@Basic
	@Raw
	public Position getPositionUnit() {
		return this.position;
	}

	/**
	 * Check whether the given position is a valid position
	 * 
	 * @param x
	 * @param y
	 * @param z
	 * @return
	 */
	public boolean isValidPosition(double x, double y, double z) {
		if ((x < MAX_X) && (y < MAX_Y) && (z < MAX_Z) && (x >= MIN_X) && (y >= MIN_Y) && (z >= MIN_Z))
			return true;
		else
			return false;

	}

	/**
	 * Set the Position of this Unit to the given coordinates.
	 * 
	 * @param x
	 *            The new X-coordinate for this Unit.
	 * @param y
	 *            The new Y-coordinate for this Unit.
	 * @param z
	 *            The new Z-coordinate for this Unit.
	 * @post The Position of this new Unit is equal to the given Position. |
	 *       new.getPosition() == position
	 * @throws ExceptionName_Java
	 *             The given Position is not a valid Position for any Unit. | !
	 *             isValidPosition(getPosition())
	 */
	@Raw
	public void setPosition(double x, double y, double z) throws IllegalPositionException {
		if (!isValidPosition(x, y, z))
			throw new IllegalPositionException(x, y, z);
		this.getPositionUnit().setX(x);
		this.getPositionUnit().setX(y);
		this.getPositionUnit().setX(z);
	}

	/**
	 * Return the Position of the cube in which the Unit rests.
	 * 
	 * @return
	 */
	public Position getPositionCube() {
		return getPositionUnit().roundDown();
	}

	/**
	 * Variable registering the Position of this Unit.
	 */
	private Position position;

}
