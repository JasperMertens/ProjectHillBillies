package testpackage;
import java.util.Vector;

import be.kuleuven.cs.som.annotate.Basic;
import be.kuleuven.cs.som.annotate.Raw;

/**
 * A class of positions that are identified by three coordinates, namely X, Y and Z.
 * 
 * @author Zeno, Jasper
 * @version 1.0
 */
public class Position {
	
	private double X;
	private double Y;
	private double Z;
	
	
	/**
	 * Initialize new position with given coordinates: X, Y, Z.
	 * @param x
	 * 			...
	 * @param y
	 * 			...
	 * @param z
	 * 			...
	 * @post	...
	 * 			| new.getX() == x
	 * @post	...
	 * 			| new.geY() == y
	 * @post	...
	 * 			| new.getZ() == z
	 * @throws IllegalArgumentException
	 * 			The given coordinate is not a valid coordinate for the position.
	 */
	// MISSCHIEN RAW
	@Raw
	public Position(double x, double y, double z){
		this.X = x;
		this.Y = y;
		this.Z = z;
	}
	
	
	
	@Basic
	public double getX() {
		return this.X;
	}
	
	public double getY() {
		return this.Y;
	}
	
	public double getZ() {
		return this.Z;
	}
	
	@Basic
	public void setX(double x) {
		this.X = x ;
	}
	@Basic
	public void setY(double y) {
		this.Y = y ;
	}
	@Basic
	public void setZ(double z) {
		this.Z = z ;
	}
	
	public Position roundDown() {
		Position roundedPosition = new Position((int)(this.getX()),(int) (this.getY()),(int) (this.getZ()));
		return roundedPosition;
	}
}
	


