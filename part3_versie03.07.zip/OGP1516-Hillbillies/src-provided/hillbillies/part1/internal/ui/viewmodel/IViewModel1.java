package hillbillies.part1.internal.ui.viewmodel;

import hillbillies.common.internal.ui.viewmodel.IViewModel;

public interface IViewModel1 extends IViewModel {

}
