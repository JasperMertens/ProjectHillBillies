package hillbillies.model.factory.subclassesExpression;

import hillbillies.model.Unit;
import hillbillies.model.factory.Expression;
import hillbillies.part3.programs.SourceLocation;

public class ReadVariable extends Expression<Object> {

	private String variableName;
	
	public ReadVariable(String variableName, SourceLocation sourceLocation){
		super(sourceLocation);
		this.variableName = variableName;
	}
	
	@Override
	public Object execute(Unit unit) {
		return unit.getVariable(this.variableName);
	}
}
