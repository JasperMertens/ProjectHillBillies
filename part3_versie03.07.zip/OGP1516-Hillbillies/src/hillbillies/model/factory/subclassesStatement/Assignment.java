package hillbillies.model.factory.subclassesStatement;

import hillbillies.model.Unit;
import hillbillies.model.factory.*;
import hillbillies.part3.programs.SourceLocation;

public class Assignment extends Statement {
	
	private String variableName;
	private Expression<Object> value;

	public Assignment(String variableName, Expression<Object> value, SourceLocation sourceLocation){
		super(sourceLocation);
		this.variableName = variableName; 
		this.value = value; 
	}
	
	@Override
	public void execute(Unit unit) throws IllegalArgumentException{
		unit.addVariable(this.variableName, this.value);
	}

	@Override
	public Statement getNext(Unit unit) {
		return null;
	}
	
}
