package hillbillies.model.factory;

import hillbillies.model.Task;

public interface CheckTask {
	
	boolean test(Task task);
}
