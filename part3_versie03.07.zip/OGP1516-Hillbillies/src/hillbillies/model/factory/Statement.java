package hillbillies.model.factory;

import be.kuleuven.cs.som.annotate.*;
import hillbillies.model.Unit;
import hillbillies.part3.facade.Facade;
import hillbillies.part3.programs.SourceLocation;

public abstract class Statement {
	
private SourceLocation sourceLocation;
private Facade facade;
	
	public Statement(SourceLocation sourceLocation) throws IllegalArgumentException{
		this.sourceLocation = sourceLocation;
		this.facade = new Facade();
	}
	
	@Immutable
	public SourceLocation getSourceLocation() {
		return this.sourceLocation;
	}
	
	@Immutable
	public Facade getFacade() {
		return this.facade;
	}
	
	public abstract void execute(Unit unit) throws IllegalArgumentException;
	
	public abstract Statement getNext(Unit unit);
}
