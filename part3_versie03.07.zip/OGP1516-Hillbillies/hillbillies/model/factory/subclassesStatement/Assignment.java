package hillbillies.model.factory.subclassesStatement;

import java.util.Map;

import hillbillies.model.Unit;
import hillbillies.model.factory.*;
import hillbillies.part3.programs.SourceLocation;

public class Assignment extends Statement {
	
	private String variableName;
	private Expression<Object> value;
	private Map<String, Expression<Object>> valueMap;

	public Assignment(String variableName, Expression<Object> value, SourceLocation sourceLocation){
		super(sourceLocation);
		this.variableName = variableName; 
		this.value = value; 
	}
	
	@Override
	public void execute(Unit unit) {
		this.valueMap.put(this.variableName, this.value);
	}

	@Override
	public Statement getNext(Unit unit) {
		return null;
	}
	
	public static 
}
