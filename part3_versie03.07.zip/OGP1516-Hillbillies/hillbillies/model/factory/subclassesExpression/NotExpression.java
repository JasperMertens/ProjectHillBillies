package hillbillies.model.factory.subclassesExpression;

import hillbillies.model.factory.Expression;
import hillbillies.part3.programs.SourceLocation;

//TODO enkel True- en FalseExpression zijn mogelijke argumenten.
// casten?
public class NotExpression<T> extends Expression<Boolean, T> {

	private Expression<Boolean, T> expression;

	public NotExpression(Expression expression, SourceLocation sourceLocation) {
		super(sourceLocation);
		this.expression = expression;
	}
	
	@Override
	public Boolean execute(T t){
		if (TrueExpression.class.isInstance(this.expression))
			return false;
		else
			return true;
	}

}
