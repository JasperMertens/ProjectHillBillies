package hillbillies.model;

import hillbillies.model.factory.Statement;

public class Task  {

	private String name;
	private Integer taskPriority;
	private Statement activities;
	private Vector taskPosition;

//	TODO name
//	priority
//	activities
//	Assignment to Unit

	public Task(String name2, int priority, Statement activity) {

//		if (activity.getLength() == 0)
//			throw new IllegalArgumentException();
		
		this.setName(name2);
		this.setPriority(priority);
		this.setActivities(activity); 
	}

	private void setCoordinates(int[] coordinates) {
		this.taskPosition = new Vector(coordinates);

	}

	private void setActivities(Statement givenActivities) {
		this.activities = givenActivities;
	}

	private void setPriority(Integer priority) {
		this.taskPriority = priority;
	}

	public Integer getPriority() {
		return this.taskPriority;
	}

	private void setName(String name) {
		this.name = name; 
	}
	public String getName(){
		return this.name;
	}
	
	public void setUnit(Unit unit){
		// TODO
		}

	public Unit getUnit() {
		// TODO Auto-generated method stub
		return null;
	}
}

