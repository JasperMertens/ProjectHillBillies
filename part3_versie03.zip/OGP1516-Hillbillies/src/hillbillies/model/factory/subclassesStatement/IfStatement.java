package hillbillies.model.factory.subclassesStatement;

import hillbillies.model.Unit;
import hillbillies.model.factory.Expression;
import hillbillies.model.factory.Statement;
import hillbillies.model.factory.subclassesExpression.TrueExpression;
import hillbillies.part3.programs.SourceLocation;

public class IfStatement extends Statement {

	private Expression condition;
	private Statement ifBody;
	private Statement elseBody;

	public IfStatement(Expression condition, Statement ifBody, Statement elseBody, SourceLocation sourceLocation) {
		super(sourceLocation);
		this.condition = condition;
		this.ifBody = ifBody;
		this.elseBody = elseBody;
	}

	@Override
	public void execute(Unit unit) {
		if (condition.execute())
	}

}
