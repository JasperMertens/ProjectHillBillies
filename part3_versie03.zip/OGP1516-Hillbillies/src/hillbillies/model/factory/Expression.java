package hillbillies.model.factory;


import hillbillies.part3.programs.SourceLocation;

public abstract class Expression<S, T> {
	
	private SourceLocation sourceLocation;
	
	protected Expression(SourceLocation sourceLocation) {
		this.sourceLocation = sourceLocation;
	}

	public SourceLocation getSourceLocation() {
		return this.sourceLocation;
	}
	
	public void setSourceLocation(SourceLocation sourceLocation) {
		this.sourceLocation = sourceLocation;
	}
	
	public abstract S execute(T t); 
}