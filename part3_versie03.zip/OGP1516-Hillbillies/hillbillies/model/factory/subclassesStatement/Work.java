package hillbillies.model.factory.subclassesStatement;

import be.kuleuven.cs.som.annotate.Immutable;
import hillbillies.model.Unit;
import hillbillies.model.factory.Expression;
import hillbillies.model.factory.Statement;
import hillbillies.part3.programs.SourceLocation;
import ogp.framework.util.ModelException;

public class Work extends Statement {

	private Expression position;

	public Work(Expression position, SourceLocation sourceLocation) {
		super(sourceLocation);
		this.position = position;
	}

	@Immutable
	public Expression getPosition(){
		return this.position;
	}
	
	@Override
	public void execute(Unit unit) {
		try {
			int[] integerPosition = (int[])this.position.execute();
			this.getFacade().workAt(unit, integerPosition[0], integerPosition[1], integerPosition[2]);
		} catch (ModelException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
