package ogp.framework.game;

public interface IGameView {
	public void refreshDisplay();

	public void setStatusText(String info);
}
