package hillbillies.model;

import be.kuleuven.cs.som.annotate.Basic;
import be.kuleuven.cs.som.annotate.Raw;

/**
 * A class of WorldObjects, with given position and World where they exist.
 * 
 * @version 1.0
 * @author Zeno Gillis, Jasper Mertens
 */
public 	abstract class WorldObject {

	protected World world;
	protected int weight;
	protected Vector vectorPosition;
	protected boolean falling;
	
	protected WorldObject(Vector position) throws IllegalArgumentException {
		if (!position.isPositive())
			throw new IllegalArgumentException();
		this.vectorPosition = (position.getCopy());
	}
	
	/**
	 * Return whether this WorldObject can fall at its current position.
	 * @return
	 */
	protected abstract boolean canFall();
	
	/**
	 * Return the weight of this WorldObject.
	 * @return
	 */
	@Basic
	protected int getWeight() {
		return this.weight;
	}
	
	/**
	 * Return the position of this WorldObject as an array of coordinates.
	 * 
	 */
	// NO problem for reference leaks, in the Vector class the getCoordinates method returns a newly made list.
	@Basic
	@Raw
	public double[] getPosition() {
		return this.vectorPosition.getCoordinates();
	}
	
	/**
	 * Return the position of this WorldObject as a Vector.
	 */
	// getCopy method in Vector class to prevent reference leaks.
	@Basic
	@Raw
	public Vector getVectorPosition() {
		return this.vectorPosition.getCopy();
	}
	
	/**
	 * Set the position of this WorldObject to the given position.
	 * 
	 * @param position
	 *            The new position for this WorldObject.
	 * @post The position of this new Unit is equal to the given position. 
	 *        | new.getPosition() == position
	 * @throws Illegal
	 *             The given position is not a valid position for any WorldObject.
	 *             | !isValidPosition(getPosition())
	 */
	@Raw
	@Basic
	public void setVectorPosition(Vector position) throws IllegalArgumentException {
		if (!this.canHaveAsPosition(position, this.world)) {
			throw new IllegalPositionException(position, this.world);
		}
		this.vectorPosition = (position.getCopy());
	}
	
	/**
	 * Return whether the given position is a valid position for this WorldObject,
	 * 	within the given World.
	 * 
	 * @param position
	 * 			The position to check.
	 * @param world
	 * 			The World in which the position must be checked.
	 * @return True if and only if the given position is within the boundaries of the given World
	 * 			and if the Cube at the given position isn't a solid Cube.
	 * 			| return == (this.world.isWithinWorld(x, y, z) && (!cube.isSolid())
	 */
	public boolean canHaveAsPosition(Vector position, World world) {
		double x_coord = position.getX();
		double y_coord = position.getY();
		double z_coord = position.getZ();
		Cube cube = world.getCube(position.getRoundDown());
		if (world.isWithinWorld(x_coord, y_coord, z_coord) && (!cube.isSolid()))
			return true;
		return false;
	}
	
	/**
	 * Add this WorldObject to the given World.
	 * 
	 * @param world
	 * 		The World to add the current WorldObject to.
	 */
	@Basic
	public void addObjectToWorld(World world) throws IllegalPositionException{
		if (!canHaveAsPosition(this.getVectorPosition(), world))
			throw new IllegalPositionException(this.getVectorPosition(), world);
		this.world = world;
		this.setVectorPosition(this.getCurrentCube().getCentreCube());
	}
	
	/**
	 * Removes this WorldObject from its current World.
	 */
	public void removeObjectFromWorld() {
		this.world = null;
	}
	
	/**
	 * Return the position of the Cube surrounding this WorldObject as an array of coordinates.
	 * @return
	 */
	@Basic
	// NO problem for reference leaks, in the Vector class the roundDown method returns a newly made list.
	public int[] getCurrentCubeCoordinate() {
		return this.vectorPosition.getRoundDown(); 
	}
	
	/**
	 * Return the position of the Cube surrounding this WorldObject as a Vector.
	 * @return
	 */
	public Vector getCurrentCubePosition() {
		return new Vector(this.getCurrentCubeCoordinate());
	}
	
	/**
	 * Return the Cube this WorldObject is currently occupying.
	 * @return
	 */
	public Cube getCurrentCube() {
		return this.world.getCube(this.getCurrentCubeCoordinate());
	}
	
	public void advanceTime(double time) {
		if (this.isFalling()) {
			Vector fallingSpeed = new Vector(0, 0, -3);
			Vector fallingVector = fallingSpeed.getMultipleVector(time);
			Vector newPosition = this.getVectorPosition().addVector(fallingVector);
			int[] newCoordinates = new int[]{(int) newPosition.getX(),
												(int) newPosition.getY(),
												(int) newPosition.getZ() };
			Cube newCube = this.world.getCube(newCoordinates);
			Vector minZ = new Vector(0,0,1);
			Vector targetVector = this.getCurrentCube().getCentreCube().subtractVector(minZ);
			double distance = fallingVector.getMagnitude();
			// if the newCube has solid ground beneath it and if the WorldObjec has fallen until
			// it's position is the center of the Cube at one level below the current Cube. 
			if (this.world.isAboveSolidGround(newCube) && this.hasArrived(targetVector, distance)){
				this.setFalling(false);
				this.setVectorPosition(newPosition);
			}
		
			this.setVectorPosition(newPosition);
		}	
	}
	
	/**
	 * Return whether this WorldObject is falling.
	 * @return
	 */
	@Basic
	protected boolean isFalling() {
		return this.falling;
	}
	
	/**
	 * Set whether this WorldObject is falling.
	 * 
	 * @param bool
	 * 		The boolean to indicate whether this WorldObject is falling.
	 */
	@Basic
	protected void setFalling(boolean bool) {
		this.falling = bool;
	}
	
	/**
	 * Check if this WorldObject has arrived at the center of the given targetCube
	 * 	after travelling the given distance.
	 * 
	 * @param centreTargetCube
	 * 		The centre of the target Cube.
	 * @param distance
	 * 		The distance to travel.
	 * @return
	 * 		| result == (distance >= currentDistanceToTarget)
	 */
	public boolean hasArrived(Vector centreTargetCube, double distance) {
		double currentDistanceToTarget = 
				centreTargetCube.subtractVector(this.getVectorPosition()).getMagnitude();
		if (distance >= currentDistanceToTarget){
			return true;
		}
		return false;
	}
}
