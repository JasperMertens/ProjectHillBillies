package hillbillies.model;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class Log extends Resource {

	public Log(Vector position) {
		super(position);
	}

	@Override
	public Set<Log> getAll(Set<Resource> set) {
		Set<Log> result = new HashSet<>(); 
		Iterator<Resource> iter = set.iterator();
		while (iter.hasNext()) {
			Resource resource = (Resource) iter.next();
			if (Log.class.isInstance(resource))
				result.add((Log) resource);
		}
		return result;
	}

}
