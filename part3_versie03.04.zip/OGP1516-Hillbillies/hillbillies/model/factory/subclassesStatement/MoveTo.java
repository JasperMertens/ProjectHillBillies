package hillbillies.model.factory.subclassesStatement;

import be.kuleuven.cs.som.annotate.*;
import hillbillies.model.Unit;
import hillbillies.model.factory.*;
import hillbillies.model.factory.subclassesExpression.BoulderPosition;
import hillbillies.model.factory.subclassesExpression.HerePosition;
import hillbillies.model.factory.subclassesExpression.LiteralPosition;
import hillbillies.model.factory.subclassesExpression.LogPosition;
import hillbillies.part3.programs.SourceLocation;
import ogp.framework.util.ModelException;

public class MoveTo extends Statement {

	private Expression<int[], ?> position;

	public MoveTo(Expression<int[], ?> position, SourceLocation sourceLocation) {
		super(sourceLocation);
		this.position = position;
	}
	@Immutable
	public Expression<int[], ?> getPosition(){
		return this.position;
	}
	@Override
	public void execute(Unit unit) {
		try {
			if (HerePosition.class.isInstance(this.position)) 
				this.getFacade().moveTo(unit, (int[]) ((HerePosition) this.position).execute(unit));
			else if (LiteralPosition.class.isInstance(this.position))
				this.getFacade().moveTo(unit, (int[]) ((LiteralPosition<?>) this.position).execute(null));
			else if (LogPosition.class.isInstance(this.position))
				this.getFacade().moveTo(unit, (int[]) ((LogPosition) this.position).execute(unit));
			else if (BoulderPosition.class.isInstance(this.position))
				this.getFacade().moveTo(unit, (int[]) ( (BoulderPosition) this.position).execute(unit));
			
		} catch (ModelException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
