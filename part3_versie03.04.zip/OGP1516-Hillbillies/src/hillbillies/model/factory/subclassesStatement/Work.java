package hillbillies.model.factory.subclassesStatement;

import be.kuleuven.cs.som.annotate.Immutable;
import hillbillies.model.Unit;
import hillbillies.model.factory.Expression;
import hillbillies.model.factory.Statement;
import hillbillies.model.factory.subclassesExpression.BoulderPosition;
import hillbillies.model.factory.subclassesExpression.HerePosition;
import hillbillies.model.factory.subclassesExpression.LiteralPosition;
import hillbillies.model.factory.subclassesExpression.LogPosition;
import hillbillies.part3.programs.SourceLocation;
import ogp.framework.util.ModelException;

public class Work extends Statement {

	private Expression<int[]> position;

	public Work(Expression<int[]> position, SourceLocation sourceLocation) {
		super(sourceLocation);
		this.position = position;
	}

	@Immutable
	public Expression<int[]> getPosition(){
		return this.position;
	}
	
	@Override
	public void execute(Unit unit) {
		try {
			int[] integerPosition = new int[3];
			integerPosition = (int[])(this.position).execute(unit);
			this.getFacade().workAt(unit, integerPosition[0], integerPosition[1], integerPosition[2]);
		} catch (ModelException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
