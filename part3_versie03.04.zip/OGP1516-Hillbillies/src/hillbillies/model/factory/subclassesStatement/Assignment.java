package hillbillies.model.factory.subclassesStatement;

import hillbillies.model.Unit;
import hillbillies.model.factory.*;
import hillbillies.model.factory.subclassesExpression.Value;
import hillbillies.part3.programs.SourceLocation;

public class Assignment extends Statement {
	
	private String name;
	private Expression<Object> value;

	public Assignment(String name, Expression<Object> value, SourceLocation sourceLocation){
		super(sourceLocation);
		this.name = name; 
		this.value = value; 
	}
	
	public String getName(){
		return this.name;
	}
	public Value getValue(){
		return (Value) this.value;
	}

	@Override
	public void execute(Unit unit) {
		// TODO Auto-generated method stub
		
	}
}
