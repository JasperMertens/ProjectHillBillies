package hillbillies.model.factory.subclassesExpression;

import hillbillies.model.Unit;
import hillbillies.model.factory.Expression;
import hillbillies.part3.programs.SourceLocation;

//TODO enkel True- en FalseExpression zijn mogelijke argumenten.
// casten?
public class NotExpression extends Expression<Boolean> {

	private Expression<Boolean> expression;

	public NotExpression(Expression<Boolean> expression, SourceLocation sourceLocation) {
		super(sourceLocation);
		this.expression = expression;
	}
	
	@Override
	public Boolean execute(Unit unit){
		if (TrueExpression.class.isInstance(this.expression))
			return false;
		else
			return true;
	}

}
