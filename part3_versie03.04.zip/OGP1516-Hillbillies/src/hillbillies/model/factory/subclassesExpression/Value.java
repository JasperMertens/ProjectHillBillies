package hillbillies.model.factory.subclassesExpression;

import hillbillies.model.Unit;
import hillbillies.model.factory.Expression;
import hillbillies.part3.programs.SourceLocation;

public class Value extends Expression<Object> {

	private Number value;
	
	public Value(Number value, SourceLocation sourceLocation){
		super(sourceLocation);
		this.value = value;
	}
	
	@Override
	public Number execute(Unit unit) {
		return this.value;
	}
}
