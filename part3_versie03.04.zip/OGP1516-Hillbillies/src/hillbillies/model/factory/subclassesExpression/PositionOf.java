package hillbillies.model.factory.subclassesExpression;

import hillbillies.model.Unit;
import hillbillies.model.factory.Expression;
import hillbillies.part3.programs.SourceLocation;

public class PositionOf extends Expression<int[]> {

	private Expression<Unit> unitToCheck;

	public PositionOf(Expression<Unit> unit, SourceLocation sourceLocation) {
		super(sourceLocation);
		this.unitToCheck = unit;
	}

	@Override
	public int[] execute(Unit unit) {
		return this.unitToCheck.execute(unit).getCurrentCubeCoordinate();
	}

}
