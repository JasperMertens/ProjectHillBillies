package hillbillies.model.factory.subclassesExpression;

import hillbillies.model.Unit;
import hillbillies.model.factory.Expression;
import hillbillies.part3.programs.SourceLocation;

public class UnitExpression extends Expression<Unit> {

	protected UnitExpression(SourceLocation sourceLocation) {
		super(sourceLocation);
	}

	@Override
	public Unit execute(Unit unit) {
		return unit;
	}

}
