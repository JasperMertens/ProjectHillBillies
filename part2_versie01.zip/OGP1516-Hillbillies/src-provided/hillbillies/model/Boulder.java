package hillbillies.model;

/**
 * A class of Boulders, with given position and World where they exist..
 * 
 * @version 1.0
 * @author Zeno Gillis, Jasper Mertens
 *
 */
public class Boulder extends Resource{

	protected Boulder(World world, Vector position) {
		super(world, position);
	}
	
}