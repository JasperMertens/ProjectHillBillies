package hillbillies.model;

import be.kuleuven.cs.som.annotate.Basic;
import be.kuleuven.cs.som.annotate.Raw;

/**
 * A class of WorldObjects, with given position and World where they exist.
 * 
 * @version 1.0
 * @author Zeno Gillis, Jasper Mertens
 */
public 	abstract class WorldObject {

	protected World world;
	protected int weight;
	protected Vector vectorPosition;
	protected boolean falling;

	protected WorldObject(World world, Vector position) {
		this.world = world;
		this.setVectorPosition(position);
	}
	
	/**
	 * Return whether this WorldObject can fall at its current position.
	 * @return
	 */
	protected abstract boolean canFall();
	
	/**
	 * Return the weight of this WorldObject.
	 * @return
	 */
	@Basic
	protected int getWeight() {
		return this.weight;
	}
	
	/**
	 * Return the position of this WorldObject as an array of coordinates.
	 * 
	 */
	// NO problem for reference leaks, in the Vector class the getCoordinates method returns a newly made list.
	@Basic
	@Raw
	public double[] getPosition() {
		return this.vectorPosition.getCoordinates();
	}
	
	/**
	 * Return the position of this WorldObject as a Vector.
	 */
	// getCopy method in Vector class to prevent reference leaks.
	@Basic
	@Raw
	public Vector getVectorPosition() {
		return this.vectorPosition.getCopy();
	}
	
	/**
	 * Set the position of this WorldObject to the given position.
	 * 
	 * @param position
	 *            The new position for this WorldObject.
	 * @post The position of this new Unit is equal to the given position. 
	 *        | new.getPosition() == position
	 * @throws Illegal
	 *             The given position is not a valid position for any WorldObject.
	 *             | !isValidPosition(getPosition())
	 */
	@Raw
	@Basic
	private void setVectorPosition(Vector position) throws IllegalArgumentException {
		if (!isValidPosition(position))
			throw new IllegalArgumentException();
		this.vectorPosition = (position.getCopy());
	}
	
	/**
	 * Return whether the given coordinates are valid coordinates for any WorldObject,
	 * 	within this World.
	 * @param x
	 * 		The X-coordinate to check.
	 * @param y
	 * 		The Y-coordinate to check.
	 * @param z
	 * 		The Z-coordinate to check.
	 * @return True if and only if the given coordinates are within the boundaries of this World
	 * 			and if the Cube at the given coordinates isn't a solid Cube.
	 * 			| return == (this.world.isWithinWorld(x, y, z) && (!cube.isSolid())
	 */
	public boolean isValidPosition(Vector position) {
		double x_coord = position.getX();
		double y_coord = position.getY();
		double z_coord = position.getZ();
		Cube cube = this.world.getCube(position.getRoundDown());
		if (this.world.isWithinWorld(x_coord, y_coord, z_coord) && (!cube.isSolid()))
			return true;
		return false;
	}
	
	/**
	 * Return the position of the cube surrounding this WorldObject.
	 * @return
	 */
	@Basic
	// NO problem for reference leaks, in the Vector class the roundDown method returns a newly made list.
	public int[] getCubeCoordinate() {
		return this.vectorPosition.getRoundDown(); 
	}
	
	public void advanceTime(double time) {
		if (this.isFalling()) {
			Vector fallingSpeed = new Vector(0, 0, -3);
			Vector fallingVector = fallingSpeed.getMultipleVector(time);
			Vector newPosition = this.getVectorPosition().addVector(fallingVector);
			this.setVectorPosition(newPosition);
		}
		
	}
	
	/**
	 * Return whether this WorldObject is falling.
	 * @return
	 */
	@Basic
	protected boolean isFalling() {
		return this.falling;
	}
	
	
	
}
