package hillbillies.model;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

/**
 * A class of Boulders, with given position and World where they exist..
 * 
 * @version 1.0
 * @author Zeno Gillis, Jasper Mertens
 *
 */
public class Boulder extends Resource{

	protected Boulder(Vector position) {
		super(position);
	}

	@Override
	public Set<Boulder> getAll(Set<Resource> set) {
		Set<Boulder> result = new HashSet<>(); 
		Iterator<Resource> iter = set.iterator();
		while (iter.hasNext()) {
			Resource resource = (Resource) iter.next();
			if (Boulder.class.isInstance(resource))
				result.add((Boulder) resource);
		}
		return result;
	}

}