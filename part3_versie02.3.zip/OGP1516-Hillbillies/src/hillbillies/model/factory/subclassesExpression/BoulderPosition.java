package hillbillies.model.factory.subclassesExpression;

import hillbillies.model.Unit;
import hillbillies.model.factory.Expression;
import hillbillies.part3.programs.SourceLocation;

public class BoulderPosition extends Expression {

	public BoulderPosition(SourceLocation sourceLocation) {
		super(sourceLocation);
		// TODO Auto-generated constructor stub
	}
	

	public int[] execute(Unit unit) {
		// TODO search for nearest BOULDER! 
		return null;
	}

}
