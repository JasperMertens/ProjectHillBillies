package hillbillies.model.factory.subclassesExpression;

import hillbillies.model.Log;
import hillbillies.model.Resource;
import hillbillies.model.Unit;
import hillbillies.model.factory.Expression;
import hillbillies.part3.programs.SourceLocation;

public class LogPosition extends Expression {

//	Unit.NearestResource<Resource> nearest = new Unit.NearestResource();
	public LogPosition(SourceLocation sourceLocation) {
		super(sourceLocation);
		// TODO Auto-generated constructor stub
	}

	public int[] execute(Unit unit) {
		Unit.NearestResource<Log> nearestResource = new Unit.NearestResource<>();
		Log log = new Log(null);
		nearestResource.getNearestResource(log);
		return null;
	}

}
