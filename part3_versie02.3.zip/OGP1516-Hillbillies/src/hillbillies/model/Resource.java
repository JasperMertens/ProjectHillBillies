package hillbillies.model;

import java.util.Random;
import java.util.Set;

/**
 * A class of Resources, with given position and World where they exist.
 * 
 * @version 2.0
 * @author Zeno Gillis, Jasper Mertens
 */
public abstract class Resource extends WorldObject{

	protected Resource(Vector position) {
		super(position);
		this.setRandomWeight();
	}
	
	/**
	 *
	 * Returns a set of it's current subclass from a set of Resources
	 */
	//filters resources to the wanted resources
	public abstract Set<? extends Resource> getAll(Set<Resource> set);
	
	private void setRandomWeight() {
		Random rand = new Random();
		int randomWeight = rand.nextInt(41) + 10;
		this.setWeight(randomWeight);
	}
	
	@Override
	public boolean canHaveAsPosition(Vector position, World world) {
		Cube cube = world.getCube(position.getRoundDown());
		return (super.canHaveAsPosition(position, world) && world.isAboveSolidGround(cube));
	}

	@Override
	protected boolean canFall() {
		Cube currentCube = this.getWorld().getCube(this.getCurrentCubeCoordinate());
		if (this.getWorld().isAboveSolidGround(currentCube))
			return false;
		return true;
	}

}
