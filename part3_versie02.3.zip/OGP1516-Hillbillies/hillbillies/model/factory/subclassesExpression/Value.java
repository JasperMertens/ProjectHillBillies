package hillbillies.model.factory.subclassesExpression;

import be.kuleuven.cs.som.annotate.*;
import hillbillies.model.factory.Expression;
import hillbillies.part3.programs.SourceLocation;

public class Value extends Expression {

	private Object value;
	
	public Value(Object value, SourceLocation sourceLocation){
		super(sourceLocation);
		this.value = value;
	}
	
	@Immutable
	public Object getValue() {
		return value;
	}

	@Override
	public Object execute() {
		// TODO Auto-generated method stub
		return null;
	}
}
