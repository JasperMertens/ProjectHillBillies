package hillbillies.model.factory.subclassesStatement;

import be.kuleuven.cs.som.annotate.*;
import hillbillies.model.Unit;
import hillbillies.model.factory.*;
import hillbillies.part3.programs.SourceLocation;
import ogp.framework.util.ModelException;

public class MoveTo extends Statement {

	private Expression position;

	public MoveTo(Expression position, SourceLocation sourceLocation) {
		super(sourceLocation);
		this.position = position;
	}
	@Immutable
	public Expression getPosition(){
		return this.position;
	}
	@Override
	public void execute(Unit unit) {
		try {
			this.getFacade().moveTo(unit, (int[])this.position.execute());
		} catch (ModelException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
