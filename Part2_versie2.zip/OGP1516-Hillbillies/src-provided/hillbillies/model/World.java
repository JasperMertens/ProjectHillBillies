package hillbillies.model;

import java.util.*;

import be.kuleuven.cs.som.annotate.*;
import hillbillies.part2.listener.TerrainChangeListener;

/**
 * A class of Worlds with given terrain types and configuration.
 *  
 * @invar A World shall never have more than 5 Factions.
 *  
 * @version 1.0
 * @author Zeno Gillis, Jasper Mertens
 *
 */
public class World {
	
	/**
	 * Constants for naming the different terrain types.
	 */
	static final int AIR = 0;
	static final int ROCK = 1;
	static final int TREE = 2;
	static final int WORKSHOP = 3;
	
	private int MAX_X;
	private int MAX_Y;
	private int MAX_Z;
	private final int MIN_X = 0;
	private final int MIN_Y = 0;
	private final int MIN_Z = 0;

	private Map<int[], Cube> worldMap;
	private Set<Faction> factionSet;
	private Set<Unit> unitSet;
	private Set<Boulder> boulderSet;
	private Set<Log> logSet;
	
	public World(int[][][] terrainTypes, TerrainChangeListener modelListener) throws IllegalArgumentException {
		this.factionSet = new HashSet<>();
		this.MAX_X = terrainTypes.length;
		this.MAX_Y = terrainTypes[0].length;
		this.MAX_Z = terrainTypes[0][0].length;
		Map<int[], Cube> myMap = new HashMap<int[], Cube>();
		for (int i=0; i < this.MAX_X; i++) {
			for (int j=0; j < this.MAX_Y; j++) {
				for (int k=0; k < this.MAX_Z; k++) {
					Cube newCube = new Cube(this, i, j, k, terrainTypes[i][j][k]);
					if (!this.isAboveSolidGround(newCube))
						newCube.setAboveSolidGround(false);
					int[] coordinates = new int[]{i,j,k};
					myMap.put(coordinates, newCube);
				}
			}
		}
		this.worldMap = myMap;
	}

	public boolean canHaveAsCube(int i, int j, int k, int terrain) {
		if ((i >= 0) && (j >= 0) && (k >= 0)
				&& (i < MAX_X) && (i < MAX_Y) && (i < MAX_Z)
				&& ((terrain == AIR) || (terrain == ROCK) || (terrain == TREE) || (terrain == WORKSHOP)))
			return true;
		return false;
	}
	
	/**
	 * Return whether the given Cube is above solid ground.
	 * 
	 * @param currentCube
	 * 			The Cube to check.
	 * @return	True if and only if the given Cube is at Z level 0 or if the Cube underneath this
	 * 			one is solid.
	 * 			|result == ((position.getZ() == 0) || cubeUnderCurrent.isSolid())
	 */
	public boolean isAboveSolidGround(Cube currentCube) {
		Vector position = currentCube.getPosition();
		if (position.getZ() == 0)
			return true;
		Vector oneZLevel = new Vector(0, 0, 1);
		Vector positionUnderCurrent = position.subtractVector(oneZLevel);
		Cube cubeUnderCurrent = this.getCube(positionUnderCurrent.getRoundDown());
		return cubeUnderCurrent.isSolid();
	}
	
	@Basic
	public int getNbCubesX() {
		return this.MAX_X;
	}
	
	@Basic
	public int getNbCubesY() {
		return this.MAX_Y;
	}
	
	@Basic
	public int getNbCubesZ() {
		return this.MAX_Z;
	}
	
	public Cube getCube(int[] coordinates) {
		return this.worldMap.get(coordinates);
	}
	
	public boolean containsCube(int[] coordinates) {
		return this.worldMap.containsKey(coordinates);
	}
	
	public int getCubeType(int[] coordinates) {
		return this.getCube(coordinates).getTerrainType();
	}
	
	public void setCubeType(int[] coordinates, int cubeType) {
		this.getCube(coordinates).setTerrainType(cubeType);
	}
	
	/**
	 * Create a new Faction with the given Unit in it.
	 * 
	 * @param firstUnit
	 * 			The Unit for the new Faction.
	 */
	public void createFaction(Unit firstUnit) {
		if (this.factionSet.size() < 5) {
			Faction newFaction = new Faction(this, firstUnit);
			this.factionSet.add(newFaction);
		}
	}
	
	public void removeFaction(Faction faction) {
		this.factionSet.remove(faction);
		faction = null;
	}
	
	@Raw
	public Set<Faction> getActiveFactions() {
		return this.factionSet;
	}
	
	public void addUnit(Unit unit) {
		if (this.unitSet.size() < 100) {
			this.unitSet.add(unit);
			if (this.factionSet.size() < 5) {
				this.createFaction(unit);
			}
			else 
				this.getSmallestFaction().addUnit(unit);
		}
	}
	
	public Faction getSmallestFaction() {
		Iterator<Faction> iter = this.factionSet.iterator();
		int smallestSoFar = iter.next().getNbOfUnits();
		Faction smallestFaction = iter.next();
		while (iter.hasNext()) {
			if (iter.next().getNbOfUnits() < smallestSoFar) {
				smallestSoFar = iter.next().getNbOfUnits();
				smallestFaction = iter.next();
			}
		}
		return smallestFaction;
	}
	
	public void removeUnit(Unit unit) {
		this.unitSet.remove(unit);
//		unit.getFaction().removeUnit(unit);
		unit = null;
	}
	
	@Raw
	public Set<Unit> getActiveUnits() {
		return this.unitSet;
	}
	
	public void createBoulder(Vector position) {
		Boulder newBoulder = new Boulder(this, position);
		this.boulderSet.add(newBoulder);
	}
	
	public void removeBoulder(Boulder boulder) {
		this.boulderSet.remove(boulder);
		boulder = null;
	}
	
	public void createLog(Vector position) {
		Log newLog = new Log(this, position);
		this.logSet.add(newLog);
	}
	
	public void removeLog(Log log) {
		this.logSet.remove(log);
		log = null;
	}
	
	/**
	 * Check whether the given coordinates are within the boundaries of this World.
	 * 
	 * @param x
	 * 			The given X-coordinate to check.
	 * @param y
	 * 			The given Y-coordinate to check.
	 * @param z
	 * 			The given Z-coordinate to check.
	 * @return	Returns true if and only if the coordinates are within the boundaries of this World.
	 * 			|return == ((x < this.MAX_X) && (y < this.MAX_Y) && (z < MAX_Z) &&
	 * 			|			(x >= MIN_X) && (y >= MIN_Y) && (z >= MIN_Z))
	 */
	public boolean isWithinWorld(double x, double y, double z) {
		if ((x < this.MAX_X) && (y < this.MAX_Y) && (z < MAX_Z) &&
				(x >= MIN_X) && (y >= MIN_Y) && (z >= MIN_Z))
			return true;
		else
			return false;
	}
	
	/**
	 * Return whether the given Cube is neighbouring a solid Cube.
	 * 
	 * @param givenCube
	 * 			The Cube to check.
	 * @return True if and only if at least one of the neighbouring Cubes is solid.
	 * 			| boolean bool = false
	 * 			| for (Cube neighbour : neighbours) {
				|	if (neighbour.isSolid())
				|		bool = true
				| }
				| result == bool
	 */
	public boolean isNearToSolid(Cube givenCube) {
		if (givenCube.getAboveSolidGround())
			return true;
		ArrayList<Cube> neighbours = givenCube.getNeighbouringCubes();
		for (Cube neighbour : neighbours) {
			if (neighbour.isSolid())
				return true;
		}
		return false;
	}
}
