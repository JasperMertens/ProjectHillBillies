package testpackage;

import java.lang.reflect.Array;
import java.util.*;
import be.kuleuven.cs.som.annotate.*;

// Niet vergeten | goed te zetten
/**
 * 
 * @invar The position of each Unit must be a valid position for any Unit. |
 *        isValidPosition(getPosition())
 * @invar The position of each Unit must be a valid position for any Unit. |
 *        isValidPosition(getPosition())
 * @invar The name of each Unit must be a valid name for any Unit. |
 *        isValidName(getName())
 * @invar The health of each Unit must be a valid health for any Unit. |
 *        isValidHealth(getHealth())
 * @invar The stamina of each Unit must be a valid stamina for any Unit. |
 *        isValidStamina(getStamina())
 * @invar The orientation of each Unit must be a valid orientation for any Unit.
 *        | isValidOrientation(getOrientation())
 * @invar Each Unit can have its targetPosition as targetPosition. |
 *        canHaveAsTargetPosition(this.getTargetPosition())
 * @invar The status of each Unit must be a valid status for any Unit. |
 *        isValidStatus(getStatus())
 * @invar The time of each Unit must be a valid time for any Unit. |
 *        isValidTime(getTime())
 *
 * 
 * @author Zeno, Jasper
 * @version 1.0
 * 
 */

public class Unit {

	/**
	 * Variable registering the position of this Unit.
	 */
	private double[] position;

	/**
	 * A list containing all Units.
	 */
	private static ArrayList<Unit> unitList = new ArrayList<>();

	private static ArrayList<String> legalStatus = new ArrayList<>();

	/**
	 * Constants marking the borders of the game world.
	 */
	private static final int MAX_X = 50;
	private static final int MIN_X = 0;
	private static final int MAX_Y = 50;
	private static final int MIN_Y = 0;
	private static final int MAX_Z = 50;
	private static final int MIN_Z = 0;
	private static final int cubeLength = 1;

	/**
	 * Variable registering the health of this Unit.
	 */
	private int health;
	/**
	 * Variable registering the stamina of this Unit.
	 */
	private int stamina;
	/**
	 * Variable registering the name of this Unit.
	 */
	private String name;
	/**
	 * Variable that multiplies the walking speed.
	 */
	private int sprint = 1;
	private boolean stopSprinting = false;
	/**
	 * Variable registering the velocity of this Unit.
	 */
	private double[] currentVelocity = new double[] { 0, 0, 0 };
	/**
	 * Variable registering the base velocity of this Unit. This may change when
	 * a Unit develops his strength and/or agility and/or weight.
	 */
	private double baseVelocity = 0.75 * (getStrength() + getAgility()) / (getWeight());
	private int weight;
	private int strength;
	private int agility;
	private int toughness;

	/**
	 * Variable registering the orientation of this Unit.
	 */
	private float orientation = (float) (Math.PI / 2);;

	private int MAX_CONDITION = (int) (200 * (getWeight() * getToughness() / 10000) + 1);
	private final int MAX_INIT_ATTR = 100;
	private final int MIN_INIT_ATTR = 25;

	private String status = "standing";
	private String effectiveStatus;
	/**
	 * Variable registering the time of this Unit.
	 */
	private static double time = 0;

	private boolean isMovingToAdjacent = false;
	private boolean isMovingTo;

	private boolean interrupted = false;

	/**
	 * Initialize this new Unit with given position.
	 *
	 * @param position
	 *            The position for this new Unit.
	 * @effect The position of this new Unit is set to the given position. |
	 *         this.setPosition(position)
	 * 
	 *         Initialize this new Unit with given health.
	 * 
	 * @param health
	 *            The health for this new Unit.
	 * @pre The given health must be a valid health for any Unit. |
	 *      isValidHealth(health)
	 * @post The health of this new Unit is equal to the given health. |
	 *       new.getHealth() == health
	 *
	 *
	 *       Initialize this new Unit with given stamina.
	 * 
	 * @param stamina
	 *            The stamina for this new Unit.
	 * @pre The given stamina must be a valid stamina for any Unit. |
	 *      isValidStamina(stamina)
	 * @post The stamina of this new Unit is equal to the given stamina. |
	 *       new.getStamina() == stamina Initialize this new Unit with given
	 *       name.
	 *
	 * @param name
	 *            The name for this new Unit.
	 * @effect The name of this new Unit is set to the given name. |
	 *         this.setName(name)
	 * 
	 *         Adds this Unit to a list of all Units.
	 * 
	 */
	// @Raw?
	public Unit(String name, int[] position, int weight, int agility, int strength, int toughness,
			boolean enableDefaultBehavior) throws IllegalArgumentException {

		double[] doublePosition = new double[] { position[0], position[1], position[2] };

		setPosition(doublePosition);
		setWeight(ConstrainAttribute(weight));
		setStrength(ConstrainAttribute(strength));
		setAgility(ConstrainAttribute(agility));
		setToughness(ConstrainAttribute(toughness));

		unitList.add(this);
		setLegalStatus();
	}

	/**
	 * Removes a Unit from the list of all Units.
	 */
	void kill() {
		unitList.remove(this);
	}

	/**
	 * Return the position of this Unit.
	 */
	@Basic
	@Raw
	public double[] getPositionUnit() {
		return Arrays.copyOf(position, position.length);
	}

	/**
	 * Check whether the given position is a valid position for any Unit.
	 * 
	 * @param position
	 *            The position to check.
	 * @return | result == (Array.getDouble(position, 0) < MAX_X) &&
	 *         (Array.getDouble(position, 1) < MAX_Y) &&
	 *         (Array.getDouble(position, 2) < MAX_Z) &&
	 *         (Array.getDouble(position, 0) >= MIN_X) &&
	 *         (Array.getDouble(position, 1) >= MIN_Y) &&
	 *         (Array.getDouble(position, 2) >= MIN_Z)
	 */
	public static boolean isValidPosition(double[] position) {
		if ((Array.getDouble(position, 0) < MAX_X) && (Array.getDouble(position, 1) < MAX_Y)
				&& (Array.getDouble(position, 2) < MAX_Z) && (Array.getDouble(position, 0) >= MIN_X)
				&& (Array.getDouble(position, 1) >= MIN_Y) && (Array.getDouble(position, 2) >= MIN_Z))
			return true;
		else
			return false;
	}

	/**
	 * Set the position of this Unit to the given position.
	 * 
	 * @param position
	 *            The new position for this Unit.
	 * @post The position of this new Unit is equal to the given position. |
	 *       new.getPosition() == position
	 * @throws Illegal
	 *             The given position is not a valid position for any Unit. | !
	 *             isValidPosition(getPosition())
	 */
	@Raw
	public void setPosition(double[] position) throws IllegalArgumentException {
		if (!isValidPosition(position))
			throw new IllegalArgumentException();
		this.position = Arrays.copyOf(position, position.length);
	}

	/**
	 * Return the position of the cube surrounding the given position.
	 * 
	 * @param position
	 * @return
	 */
	@Basic
	@Raw
	public static int[] getPositionCube(double[] position) {
		int[] roundedPosition = new int[3];
		for (int i = 0; i < position.length; i++) {
			roundedPosition[i] = (int) (position[i]);
		}
		return roundedPosition;
	}

	/**
	 * Return the position of the cube surrounding the Unit.
	 * 
	 * @return
	 */
	@Basic
	public int[] getCubeCoordinate() {
		int[] roundedPosition = new int[3];
		for (int i = 0; i < roundedPosition.length; i++) {
			roundedPosition[i] = (int) (getPositionUnit()[i]);
		}
		return roundedPosition;
	}

	private double[] getCentreCube(double[] positionInCube) {
		double xValueCube = getPositionCube(positionInCube)[0];
		double yValueCube = getPositionCube(positionInCube)[1];
		double zValueCube = getPositionCube(positionInCube)[2];

		double xCentreCube = (cubeLength / 2) + xValueCube;
		double yCentreCube = (cubeLength / 2) + yValueCube;
		double zCentreCube = (cubeLength / 2) + zValueCube;

		double[] centreCube = new double[] { xCentreCube, yCentreCube, zCentreCube };
		return centreCube;
	}

	/**
	 * Return the weight of this Unit.
	 */
	@Basic
	public int getWeight() {
		return this.weight;
	}

	// @effect gebruiken?
	/**
	 * Set the weight of this Unit to the given weight.
	 * 
	 * @param weight
	 *            The new weight for this Unit.
	 *
	 * @post If the given weight is a valid weight, the weight of this Unit is
	 *       equal to the given weight. | if (isValidWeight(weight)) | then
	 *       new.getWeight() == weight
	 * @post If the given weight is not a valid weight, the weight of this Unit
	 *       is set to the mean value of the strength and agility of this Unit.
	 *       | if (! isValidWeight(weight)) | then new.getWeight() ==
	 *       (this.strength + this.agility)/2
	 */
	@Basic
	public void setWeight(int weight) {
		if (!isValidWeight(weight))
			this.weight = (this.strength + this.agility) / 2;
		else
			this.weight = weight;
	}

	/**
	 * Return the given attribute, constrained to the legal initial values.
	 * 
	 * @param attribute
	 *            The new attribute for a Unit.
	 * @post If the given attribute exceeds the maximal initial value, the
	 *       attribute is set to the maximal initial value. |
	 *       if(attribute>MAX_INITIAL) | then return MAX_INITIAL ........
	 * @return
	 */
	// WAT ALS null?
	// Reden niet static: Hero.
	public int ConstrainAttribute(int attribute) {
		if (attribute < this.getMinInitAttr())
			return this.getMinInitAttr();
		if (attribute > this.getMaxInitAttr())
			return this.getMaxInitAttr();
		else
			return attribute;
	}

	public int getMinInitAttr() {
		return this.MIN_INIT_ATTR;
	}

	public int getMaxInitAttr() {
		return this.MAX_INIT_ATTR;
	}

	/**
	 * 
	 * @param weight
	 * @return
	 */
	private boolean isValidWeight(int weight) {
		if (weight >= (this.strength + this.agility) / 2)
			return true;
		else
			return false;
	}

	@Basic
	public int getStrength() {
		return this.strength;

	}

	@Basic
	public void setStrength(int strength) {
		this.strength = ConstrainAttribute(strength);
	}

	@Basic
	public int getAgility() {
		return this.agility;

	}

	@Basic
	public void setAgility(int agility) {

		this.agility = ConstrainAttribute(agility);
	}

	@Basic
	public int getToughness() {
		return this.toughness;
	}

	@Basic
	public void setToughness(int toughness) {

		this.toughness = ConstrainAttribute(toughness);
	}

	// NOMINAAL
	@Basic
	public int getMaxCondition() {
		return this.MAX_CONDITION;
	}

	/**
	 * Return the name of this Unit.
	 */
	@Basic
	@Raw
	public String getName() {
		return this.name;
	}

	/**
	 * Check whether the given name is a valid name for any Unit.
	 * 
	 * @param name
	 *            The name to check.
	 * @return | result ==
	 */
	public static boolean isValidName(String name) {
		if (Character.isUpperCase(name.charAt(0)) && (name.length() >= 2)) {

			for (int i = 0; i < name.length(); i++) {
				if ((!Character.isLetter(name.charAt(i))) && (!Character.isSpaceChar(name.charAt(i)))
						&& (name.charAt(i) != '\''))
					return false;
			}

			return true;
		}
		return false;

	}

	/**
	 * Set the name of this Unit to the given name.
	 * 
	 * @param name
	 *            The new name for this Unit.
	 * @post The name of this new Unit is equal to the given name. |
	 *       new.getName() == name
	 * @throws IllegalNameException
	 *             The given name is not a valid name for any Unit. | !
	 *             isValidName(getName())
	 */
	@Raw
	public void setName(String name) throws IllegalNameException {
		if (!isValidName(name))
			throw new IllegalNameException(name);
		this.name = name;
	}

	/**
	 * Return the health of this Unit.
	 */
	@Basic
	@Raw
	public int getHealth() {
		return this.health;
	}

	/**
	 * Check whether the given condition is a valid condition for any Unit.
	 * 
	 * @param condition
	 *            The condition to check.
	 * @return ..............
	 */
	@Basic
	public boolean isValidCondition(int condition) {
		if ((condition >= 0) && (condition <= this.getMaxCondition()))
			return true;
		else
			return false;
	}

	/**
	 * Set the health of this Unit to the given health.
	 * 
	 * @param health
	 *            The new health for this Unit.
	 * @pre The given health must be a valid health for any Unit. |
	 *      isValidHealth(health)
	 * @post The health of this Unit is equal to the given health. |
	 *       new.getHealth() == health
	 */
	@Basic
	@Raw
	public void setHealth(int health) {
		assert isValidCondition(health);
		this.health = health;
	}

	/**
	 * Return the stamina of this Unit.
	 */
	@Basic
	@Raw
	public int getStamina() {
		return this.stamina;
	}

	/**
	 * Set the stamina of this Unit to the given stamina.
	 * 
	 * @param stamina
	 *            The new stamina for this Unit.
	 * @pre The given stamina must be a valid stamina for any Unit. |
	 *      isValidStamina(stamina)
	 * @post The stamina of this Unit is equal to the given stamina. |
	 *       new.getStamina() == stamina
	 */
	@Raw
	public void setStamina(int stamina) {
		assert isValidCondition(stamina);
		this.stamina = stamina;
	}

	/**
	 * @invar The orientation of each Unit must be a valid orientation for any
	 *        Unit. | isValidOrientation(getOrientation())
	 */

	/**
	 * Return the orientation of this Unit.
	 */
	@Basic
	@Raw
	public float getOrientation() {
		return this.orientation;
	}

	/**
	 * Check whether the given orientation is a valid orientation for any Unit.
	 * 
	 * @param orientation
	 *            The orientation to check.
	 * @return | result ==
	 */
	public static boolean isValidOrientation(float orientation) {
		if (orientation <= 2 * Math.PI)
			return true;
		else
			return false;
	}

	/**
	 * Set the orientation of this Unit to the given orientation.
	 * 
	 * @param orientation
	 *            The new orientation for this Unit.
	 * @post If the given orientation is a valid orientation for any Unit, the
	 *       orientation of this new Unit is equal to the given orientation. |
	 *       if (isValidOrientation(orientation)) | then new.getOrientation() ==
	 *       orientation
	 */
	@Raw
	public void setOrientation(float orientation) {
		if (isValidOrientation(orientation))
			this.orientation = orientation;
		else
			this.orientation = (float) (orientation % (2 * Math.PI));
	}

	/**
	 * Return the time of this Unit.
	 */
	@Basic
	@Raw
	public static double getTime() {
		return time;
	}

	/**
	 * Check whether the given time is a valid time for any Unit.
	 * 
	 * @param time
	 *            The time to check.
	 * @return | result ==
	 */
	public static boolean isValidTime(double time) {
		if (time >= 0)
			return true;
		return false;
	}

	/**
	 * Set the time of this Unit to the given time.
	 * 
	 * @param time
	 *            The new time for this Unit.
	 * @post The time of this new Unit is equal to the given time. |
	 *       new.getTime() == time
	 * @throws IllegalArgumentException
	 *             The given time is not a valid time for any Unit. | !
	 *             isValidTime(getTime())
	 */
	@Raw
	public static void setTime(double givenTime) throws IllegalArgumentException {
		if (!isValidTime(givenTime))
			throw new IllegalArgumentException();
		time = givenTime;
	}

	/**
	 * Update the status and the position of a unit, advance the time of the
	 * game world by a given amount .
	 * 
	 * @param time
	 * 
	 */
	public void advanceTime(Unit unit, double time) {
		if (unit.effectiveStatus != unit.getStatus()) {
			updateEffectiveStatus(unit);
		}
		if (unit.effectiveStatus == "moving") {
			if (this.sprint == 2) {
				unit.setStamina((int) (unit.getStamina() - (time * 10)));
			}
			updatePosition(unit, time);
			updateOrientation(unit);
		}
		if ((unit.effectiveStatus == "attacking") || (unit.effectiveStatus == "attacking")) {
			updateOrientation(unit);

		}
		setTime(getTime() + time);
	}

	private void updateOrientation(Unit unit) {
		double xVelocity = unit.getCurrentVelocity()[0];
		double yVelocity = unit.getCurrentVelocity()[1];
		float orientation = (float) (Math.atan2(yVelocity, xVelocity));

		unit.setOrientation(orientation);
	}

	private void updateEffectiveStatus(Unit unit) {
		unit.effectiveStatus = unit.getStatus();
	}

	/**
	 * 
	 * @param unit
	 * @param time
	 */
	private void updatePosition(Unit unit, double time) {

		double xValueNow = unit.getPositionUnit()[0];
		double yValueNow = unit.getPositionUnit()[1];
		double zValueNow = unit.getPositionUnit()[2];

		double xVelocity = unit.getCurrentVelocity()[0];
		double yVelocity = unit.getCurrentVelocity()[1];
		double zVelocity = unit.getCurrentVelocity()[2];

		double[] newPosition = new double[] { xValueNow + xVelocity * time, yValueNow + yVelocity * time,
				zValueNow + zVelocity * time };

		unit.setPosition(newPosition);
	}

	/**
	 * Return the base velocity of this Unit.
	 */
	@Basic
	@Raw
	public double getBaseVelocity() {
		return this.baseVelocity;
	}

	public void startSprint() {
		this.stopSprinting = false;
		while ((this.status == "moving") && (this.stamina > 0) && (!this.stopSprinting)) {
			this.sprint = 2;
		}
		stopSprint();
	}

	public void stopSprint() {
		this.sprint = 1;
		this.stopSprinting = true;
	}

	/**
	 * Return the currentVelocity of this Unit.
	 */
	@Basic
	@Raw
	public double[] getCurrentVelocity() {
		return new double[] { currentVelocity[0], currentVelocity[1], currentVelocity[2] };
	}

	/**
	 * Set the currentVelocity of this Unit to the given currentVelocity.
	 * 
	 * @param currentVelocity
	 *            The new currentVelocity for this Unit.
	 * @post The currentVelocity of this new Unit is equal to the given
	 *       currentVelocity. | new.getCurrentVelocity() == currentVelocity
	 * @throws IllegalArgumentException
	 *             The given adjacentPosition is not a valid adjacentPosition
	 *             for any Unit. | !
	 *             canHaveAsAdjacentPosition(adjacentPosition))
	 */
	@Raw
	public void setCurrentVelocity(double[] currentVelocity, double[] adjacentPosition) {
		double TempDistance = Math.sqrt(Math.pow((adjacentPosition[0] - getPositionUnit()[0]), 2)
				+ Math.pow((adjacentPosition[1] - getPositionUnit()[1]), 2)
				+ Math.pow((adjacentPosition[2] - getPositionUnit()[2]), 2));

		double Tempcte;
		if (this.getPositionUnit()[2] - adjacentPosition[2] == -1)
			Tempcte = 0.5;
		else if (this.getPositionUnit()[2] - adjacentPosition[2] == 1)
			Tempcte = 1.2;
		else
			Tempcte = 1;
		this.currentVelocity = new double[] {
				((Tempcte / TempDistance) * this.sprint * (adjacentPosition[0] - getPositionUnit()[0])),
				((Tempcte / TempDistance) * this.sprint * (adjacentPosition[1] - getPositionUnit()[1])),
				((Tempcte / TempDistance) * this.sprint * (adjacentPosition[2] - getPositionUnit()[2])) };
	}

	/**
	 * Check whether this Unit can have the given targetPosition as its
	 * targetPosition.
	 * 
	 * @param adjacentPosition
	 *            The targetPosition to check.
	 * @return | result == ((isValidPosition(adjacentPosition)) &&
	 *         (Math.abs((xValueAdj - xValueCube)) == 1) && (Math.abs((yValueAdj
	 *         - yValueCube)) == 1) && (Math.abs((zValueAdj - zValueCube)) ==
	 *         1))
	 */
	@Raw
	public boolean canHaveAsAdjacentPosition(double[] adjacentPosition) {

		int xValueAdj = getPositionCube(adjacentPosition)[0];
		int yValueAdj = getPositionCube(adjacentPosition)[1];
		int zValueAdj = getPositionCube(adjacentPosition)[2];
		int xValueUnitCube = getPositionCube(getPositionUnit())[0];
		int yValueUnitCube = getPositionCube(getPositionUnit())[1];
		int zValueUnitCube = getPositionCube(getPositionUnit())[2];

		if ((isValidPosition(adjacentPosition)) && (Math.abs((xValueAdj - xValueUnitCube)) == 1)
				&& (Math.abs((yValueAdj - yValueUnitCube)) == 1) && (Math.abs((zValueAdj - zValueUnitCube)) == 1))
			return true;
		else
			return false;
	}

	/**
	 * 
	 * @param unit
	 * @param dx
	 * @param dy
	 * @param dz
	 * @throws IllegalArgumentException
	 */
	public void moveToAdjacent(Unit unit, int dx, int dy, int dz) throws IllegalArgumentException {

		if (!unit.getIsMovingToAdjacent() && ((dx != 0) || (dy != 0) || (dz != 0))) {
			double[] adjacentPosition = new double[] { unit.getPositionUnit()[0] + dx, unit.getPositionUnit()[1] + dy,
					unit.getPositionUnit()[2] + dz };
			double[] currentPosition = unit.getPositionUnit();

			unit.setIsMovingToAdjacent(true);

			if (!canHaveAsAdjacentPosition(adjacentPosition)) {
				throw new IllegalArgumentException();
			}
			double[] centreCube = new double[3];

			if (getCentreCube(adjacentPosition) != adjacentPosition) {
				centreCube = getCentreCube(adjacentPosition);
			} else if (getCentreCube(adjacentPosition) == adjacentPosition) {
				centreCube = adjacentPosition;
			}
			while ((!hasArrived(currentPosition, centreCube)) && (getStatus() != "attacked")) {
				if (unit.getStatus() != "moving") {
					unit.setStatus("moving");
					unit.setCurrentVelocity(unit.currentVelocity, adjacentPosition);
				}
			}
			if (unit.getStatus() != "attacked") {
				unit.setPosition(centreCube);
				unit.setStatus("standing");
				unit.currentVelocity = new double[] { 0, 0, 0 };
				unit.setIsMovingToAdjacent(false);
			}
		}
	}

	/**
	 * Returns whether the Unit is moving to an Adjacent cube.
	 * 
	 * @return |this.isMovingToAdjacent
	 */
	public boolean getIsMovingToAdjacent() {
		return this.isMovingToAdjacent;
	}

	/**
	 * Set the variable isMovingToAdjacent to the given boolean.
	 * 
	 * @param bool
	 * @post The variable isMovingToAdjacent is equal to the given boolean
	 *       |new.getIsMovingToAdjacent() == bool
	 */
	public void setIsMovingToAdjacent(boolean bool) {
		this.isMovingToAdjacent = bool;
	}

	public void moveTo(Unit unit, int[] targetPosition) throws IllegalArgumentException {
		double[] doubleTargetPosition = new double[] { targetPosition[0], targetPosition[1], targetPosition[2] };
		if (!isValidPosition(doubleTargetPosition)) {
			throw new IllegalArgumentException();
		}
		int xValueTargetCube = getPositionCube(doubleTargetPosition)[0];
		int yValueTargetCube = getPositionCube(doubleTargetPosition)[1];
		int zValueTargetCube = getPositionCube(doubleTargetPosition)[2];

		int xValueUnitCube = getCubeCoordinate()[0];
		int yValueUnitCube = getCubeCoordinate()[1];
		int zValueUnitCube = getCubeCoordinate()[2];

		int x;
		int y;
		int z;

		while ((getCubeCoordinate() != getPositionCube(doubleTargetPosition))
				&& (!unit.getInterrupted())) {
			if (xValueUnitCube == xValueTargetCube) {
				x = 0;
			} else if (xValueUnitCube < xValueTargetCube) {
				x = 1;
			}

			else {
				x = -1;
			}
			if (yValueUnitCube == yValueTargetCube) {
				y = 0;
			} else if (yValueUnitCube < yValueTargetCube) {
				y = 1;
			}

			else {
				y = -1;
			}
			if (zValueUnitCube == zValueTargetCube) {
				z = 0;
			} else if (zValueUnitCube < zValueTargetCube) {
				z = 1;
			}

			else {
				z = -1;
			}
			moveToAdjacent(unit, x, y, z);
		}

	}

	private boolean getInterrupted() {
		return this.interrupted ;
	}
	
	private void setInterrupted(boolean bool){
		this.interrupted = bool;
	}
	private boolean hasArrived(double[] previousPosition, double[] targetPosition) {
		double xDistancePrevToTarget = Math.pow((previousPosition[0] - targetPosition[0]), 2);
		double yDistancePrevToTarget = Math.pow((previousPosition[1] - targetPosition[1]), 2);
		double zDistancePrevToTarget = Math.pow((previousPosition[2] - targetPosition[2]), 2);

		double xDistancePrevToUnit = Math.pow((previousPosition[0] - this.getPositionUnit()[0]), 2);
		double yDistancePrevToUnit = Math.pow((previousPosition[1] - this.getPositionUnit()[1]), 2);
		double zDistancePrevToUnit = Math.pow((previousPosition[2] - this.getPositionUnit()[2]), 2);

		if ((xDistancePrevToUnit + yDistancePrevToUnit + zDistancePrevToUnit) >= (xDistancePrevToTarget
				+ yDistancePrevToTarget + zDistancePrevToTarget))
			return true;
		return false;
	}

	/**
	 * Return the status of this Unit.
	 */
	@Basic
	@Raw
	public String getStatus() {
		return this.status;
	}

	/**
	 * Check whether the given status is a valid status for any Unit.
	 * 
	 * @param status
	 *            The status to check.
	 * @return | result ==
	 */
	public static boolean isValidStatus(String status) {
		if (legalStatus.contains(status))
			return true;
		return false;
	}

	/**
	 * Set the status of this Unit to the given status.
	 * 
	 * @param status
	 *            The new status for this Unit.
	 * @post The status of this new Unit is equal to the given status. |
	 *       new.getStatus() == status
	 * @throws IllegalArgumentException
	 *             The given status is not a valid status for any Unit. | !
	 *             isValidStatus(getStatus())
	 */
	@Raw
	public void setStatus(String status) throws IllegalArgumentException {
		if (!isValidStatus(status))
			throw new IllegalArgumentException();
		this.status = status;
	}

	private void setLegalStatus() {
		legalStatus.add("standing");
		legalStatus.add("resting");
		legalStatus.add("moving");
		legalStatus.add("attacking");
		legalStatus.add("working");
		legalStatus.add("attacked");
	}

	public boolean isWorking() {
		return this.effectiveStatus == "working";

	}

	public boolean isAttacking() {
		return this.effectiveStatus == "attacking";

	}

	public boolean isAttacked() {
		return this.effectiveStatus == "attacked";

	}

	public boolean isResting() {
		return this.effectiveStatus == "resting";

	}

	public boolean isMoving() {
		return this.effectiveStatus == "moving";

	}

}
