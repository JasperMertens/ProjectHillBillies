package testpackage;

import java.util.ArrayList;

public class Documentation {

	// INVAR DOCUMENTATION
	/**
	 * @invar  The name of each Unit must be a valid name for any Unit.
	 *       | isValidName(getName())
	 *       
	 * @invar The position of each Unit must be a valid position for any Unit. 
	 * 		 | isValidPositionUnit(getPositionUnit())
	 *
	 *@invar  The defaultBehavior of each Unit must be a valid defaultBehavior for any Unit.
	 *       | isValidDefaultBehavior(getDefaultBehavior())
	 * 
	 */

	// CONSTRUCTOR DOCUMENTATION
	/**
	 * ---POSITIONS ARE DEFENSIVE--- 
	 *        Initialize this new Unit with given position.
	 *
	 * @param position
	 *            The position for this new Unit.
	 * @effect The position of this new Unit is set to the given position. |
	 *         this.setPositionUnit(position) 
	 *         
	 *         
	 * ---ATTRIBUTES ARE TOTAL---
	 *         
	 *       Initialize this new Unit with given weight.
	 * 
	 * @param weight
	 *            The weight for this new Unit.
	 * @post If the given weight is a valid weight for any Unit, the weight of
	 *       this new Unit is equal to the given weight. Otherwise, if the
	 *       weight of this new Unit is less than 25, the weight of this new
	 *       Unit is equal to 25 or if the weight of this new Unit is greater
	 *       than 100, the weight of this new Unit is equal to 100 |
	 *       if(isValidWeight(propertyName_Java)) | then new.getWeight() ==
	 *       propertyName_Java | else if weight < 25 | then new.getWeight() ==
	 *       25 | else if weight > 100 | then new.getWeight() == 100
	 * 
	 *       Initialize this new Unit with given strength.
	 * 
	 * @param strength
	 *            The strength for this new Unit.
	 * @post If the given strength is a valid strength for any Unit, the
	 *       strength of this new Unit is equal to the given strength.
	 *       Otherwise, if the strength of this new Unit is less than 25, the
	 *       strength of this new Unit is equal to 25 or if the strength of this
	 *       new Unit is greater than 100, the strength of this new Unit is
	 *       equal to 100 | if(isValidstrength(propertyName_Java)) | then
	 *       new.getStrength() == propertyName_Java | else if strength < 25 |
	 *       then new.getStrength() == 25 | else if strength > 100 | then
	 *       new.getStrength() == 100
	 * 
	 *       Initialize this new Unit with given agility.
	 * 
	 * @param agility
	 *            The agility for this new Unit.
	 * @post If the given agility is a valid agility for any Unit, the agility
	 *       of this new Unit is equal to the given agility. Otherwise, if the
	 *       agility of this new Unit is less than 25, the agility of this new
	 *       Unit is equal to 25 or if the agility of this new Unit is greater
	 *       than 100, the agility of this new Unit is equal to 100 |
	 *       if(isValidAgility(propertyName_Java)) | then new.getAgility() ==
	 *       propertyName_Java | else if Agility < 25 | then new.getAgility() ==
	 *       25 | else if Agility > 100 | then new.getAgility() == 100
	 * 
	 *       Initialize this new Unit with given toughness.
	 * 
	 * @param toughness
	 *            The toughness for this new Unit.
	 * @post If the given toughness is a valid toughness for any Unit, the
	 *       toughness of this new Unit is equal to the given toughness.
	 *       Otherwise, if the toughness of this new Unit is less than 25, the
	 *       toughness of this new Unit is equal to 25 or if the toughness of
	 *       this new Unit is greater than 100, the toughness of this new Unit
	 *       is equal to 100 | if(isValidToughness(propertyName_Java)) | then
	 *       new.getToughness() == propertyName_Java | else if Toughness < 25 |
	 *       then new.getToughness() == 25 | else if Toughness > 100 | then
	 *       new.getToughness() == 100
	 * 
	 * 		
	 * 		Add legal statuses to a list for this new Unit.
	 * 
	 * @post All legal statuses for a new Unit are listed in a variable list
	 * 		 legalStatusses
	 * 		| new.legalStatusses() = ArrayList("standing","attacking","attacked",
	 * 		|									"working","moving","resting")
	 * 
	 * 		Initialize this new Unit with orientation PI/2.
	 * @post The orientation for this new Unit equals PI/2.
	 * 		| new.orientation = (float) (Math.PI/2)
	 *		
	 *		Initialize this new Unit with given default behavior.
	 *
	 * @post If the given default behavior is a valid behavior for any Unit, the
	 * 		 default behavior is equal to the given default behavior.
	 * 		 Else 
	 * 
	 * Initialize this new Unit with given defaultBehavior.
	 *
	 * @param  defaultBehavior
	 *         The defaultBehavior for this new Unit.
	 * @effect The defaultBehavior of this new Unit is set to
	 *         the given defaultBehavior.
	 *       | this.setDefaultBehavior(defaultBehavior)
	 *
	 */

// IN UNIT CONSTRUCTOR
// this.defaultBehaviorEnabled = enableDefaultbehavior;
	
	
	private static ArrayList<String> defaultBehavior = new ArrayList<>();
	private void setDefaultBehavior() {
		defaultBehavior.add("moveToRandom");
		defaultBehavior.add("startSprinting");
		defaultBehavior.add("resting");
		defaultBehavior.add("working");
		
	}


	/**
	 * Return if the default behavior of this Unit is enabled.
	 */
	@Basic @Raw
	public boolean isDefaultBehaviorEnabled() {
		return this.defaultBehaviorEnabled;
	}

	/**
	 * Check whether the given defaultBehavior is a valid defaultBehavior for
	 * any Unit.
	 *  
	 * @param  defaultBehavior
	 *         The defaultBehavior to check.
	 * @return 
	 *       | result == 
	*/
	public static boolean isValidDefaultBehavior(boolean defaultBehavior) {
		return false;
	}

	/**
	 * Set the defaultBehavior of this Unit to the given defaultBehavior.
	 * 
	 * @param  defaultBehavior
	 *         The new defaultBehavior for this Unit.
	 * @post   The defaultBehavior of this new Unit is equal to
	 *         the given defaultBehavior.
	 *       | new.getDefaultBehavior() == defaultBehavior
	 * @throws IllegalArgumentException
	 *         The given defaultBehavior is not a valid defaultBehavior for any
	 *         Unit.
	 *       | ! isValidDefaultBehavior(getDefaultBehavior())
	 */
	@Raw
	public void setDefaultBehavior(boolean defaultBehavior) 
			throws IllegalArgumentException {
		if (! isValidDefaultBehavior(defaultBehavior))
			throw new IllegalArgumentException();
		this.defaultBehavior = defaultBehavior;
	}

	/**
	 * Variable registering the defaultBehavior of this Unit.
	 */
	private boolean defaultBehaviorEnabled;

	}	
}