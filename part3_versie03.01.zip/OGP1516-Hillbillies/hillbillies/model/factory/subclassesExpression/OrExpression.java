package hillbillies.model.factory.subclassesExpression;

import hillbillies.model.factory.Expression;
import hillbillies.part3.programs.SourceLocation;

public class OrExpression extends Expression {


	private Expression left;
	private Expression right;

	public OrExpression(Expression left, Expression right, SourceLocation sourceLocation) {
		super(sourceLocation);
		this.left = left;
		this.right = right;
	}
	
	public boolean execute(){
		if ((TrueExpression.class.isInstance(this.left)) || (TrueExpression.class.isInstance(this.right)))
			return true;
		else
			return false;
	}
}
