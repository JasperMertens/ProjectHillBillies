package hillbillies.model.factory.subclassesExpression;

import be.kuleuven.cs.som.annotate.*;
import hillbillies.model.factory.Expression;
import hillbillies.part3.programs.SourceLocation;

public class Value<T> extends Expression<Object, T> {

	private Object value;
	
	public Value(Object value, SourceLocation sourceLocation){
		super(sourceLocation);
		this.value = value;
	}
	
	@Immutable
	public Object getValue() {
		return value;
	}

	@Override
	public Object execute(T t) {
		// TODO Auto-generated method stub
		return null;
	}
}
