package hillbillies.model.factory.subclassesExpression.positionExpression;

import hillbillies.model.Cube;
import hillbillies.model.Unit;
import hillbillies.model.factory.Expression;
import hillbillies.part3.programs.SourceLocation;

public class WorkshopPosition extends Expression<int[]> {

	public WorkshopPosition(SourceLocation sourceLocation) {
		super(sourceLocation);
	}

	@Override
	public int[] execute(Unit unit) {
		Cube workshop = unit.getWorld().getNearestWorkshop(unit.getVectorPosition());
		return workshop.getCoordinates();
	}

}
