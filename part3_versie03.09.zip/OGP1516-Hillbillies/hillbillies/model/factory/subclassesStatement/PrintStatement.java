package hillbillies.model.factory.subclassesStatement;

import hillbillies.model.Unit;
import hillbillies.model.factory.Expression;
import hillbillies.model.factory.Statement;
import hillbillies.part3.programs.SourceLocation;

public class PrintStatement extends Statement {

	private Expression<Number> value;

	public PrintStatement(Expression<Number> value, SourceLocation sourceLocation) {
		super(sourceLocation);
		this.value = value;
	}

	@Override
	public void execute(Unit unit) {
		System.out.println(this.value);
	}

	@Override
	public Statement getNext(Unit unit) {
		return null;
	}

}
