package hillbillies.model.factory.subclassesStatement;

import hillbillies.model.Unit;
import hillbillies.model.factory.*;
import hillbillies.part3.programs.SourceLocation;

public class Assignment<T> extends Statement {
	
	private String variableName;
	private Expression<T> value;

	public Assignment(String variableName, Expression<T> value, SourceLocation sourceLocation){
		super(sourceLocation);
		this.variableName = variableName; 
		this.value = value; 
	}
	
	@Override
	public void execute(Unit unit) throws IllegalArgumentException{
		Unit.Variable<T> variable = unit.new Variable<>();
		variable.addVariable(variableName, value);
	}

	@Override
	public Statement getNext(Unit unit) {
		return null;
	}
	
}
