package hillbillies.model.factory.subclassesExpression.positionExpression;

import hillbillies.model.Cube;
import hillbillies.model.Unit;
import hillbillies.model.factory.Expression;
import hillbillies.part3.programs.SourceLocation;

public class WorkshopPosition extends Expression<int[]> {

	public WorkshopPosition(SourceLocation sourceLocation) {
		super(sourceLocation);
	}

	@Override
	public int[] execute(Unit unit) {
		System.out.println("searchon workshop");
		Cube workshop = unit.getWorld().getNearestWorkshop(unit.getVectorPosition());
		System.out.println("Execute workshop: " + workshop);
		return workshop.getCoordinates();
	}
}
