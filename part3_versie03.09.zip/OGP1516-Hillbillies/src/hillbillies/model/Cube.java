package hillbillies.model;

import java.util.*;

import be.kuleuven.cs.som.annotate.*;

/**
 * A class of Cubes that exist in a World, with a position and a terrain type.
 * 
 * @invar The position and terrain type of each Cube must be a valid
 *          position and terrain type for a Cube in respect to its World.
 *        | World.isValidCube()
 * 
 * @version 1.0
 * @author Zeno Gillis, Jasper Mertens
 *
 */
public class Cube {
	
	/**
	 * Constants for naming the different terrain types.
	 */
	static final int AIR = 0;
	static final int ROCK = 1;
	static final int TREE = 2;
	static final int WORKSHOP = 3;
	
	/**
	 * Constants containing the value of the X-, Y- and Z-coordinates of the Cube respectively.
	 */
	private final int X;
	private final int Y;
	private final int Z;
	
	/**
	 * A constant registering the World in which this Cube exists.
	 */
	private final World world;
	
	/**
	 * A variable registering the type of terrain for this Cube.
	 */
	private int terrainType = AIR;
	
	/**
	 * A constant defining the length of this Cube.
	 */
	private static final double cubeLength = 1.0;
	
	private ArrayList<Resource> resourceList = new ArrayList<>();
	
	/**
	 * Initialize a new Cube with given coordinates and terrain type and the World where it exists.
	 * 
	 * @param world
	 * 			The World in where this Cube exists.
	 * @param x
	 * 			The X-coordinate for this Cube.
	 * @param y
	 * 			The Y-coordinate for this Cube.
	 * @param z
	 * 			The Z-coordinate for this Cube.
	 * @param terrainType
	 * 			The type of terrain for this Cube.
	 * @post   The X-coordinate of this new Cube is equal to
	 *		   the given x.
	 *       | new.X == x;
	 * @post   The Y-coordinate of this new Cube is equal to
	 *		   the given y.
	 *       | new.X == x;
	 * @post   The Z-coordinate of this new Cube is equal to
	 *		   the given z.
	 *       | new.Z == z;
	 * @post   The terrain type of this new Cube is equal to
	 *		   the given terrain type.
	 *       | new.terrainType == terrainType;
	 * @throws NullPointerException
	 * 			The given World is not an effective World.
	 * 			| world == null
	 * @throws IllegalArgumentException
	 * 			The given arguments for a Cube are not valid arguments for a Cube in the given World.
	 * 			| ! world.isValidCube(x, y, z, terrainType)
	 */
	public Cube(World world, int x, int y, int z, int terrainType) 
			throws NullPointerException, IllegalArgumentException {
		if (!world.canHaveAsCube(x, y, z, terrainType))
			throw new IllegalArgumentException();
		this.world = world;
		this.X = x;
		this.Y = y;
		this.Z = z;
		this.terrainType = terrainType;
		if (!isSolidTerrain(terrainType))
			this.world.getConnectedToBorder().changeSolidToPassable(this.X, this.Y, this.Z);
	}
	
	/**
	 * Return the coordinates of this Cube as an array of integers.
	 * @return
	 * 			|result == new int[]{this.X, this.Y, this.Z};
	 */
	@Immutable @Raw
	public int[] getCoordinates() {
		int[] intList = new int[]{this.X, this.Y, this.Z};
		return intList;
	}
	
	/**
	 * Return the position of this Cube as a Vector.
	 * @return
	 */
	@Immutable @Raw
	public Vector getPosition() {
		Vector vectorPosition = new Vector(this.X, this.Y, this.Z);
		return vectorPosition;
	}
	
	@Immutable @Raw
	public String getStringPosition() {
		String coordinates = "x" + this.X + "y" + this.Y + "z" + this.Z;
		return coordinates;
	}
	
	/**
	 * Return the center of this Cube.
	 * 
	 * @return The center of this Cube as a Vector.
	 * 			|result == centreCube;
	 */
	@Basic
	public Vector getCentreCube() {
		Vector toCentre = new Vector((cubeLength / 2),(cubeLength / 2),(cubeLength / 2));
		Vector centreCube = this.getPosition().addVector(toCentre);
		return centreCube;
	}
	
	/**
	 * Set the terrain type of this Cube to the given terrain type and update the GUI if needed.
	 * 
	 * @param terrainType
	 * 			The new terrain type for this Cube.
	 */
	@Raw
	public void setTerrainType(int terrainType) {
		if (terrainType != this.getTerrainType()) {
			if (this.isSolid() && !isSolidTerrain(terrainType)) {
				List<int[]> toBeCollapsed = this.world.getConnectedToBorder().changeSolidToPassable(this.X, this.Y, this.Z);
				for (int[] coordinates : toBeCollapsed) {
					this.world.getCube(coordinates).collapse();
				}
			}
			else if (!this.isSolid() && isSolidTerrain(terrainType))
				this.world.getConnectedToBorder().changePassableToSolid(this.X, this.Y, this.Z);
			this.terrainType = terrainType;
			this.world.getModelListener().notifyTerrainChanged(this.X, this.Y, this.Z);
		}
	}
	
	/**
	 * Return the type of terrain for this Cube.
	 * @return
	 */
	@Basic @Raw
	public int getTerrainType() {
		return this.terrainType;
	}
	
	/**
	 * Return whether the given terrain is solid terrain.
	 * 
	 * @param terrain
	 * 		| The terrain to check.
	 * @return	True if and only if the type of terrain is ROCK or TREE.
	 * 		| result == (terrain == ROCK) || (terrain == TREE)
	 */
	public static boolean isSolidTerrain(int terrain) {
		return ((terrain == ROCK) || (terrain == TREE));
	}
	
	/**
	 * Return whether this Cube is solid.
	 * @effect Return true if the terrain type of this Cube is solid.
	 * 		| isSolidTerrain(this.getTerrainType())
	 */
	public boolean isSolid() {
		return isSolidTerrain(this.getTerrainType());
	}
	
	/**
	 * Let this Cube collapse with a chance to spawn a Resource according to its current terrain type.
	 * 
	 * @throws IllegalStateException
	 */
	public void collapse() throws IllegalStateException{
		if (!this.isSolid())
			throw new IllegalStateException();			
		int terrain = this.getTerrainType();
		this.setTerrainType(AIR);
		Random rand = new Random();
		int random = rand.nextInt(4);
		if (random == 0) {
			if (terrain == TREE)
				this.world.spawnLog(this);
			if (terrain == ROCK)
				this.world.spawnBoulder(this);
		}
	}
	
	/**
	 * Return all the neighbouring Cubes (excluding this Cube) of this Cube as an array of Cubes.
	 * 
	 * @return	An array of Cubes, containing all the cubes that exist in the World of this Cube
	 * 			and that neighbour this Cube.
	 * 			| for (other_Cube : all_Cubes) {
	 * 			|	if ((other_Cube.X == this_Cube.X � 1) ||
	 * 			|		(other_Cube.Y == this_Cube.Y � 1) ||
	 * 			|		(other_Cube.Z == this_Cube.Z � 1))
	 * 			|		cubeList.add(other_Cube);
	 * 			| result == cubeList;
	 */
	public ArrayList<Cube> getNeighbouringCubes() {
		ArrayList<Cube> cubeList = new ArrayList<>();
		Vector cubePosition = this.getPosition();
		for (int i=-1; i<2; i++) {
			for (int j=-1; j<2; j++) {
				for (int k=-1; k<2; k++) {
					Vector vectorTerm = new Vector(i, j, k);
					Vector vectorResult = cubePosition.addVector(vectorTerm);
					int[] coordinates = vectorResult.getRoundDown();
					if ((this.world.containsCube(coordinates[0], coordinates[1], coordinates[2]))
							&& (i!=0 || j!=0 || k!=0)) {
						Cube neighbour = this.world.getCube(coordinates);
						cubeList.add(neighbour);
					}
				}
			}
		}
		return cubeList;
	}
	
	
	/**
	 * Returns whether the given cube is equal to the current Cube or not.
	 * @param cube
	 * 
	 * @return True if the coordinates of the given cube are equal to the coordinates of the current Cube,
	 *  		false otherwise
	 *  		| if (Arrays.equals(this.getCoordinates(), cube.getCoordinates()))
	 *  		|	then result == true;
	 *  		| else result == false;
	 */
	public boolean isEqualTo(Cube cube){
		int[] currentCube = this.getCoordinates();
		int[] cubeToCheck = cube.getCoordinates();
		if (Arrays.equals(currentCube, cubeToCheck))
			return true;
		return false;
		
	}
	
	/**
	 * Returns whether the given list of cubes contains this Cube. 
	 * 
	 * @param cubeList
	 * 			The cubeList to check.
	 * @return True if this Cube is a part of the list of cubes, 
	 * 			false otherwise.
	 * 			| if (cubeList.contains(this))
	 * 			| 	then result == true;
	 * 			| else result == false;
	 */
	public boolean containsCube(ArrayList<Cube> cubeList){
		for (Cube cube : cubeList) {
			if (this.isEqualTo(cube)){
				return true;
			}
		} 
		return false;
	}
	
	/**
	 * Add the given Resource to this Cube.
	 * 
	 * @param resource
	 * 		The Resource to add.
	 * @post The given Resource is added to the end of the list of all Resources in this Cube.
	 * 		| new.resourceList.get(new.resourceList.size - 1) == resource
	 */
	public void addResource(Resource resource) {
		this.resourceList.add(resource);
	}
	
	/**
	 * Remove the given Resource from this Cube.
	 * 
	 * @param resource
	 * 		The Resource to remove.
	 * @post The given Resource is removed from the list of all Resources in this Cube.
	 * 		| new.resourceList == old.resourceList.remove(resource)
	 */
	public void removeResource(Resource resource) {
		this.resourceList.remove(resource);
	}
	
	/**
	 * Check whether this Cube contains a Resource.
	 * 
	 * @return True if and only if there's at least one Resource in this Cube.
	 * 		| result == !this.resourceSet.isEmpty()
	 */
	public boolean containsResource() {
		return (!this.resourceList.isEmpty());
	}
	
	/**
	 * Check whether there's a Log within this Cube.
	 * 
	 * @return True if and only if there's at least one Log in this Cube.
	 * 		| result == (there exists an element of this.resourceList
	 * 		| 			where element.getClass() == Log.class)
	 */
	public boolean containsLog() {
		if (this.containsResource()) {
			for (Resource resource : this.resourceList) {
				if (resource.getClass() == Log.class)
					return true;
			}
		}
		return false;
	}
	
	/**
	 * Check whether there's a Boulder within this Cube.
	 * 
	 * @return True if and only if there's at least one Boulder in this Cube.
	 * 		| result == (there exists an element of this.resourceList
	 * 		| 			where element.getClass() == Boulder.class)
	 */
	public boolean containsBoulder() {
		if (this.containsResource()) {
			System.out.println("contains resource");
			for (Resource resource : this.resourceList) {
				if (resource.getClass() == Boulder.class)
					return true;
			}
		}
		return false;
	}
	
	/**
	 * Return the Boulder that has last been added to this Cube and remove it from this Cube.
	 * 
	 * @return The element of the list of all Resources in this Cube which is a Boulder and
	 * 			with an index greater than all other elements that are Boulders in this list.
	 * 		| result == (element where this.resourceList.contains(element)
	 * 		|			and element.getClass() == Boulder.class
	 * 		|			and this.resourceList.indexOf(element) > (this.resourceList.indexOf(other_element) 
	 * 		|			where other_element this.resourceList.contains(other_element)
	 * 		|			and element.getClass() == Boulder.class))
	 * @post The returned element is removed from the list of all Resources in this Cube.
	 * 		| new.resourceList == old.resourceList.remove(result)
	 * @throws IllegalStateException
	 * 		The list of all Resources in this Cube does not contain a Boulder.
	 * 		| !this.containsBoulder()
	 */
	public Boulder pickUpBoulder() throws IllegalStateException {
		if (!this.containsBoulder())
			throw new IllegalStateException();
		int index = this.resourceList.size() - 1;
		while (!Boulder.class.isInstance(this.resourceList.get(index))) {
				index --;
		}
		Boulder boulder = (Boulder) this.resourceList.get(index);
		boulder.removeObjectFromWorld();
		return boulder;
	}
	
	/**
	 * Return the Log that has last been added to this Cube and remove it from this Cube.
	 * 
	 * @return The element of the list of all Resources in this Cube which is a Log and
	 * 			with an index greater than all other elements that are Logs in this list.
	 * 		| result == (element where this.resourceList.contains(element)
	 * 		|			and element.getClass() == Log.class
	 * 		|			and this.resourceList.indexOf(element) > (this.resourceList.indexOf(other_element) 
	 * 		|			where other_element this.resourceList.contains(other_element)
	 * 		|			and element.getClass() == Log.class))
	 * @post The returned element is removed from the list of all Resources in this Cube.
	 * 		| new.resourceList == old.resourceList.remove(result)
	 * @throws IllegalStateException
	 * 		The list of all Resources in this Cube does not contain a Log.
	 * 		| !this.containsLog()
	 */
	public Log pickUpLog() throws IllegalStateException {
		if (!this.containsLog())
			throw new IllegalStateException();
		int index = this.resourceList.size() - 1;
		while (!Log.class.isInstance(this.resourceList.get(index))) {
				index --;
		}
		Log log = (Log) this.resourceList.get(index);
		log.removeObjectFromWorld();
		return log;
	}
}
