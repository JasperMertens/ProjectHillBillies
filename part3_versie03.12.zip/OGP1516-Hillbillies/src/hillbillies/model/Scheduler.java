package hillbillies.model;

import java.util.Collection;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import be.kuleuven.cs.som.annotate.Basic;


/**
 * A class of schedulers that manage Tasks.
 * 
 * @invar	 A Scheduler shall only contain Tasks that are well formed.
 * 			| for each Task task in returnAllTasks(): task.isWellFormed() 
 * 
 * @version 1.0
 * @author Zeno Gillis, Jasper Mertens
 *
 */
public class Scheduler {

	/**
	 * Variable registering all Tasks in this Scheduler
	 */
	private List<Task> taskList = new LinkedList<>();
	/**
	 * Variable registering the faction where this Scheduler should be assigned to.
	 */
	private Faction faction; 
	
	/**
	 * Initialize a new Scheduler with the given faction.
	 * 
	 * @param faction
	 * 			The faction to which this new Scheduler should be assigned to.
	 * 
	 * @effect The faction of this new Scheduler is set to the given Faction.
	 * 			|new.getFaction() = faction;
	 */
	public Scheduler(Faction faction){
		this.setFaction(faction);
	}
	
	/**
	 * Returns the faction of this Scheduler.
	 */
	@Basic
	public Faction getFaction() {
		return faction;
	}

	/**
	 * Set the faction of this Scheduler to the given faction.
	 */
	@Basic
	public void setFaction(Faction faction) {
		this.faction = faction;
	}

	/**
	 * Add a Task to this Scheduler.
	 * @param task
	 * 			The task to add.
	 * 
	 * @post The Task is added to List of Tasks of this Scheduler.
	 * 			If the list of all Tasks of this Scheduler is empty, 
	 * 				add the given Task to the list of Tasks of this Scheduler.
	 * 			Else 
	 * 				Iterate over the list of all Tasks of this Scheduler
	 * 					If the priority the Task in the list is smaller then 
	 * 						the priority of the given Task, insert the given
	 * 						Task in the list. This means, shift elements with
	 * 						a higher priority in the list of Tasks one 
	 * 						index to the right and add the given Task at the
	 * 						previous index of the comparing task in the List.
	 * 					Else if the end of the list of all Tasks is reached,
	 * 						add the given task at the end of the list. 
	 * 			
	 * 			|If (old.getTaskList().isEmpty())
	 * 			|	then new.getTaskList() == old.getTaskList() + (task).
	 * 			|Else
	 * 			|	iterator old.getTaskList().getIterator()
	 * 			| 		for(iterator.hasNext())
	 * 			|			comparingTask = iterator.getTask();
	 * 			|			if (comparingTask.getPriority() < task.getPriority())
	 * 			|				then new.getTaskList() == old.getTaskList().insert(task);
	 * 			|			else if (iterator.getIndex() == old.getTaskList.getSize())
	 * 			|				then new.getTaskList() == old.getTaskList().addToEnd(Task);
	 * @throws	IllegalArgumentException
	 * 			The given Task is not well formed.
	 * 			|(!task.isWellFormed())
	 */
	public void addTask(Task task) throws IllegalArgumentException {
		if (!task.isWellFormed())
			throw new IllegalArgumentException();
		Integer taskPriority = task.getPriority();
		LinkedList<Task> iterateList = new LinkedList<>();
		iterateList.addAll(this.taskList);
		task.addScheduler(this);
		if (iterateList.size() == 0 ){
			taskList.add(task);
			System.out.println("First task added to the list of tasks");
		}
		else {
			for (Task comparingTask : iterateList) {
				if (taskPriority > comparingTask.getPriority()){
					taskList.add(taskList.indexOf(comparingTask), task);
					System.out.println("Inserts a task of equal or higher priority");
				}
				else if (taskList.indexOf(comparingTask) == iterateList.size()-1){
					((LinkedList<Task>) taskList).addLast(task);
					System.out.println("Added a task at the end of the list");
				}
			}
		}
		
	}
	/**
	 * Add a Collection of Tasks to this Scheduler
	 * @param tasks
	 * 			The Collection of Tasks to add.
	 * @effect For each Task in the Collection of Tasks, add
	 * 			that Task to the list of Tasks of this Scheduler.
	 * 			|taskToAdd = tasks.getNext()
	 * 			|this.addTask(taskToAdd);
	 * @post The Collection of Tasks is added to the list of Tasks 
	 * 			of this Scheduler
	 * 			|new.getTaskList() == old.getTaskList() + (tasks);
	 */
	public void addTask(Collection<Task> tasks){
		for (Task task : tasks) {
			this.addTask(task);
		}
	}
	/**
	 * Remove a Task from this Scheduler
	 * @param task
	 * 			The Task to remove.
	 * @post The given Task is removed from this Scheduler.
	 * 			If it does not exist in this Scheduler, do nothing.
	 * 			Else, remove the given Task from this Scheduler's list of Tasks.
	 * 			|new.getTaskList() == old.getTaskList() - (task);
	 */
	public void removeTask(Task task) {
		taskList.remove(task);
	}
	/**
	 * Remove a Collection of Tasks from this Scheduler
	 * @param tasks
	 * 			The Collection of Tasks to remove.
	 * @effect removeTask(tasks)
	 * 			For each Task in the Collection of Tasks to remove,
	 * 			 remove that Task from the list of Tasks of this Scheduler.
	 * 			|new.getTaskList() == old.getTaskList() - (tasks);
	 */
	public void removeTask(Collection<Task> tasks) {
		taskList.removeAll(tasks);
	}

	/**
	 * Replace a Task with a new one in this Scheduler.
	 * @param originalTask
	 * 			The old Task to remove.
	 * @param newTask
	 * 			The new Task to add.
	 * @post The originalTask is replaced with the newTask.
	 * 			If the originalTask is being executed, 
	 * 				stop the execution of this task.
	 * @effect Remove the originalTask from the list of Tasks of this
	 * 			Scheduler.
	 * 			|this.removeTask(originalTtask);
	 * @effect Add the new Task to the list of Tasks of this Scheduler.
	 * 			|this.addTask(newTtask);			
	 * 			
	 * @post The list of Tasks of this Scheduler is updated, the original Task
	 * 			is replaced by the new Task.
	 * 			|new.getOriginalTask() ==  newTask;
	 */
	public void replaceTask(Task originalTask, Task newTask){
		if (originalTask.isBeingExecuted())
			this.unmarkUnit(originalTask.getUnit());
		this.removeTask(originalTask);
		this.addTask(newTask);
	}
	
	/**
	 * Check whether this Scheduler contains a Task.
	 * @param givenTask
	 * 			The Task to check.
	 * @return True if and only if the list of Tasks of this Scheduler contains
	 * 			the given Task.
	 * 			|result == new.getTaskList().contains(givenTask);
	 */
	public boolean containsTask(Task givenTask){
		return (taskList.contains(givenTask));
	}
	
	/**
	 * Check whether this Scheduler contains a Collection of Tasks.
	 * @param givenTasks
	 * 			The Collection of Tasks to check.
	 * @return True if and only if the list of Tasks of this Scheduler contains
	 * 			the given Collection of Tasks.
	 * 			|result == new.getTaskList().containsAll(givenTasks);
	 */
	public boolean containsTask(Collection<Task> givenTasks){
		return (taskList.containsAll(givenTasks));
	}
	
	/**
	 * Return the Task with the highest priority.
	 * @return The task with the highest priority from the list of 
	 * 			Tasks of this Scheduler.
	 * 			If there is no Task present in the list of Tasks of
	 * 			this Scheduler, return null.
	 * 			|If(old.gettaskList().isEmpty())
	 * 			|	result == null;
	 * 			|Else
	 * 			|	result == new.getTaskList().getHighestPriorityTask(); 
	 */
	public Task returnHighestPriorityTask() {
		for (Task task : this.taskList){
			if (!task.isBeingExecuted())
				return task;
		}
		return null;
	}
	
	/**
	 * Return all Tasks in this Scheduler.
	 */
	@Basic
	public List<Task> returnAllTasks(){
		return this.taskList; 
	}
	
	/**
	 * Return all tasks that satisfy the given condition.
	 * 
	 * @param predicate
	 * 			The condition to check.
	 * 
	 * @return All tasks that satisfy the given condition from the 
	 * 			list of Tasks of this Scheduler.
	 * 			|result == new.getTaskList().satisfy(predicate);
	 */
	public List<Task> returnFilteredTasks(Predicate<Task> predicate) {
		List<Task> allTasks = this.returnAllTasks();
		return allTasks.stream().filter(predicate).collect(Collectors.toList());
	}
	
	/**
	 * Assign a Unit to a Task
	 * @param unit
	 * 			The Unit to give the Task to.
	 * @param task
	 * 			The Task to be given to the Unit.
	 * @effect Set the Unit that gets this task to unit.
	 * 			|task.getUnit() == unit;
	 * @effect Set the Task that this Unit gets to task.
	 * 			|unit.getTaskToDo() == task;
	 * @post The given Unit is assigned to the given Task.
	 */
	private void markUnit(Unit unit, Task task){
		task.setUnit(unit);
		unit.setTaskToDo(task);
	}
	
	/**
	 * Unmark a Unit from his Task.
	 * @param unit
	 * 			The Unit of his Task to unmark.
	 * @effect If the Unit is executing his Task, make him stop.
	 * 			|unit.getStatus() == stop;
	 * @effect Set the Unit of his Task to null
	 * 			|task.getUnit() == null;
	 * @post The given Unit is unmarked from his Task.
	 * 			|unit.getTaskToDo() == null;
	 */
	public void unmarkUnit(Unit unit){
		Task markedTask = unit.getTaskToDo();
		markedTask.getUnit().standStill();
		markedTask.setUnit(null);
		unit.setTaskToDo(null);
	}
	
	/**
	 * Assign a task to a Unit
	 * @param unit
	 * 			The Unit to assign the Task to.
	 * @effect The Task with the highest priority of this Scheduler is called to.
	 * 			|this.returnHighestPriorityTask();
	 * @effect The task with the highest Priority of this Scheduler is assigned to 
	 * 			to the given Unit.
	 * 			|this.returnHighestPriorityTask().markUnit(unit)
	 * @post The given Unit is assigned the highest priority Task of this Scheduler.
	 * 			|unit.getTaskToDo() == new.returnHighestPriorityTask();
	 */
	public void giveTask(Unit unit) {
		Task task = this.returnHighestPriorityTask();
		if (task != null) {
			this.markUnit(unit, task);
		}
	}
	/**
	 * Initialize a new Iterator for this Scheduler.
	 * @return A new Iterator for this Scheduler.
	 * 			|result == new.getIterator();
	 */
	public Iterator<Task> iterator() {
		return new Iterator<Task>(){

			@Override
			public boolean hasNext() {
				return iteratorIndex < taskList.size()-1;
			}

			@Override
			public Task next() {
				if (!hasNext()){
					this.iteratorIndex = 0;
					throw new NoSuchElementException();
				}
				this.iteratorIndex ++;
				return taskList.get(iteratorIndex-1);
			}
			private Integer iteratorIndex = 0;
		};
	}
}
