package hillbillies.model;


/**
 * A class for signalling illegal invocations of AdvanceTime for a WorldObject.
 * 
 * @author Jasper, Zeno
 * @version 1.0
 *
 */

public class IllegalAdvanceStateException extends RuntimeException {
	public IllegalAdvanceStateException() {
	}

	/**
	 * This aspect is of no concern to us, but Java requires it.
	 */
	private static final long serialVersionUID = 2003001L;

}
