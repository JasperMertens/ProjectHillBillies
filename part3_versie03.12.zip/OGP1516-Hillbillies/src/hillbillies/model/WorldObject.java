package hillbillies.model;

import be.kuleuven.cs.som.annotate.Basic;
import be.kuleuven.cs.som.annotate.Raw;
import ogp.framework.util.Util;

/**
 * A class of WorldObjects, with given position and World where they exist.
 * 
 * @invar A WorldObject is always spawned in a World at the centre of the Cube surrounding its current position.
 * 
 * @version 2.0
 * @author Zeno Gillis, Jasper Mertens
 */
public 	abstract class WorldObject {

	private World world;
	private int weight;
	private Vector vectorPosition;
	private boolean falling;
	
	
	
	protected WorldObject(Vector position) throws IllegalArgumentException {
		if (!position.isPositive())
			throw new IllegalArgumentException();
		this.vectorPosition = (position.getCopy());
	}
	
	/**
	 * Return whether this WorldObject can fall at its current position.
	 * @return
	 */
	protected abstract boolean canFall() throws IllegalStateException;
	
	/**
	 * Return the weight of this WorldObject.
	 * @return
	 */
	@Basic
	protected int getWeight() {
		return this.weight;
	}
	
	/**
	 * Return the position of this WorldObject as an array of coordinates.
	 * 
	 */
	// NO problem for reference leaks, in the Vector class the getCoordinates method returns a newly made list.
	@Basic
	@Raw
	public double[] getPosition() {
		return this.vectorPosition.getCoordinates();
	}
	
	/**
	 * Return the position of this WorldObject as a Vector.
	 */
	// getCopy method in Vector class to prevent reference leaks.
	@Basic
	@Raw
	public Vector getVectorPosition() {
		return this.vectorPosition.getCopy();
	}
	
	/**
	 * Set the position of this WorldObject to the given position in the given World.
	 * 
	 * @param position
	 *            The new position for this WorldObject.
	 * @param world
	 * 			The World in which to check the position.
	 * @post The position of this new Unit is equal to the given position. 
	 *        | new.getPosition() == position
	 * @throws IllegalPositionException
	 *             The given position is not a valid position for any WorldObject.
	 *             | !isValidPosition(getPosition())
	 */
	@Raw
	@Basic
	public void setVectorPosition(Vector position, World world) throws IllegalPositionException {
		if (!this.canHaveAsPosition(position, world)
				&& !this.isNearToEdge(position, world)) {
			throw new IllegalPositionException(position, world);
		}
		this.vectorPosition = (position.getCopy());
	}
	
	/**
	 * Return whether the given position is a valid position for this WorldObject,
	 * 	within the given World.
	 * 
	 * @param position
	 * 			The position to check.
	 * @param world
	 * 			The World in which the position must be checked.
	 * @return True if and only if the given position is within the boundaries of the given World
	 * 			and if the Cube at the given position isn't a solid Cube.
	 * 			| return == (this.world.isWithinWorld(x, y, z) && (!cube.isSolid())
	 */
	public boolean canHaveAsPosition(Vector position, World world) {
		double x_coord = position.getX();
		double y_coord = position.getY();
		double z_coord = position.getZ();
		Cube cube = world.getCube(position.getRoundDown());
		if (world.isWithinWorld(x_coord, y_coord, z_coord) && (!cube.isSolid())){
			return true;
		}
		return false;
	}
	
	/**
	 * Return whether the given position is near to an edge of the Cube surrounding the given position in the World of this WorldObject.
	 * 
	 * @param x
	 * 		The x-coordinate to check.
	 * @param y
	 * 		The y-coordinate to check.
	 * @param z
	 * 		The z-coordinate to check.
	 * @param world
	 * 		The World to get the Cube from.
	 * 
	 * @return True if and only if at least one of the given coordinates is near to an edge of the Cube
	 * 			 surrounding the given position in the World of this WorldObject.
	 * 		| result == ((Util.fuzzyEquals(position.getX(), cubeCoordinates[0], 0.01)) || (Util.fuzzyEquals(position.getX(), cubeCoordinates[0]+cubeLength, 0.01))
	 *					|| (Util.fuzzyEquals(position.getY(), cubeCoordinates[1], 0.01)) || (Util.fuzzyEquals(position.getY(), cubeCoordinates[1]+cubeLength, 0.01))
	 *					|| (Util.fuzzyEquals(position.getZ(), cubeCoordinates[2], 0.01)) || (Util.fuzzyEquals(position.getZ(), cubeCoordinates[2]+cubeLength, 0.01)))
	 */
	private boolean isNearToEdge(Vector position, World world) {
		int[] cubeCoordinates = position.getRoundDown();
		double cubeLength = world.getCube(cubeCoordinates).getCubeLength();
		
		if ((Util.fuzzyEquals(position.getX(), cubeCoordinates[0], 0.01)) || (Util.fuzzyEquals(position.getX(), cubeCoordinates[0]+cubeLength, 0.01))
				|| (Util.fuzzyEquals(position.getY(), cubeCoordinates[1], 0.01)) || (Util.fuzzyEquals(position.getY(), cubeCoordinates[1]+cubeLength, 0.01))
				|| (Util.fuzzyEquals(position.getZ(), cubeCoordinates[2], 0.01)) || (Util.fuzzyEquals(position.getZ(), cubeCoordinates[2]+cubeLength, 0.01)))
			return true;
		return false;
	}
	
	/**
	 * Add this WorldObject to the given World.
	 * 
	 * @param world
	 * 		The World to add the current WorldObject to.
	 * @throws IllegalPositionException
	 * 			The position of this WorldObject is not a valid position in the given World.
	 */
	public void addObjectToWorld(World world) throws IllegalPositionException {
		this.setVectorPosition(this.getCurrentCube(world).getCentreCube(), world);
		this.world = world;
		world.addWorldObjectToSet(this);
	}
	
	/**
	 * Removes this WorldObject from its current World.
	 * 
	 * @post This WorldObject is removed from its World.
	 * 		| new.getWorld() == null
	 * @throws IllegalStateException
	 * 			This WorldObject doesn't currently belong to a World.
	 * 			| this.getWorld() == null
	 */
	public void removeObjectFromWorld() throws IllegalStateException {
		if (this.getWorld() == null)
			throw new IllegalStateException();
		this.getWorld().removeWorldObjectFromSet(this);
		this.world = null;
	}
	
	/**
	 * Return the position of the Cube surrounding this WorldObject as an array of coordinates.
	 * @return
	 */
	@Basic
	// NO problem for reference leaks, in the Vector class the roundDown method returns a newly made list.
	public int[] getCurrentCubeCoordinate() {
		return this.vectorPosition.getRoundDown(); 
	}
	
	/**
	 * Return the position of the Cube surrounding this WorldObject as a Vector.
	 * @return
	 */
	public Vector getCurrentCubePosition() {
		return new Vector(this.getCurrentCubeCoordinate());
	}
	
	/**
	 * Return the Cube this WorldObject would occupy in the given World.
	 * 
	 * @param world
	 * 		The World to get the Cube from.
	 * 
	 * @return
	 * 		| result == world.getCube(this.getCurrentCubeCoordinate())
	 */
	public Cube getCurrentCube(World world) {
		return world.getCube(this.getCurrentCubeCoordinate());
	}
	
	/**
	 * Checks if the given time is a valid time.
	 * @param time
	 * 			The time to check
	 * @return Returns true if and only if the given time lies between 0 and 0.2.
	 * 			|result == (0<=time<=0.2)
	 */
	private boolean isValidAdvanceTime(double time) {
		return ((time>= 0) && (time <= 0.2));
	}
	
	public void advanceTime(double time) throws IllegalArgumentException, UnreachablePositionException,
												IllegalPositionException {
		if (!isValidAdvanceTime(time)) {
			System.out.println(time);
			throw new IllegalArgumentException();
		}
		if (this.canFall() || this.isFalling())
			this.fall(time);
	}
	
	/**
	 * Return whether this WorldObject is falling.
	 * @return
	 */
	@Basic
	protected boolean isFalling() {
		return this.falling;
	}
	
	/**
	 * Set whether this WorldObject is falling.
	 * 
	 * @param bool
	 * 		The boolean to indicate whether this WorldObject is falling.
	 */
	@Basic
	protected void setFalling(boolean bool) {
		this.falling = bool;
	}
	
	/**
	 * Check if this WorldObject has arrived at the center of the given targetCube
	 * 	after travelling the given distance.
	 * 
	 * @param centreTargetCube
	 * 		The centre of the target Cube.
	 * @param distance
	 * 		The distance to travel.
	 * @return
	 * 		| result == (distance >= currentDistanceToTarget)
	 */
	public boolean hasArrived(Vector targetPosition, double distance) {
		double currentDistanceToTarget = 
				targetPosition.subtractVector(this.getVectorPosition()).getMagnitude();
		if (distance >= currentDistanceToTarget){
			return true;
		}
		return false;
	}
	/**
	 * Let this WorldObject that is a resource fall towards a cube at a lower Z level.
	 * @param time
	 */
	public void fall(double time){
		this.setFalling(true);
		Vector fallingSpeed = new Vector(0, 0, -3);
		Vector fallingVector = fallingSpeed.getMultipleVector(time);
		Vector newPosition = this.getVectorPosition().addVector(fallingVector);
		Cube newCube = this.getWorld().getCube(newPosition.getRoundDown());
		double z_Value = (this.getCurrentCube(getWorld()).getCubeLength())/2.0;
		Vector targetPosition = newPosition.getCopy();
		targetPosition.setZ(z_Value);
		if (this.getWorld().isAboveSolidGround(newCube) &&
				this.hasArrived(targetPosition, fallingVector.getMagnitude())){
			this.setFalling(false);
			this.setVectorPosition(newCube.getCentreCube(), this.getWorld());
		}
		else{
			this.setVectorPosition(newPosition, this.getWorld());
			
			
		}
	}
	public World getWorld(){
		return this.world;
	}
	public boolean getFalling(){
		return this.falling;
	}
	public void setWeight(int weight){
		this.weight = weight;
	}
}
