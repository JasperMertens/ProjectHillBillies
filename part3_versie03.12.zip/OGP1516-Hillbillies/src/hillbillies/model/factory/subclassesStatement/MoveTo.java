package hillbillies.model.factory.subclassesStatement;

import hillbillies.model.Unit;
import hillbillies.model.UnreachablePositionException;
import hillbillies.model.factory.*;
import hillbillies.part3.programs.SourceLocation;

public class MoveTo extends Statement {

	private Expression<int[]> position;

	public MoveTo(Expression<int[]> position, SourceLocation sourceLocation) {
		super(sourceLocation);
		this.position = position;
	}

	@Override
	public void execute(Unit unit) throws IllegalArgumentException, UnreachablePositionException {
				unit.moveTo((this.position.execute(unit)));
	}
	
	@Override
	public String getRead() {
		return this.position.getVariableName();
	}
}
