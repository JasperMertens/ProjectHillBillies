package hillbillies.model.factory.subclassesStatement;

import hillbillies.model.Unit;
import hillbillies.model.factory.Expression;
import hillbillies.model.factory.Statement;
import hillbillies.part3.programs.SourceLocation;

public class Attack extends Statement {

	private Expression<Unit> unitToAttack;
	
	public Attack(Expression<Unit> unit, SourceLocation sourceLocation) {
		super(sourceLocation);
		this.unitToAttack = unit;
	}

	@Override
	public void execute(Unit unit) {
			unit.attack( this.unitToAttack.execute(unit));
	}
	
	@Override
	public String getRead() {
		return this.unitToAttack.getVariableName();
	}
}
