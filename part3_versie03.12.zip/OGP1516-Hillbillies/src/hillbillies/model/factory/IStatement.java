package hillbillies.model.factory;

import java.util.Map;

import hillbillies.model.Unit;

public interface IStatement {
	
	default public boolean containsBreakOutOfLoop() {
		return false;
	}
	
	default public Statement getNext(Unit unit) {
		return null;
	}
	
	default public int size(){
		return 1;
	}
	
	default public boolean containsInvalidRead(Map<String, Integer> assignMap) {
		return false;
	}
	
	default public String getAssignment() {
		return null;
	}
	
	default public String getRead(){
		return null;
	}
}
