package hillbillies.model.factory;

import be.kuleuven.cs.som.annotate.*;
import hillbillies.model.IllegalPositionException;
import hillbillies.model.Unit;
import hillbillies.model.UnreachablePositionException;
import hillbillies.part3.programs.SourceLocation;

public abstract class Statement implements IStatement {
	
private SourceLocation sourceLocation;
	
	public Statement(SourceLocation sourceLocation) throws IllegalArgumentException{
		this.sourceLocation = sourceLocation;
	}
	
	@Immutable
	public SourceLocation getSourceLocation() {
		return this.sourceLocation;
	}
	
	public abstract void execute(Unit unit) throws IllegalArgumentException, UnreachablePositionException,
														IllegalPositionException, IllegalStateException;
}