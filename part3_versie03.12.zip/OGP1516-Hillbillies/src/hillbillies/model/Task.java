package hillbillies.model;

import java.util.*;

import be.kuleuven.cs.som.annotate.Basic;
import hillbillies.model.factory.Statement;

/**
 * A class of tasks with a name, a priority and activities.
 * 
 * @version 1.0
 * @author Zeno Gillis, Jasper Mertens
 */
public class Task  {

	/**
	 * Variable registering the name of this Task.
	 */
	private String name;
	/**
	 * Variable registering the priority of this Task.
	 */
	private Integer taskPriority;
	/**
	 * Variable registering the activities of this Task.
	 */
	private Statement activities;
	/**
	 * Variable registering the Unit assigned to this Task.
	 */
	private Unit unit;
	/**
	 * Variable registering selected Cubes of this Task.
	 */
	private int[] selectedCubes;
	/**
	 * Variable registering the Schedulers of this Task.
	 */
	private Set<Scheduler> schedulers;

	/**
	 * Initialize a new Task with the given name, priority, activity and selectedCubes. 
	 * @param name
	 * 			The name of this new Task.
	 * @param priority
	 * 			The priority of this new Task.
	 * @param activity
	 * 			The activity of this new Task.
	 * @param selectedCubes
	 * 			The selectedCubes of this new Task.
	 * 
	 * @post The new Task is initialized with a name, a priority, an activity, selected Cubes
	 * 			and an empty set of Schedulers.
	 * 		  If no activity is given, don't initialize a new Task.
	 * 		|new.getName() == name;
	 * 		|new.getPriority() == priority;
	 * 		|new.getActivity() == activity;
	 * 		|new.getSelectedCubes() == selectedCubes;
	 * 		|new.getSchedulers() == emptySet;
	 */
	public Task(String name, int priority, Statement activity, int[] selectedCubes) {
		if (activity.size() == 0)
			throw new IllegalArgumentException();
		this.schedulers = new HashSet<>();
		this.setName(name);
		this.setPriority(priority);
		this.setActivities(activity);
		this.selectedCubes = selectedCubes;
	}

	/**
	 * Set the activities of this Task. 
	 */
	@Basic
	private void setActivities(Statement givenActivities) {
		this.activities = givenActivities;
	}
	
	/**
	 * Return the activities of this Task.
	 */
	@Basic
	public Statement getActivities() {
		return this.activities;
	}

	/**
	 * Set the priority of this Task.
	 * @param priority
	 * 			The priority to be set.
	 * @return	To keep the right ordering of Tasks in this Task's Scheduler,
	 * 			 this Task should be removed and added back to the Scheduler
	 * 			 with the right priority. 
	 * 			|this.replaceTask(this,this);
	 * @post The priority of this Task is set to the given priority.
	 * 		 |new.getPriority() == priority;
	 */
	// Remove and add back to schedulers to keep the right ordering.
	private void setPriority(Integer priority) {
		this.taskPriority = priority;
		Iterator<Scheduler> schedulerIterator = this.getSchedulers().iterator();
		while (schedulerIterator.hasNext()) {
			Scheduler schedule = schedulerIterator.next();
			schedule.replaceTask(this, this);
		}
	}
	/**
	 * Return the priority of this Task.
	 */
	@Basic
	public Integer getPriority() {
		return this.taskPriority;
	}

	/**
	 * Set the name of this Task.
	 */
	@Basic
	private void setName(String name) {
		this.name = name; 
	}
	
	/**
	 * Return the name of this Task. 
	 */
	@Basic
	public String getName(){
		return this.name;
	}
	
	/**
	 * Set the Unit of this Task
	 */
	@Basic
	public void setUnit(Unit unit){
		this.unit = unit;
	}

	/**
	 * Return the Unit of this Task.
	 */
	@Basic
	public Unit getUnit() {
		return this.unit;
	}

	/**
	 * Reduce the priority of this Task.
	 * @post The priority of this Task is reduced with one.
	 * 			|new.getPriority() == old.getPriority()-1
	 */
	public void reducePriority() {
		this.setPriority(this.getPriority()-1);
	}

	/**
	 * Return the state of execution of this Task
	 * @return	True if and only if this Task has a Unit.
	 * 			|result == (new.getUnit() != null);
	 */
	public boolean isBeingExecuted() {
		return this.getUnit()!=null;
	}
	
	/**
	 * Execute this Task.
	 * @post The activities of this Task are executed.
	 * 			|new.getActivities().isExecuting == true.
	 */
	public void execute() {
		try{
			this.activities.execute(this.getUnit());
		}catch (IllegalArgumentException | UnreachablePositionException | IllegalPositionException ex){
			this.getUnit().getTaskToDo().reducePriority();
			this.getUnit().getFaction().getScheduler().unmarkUnit(this.getUnit());
		}
	}

	/**
	 * Return the selectedCubes of this Task.
	 */
	@Basic
	public int[] getSelected() {
		return this.selectedCubes;
	}

	/**
	 * Add a Scheduler to the list of Schedulers.
	 * @param scheduler
	 * 			The Scheduler to add.
	 * @post The Scheduler is added to the list of Schedulers
	 * 			of this Task
	 * 			|new.getSchedulers() == old.getSchedulers() + scheduler;
	 */
	public void addScheduler(Scheduler scheduler){
		this.schedulers.add(scheduler);
	}
	
	/**
	 * Return a list of Schedulers.
	 */
	@Basic
	public Set<Scheduler> getSchedulers() {
		return this.schedulers;
	}
	
	/**
	 * Check if this Task is well formed.
	 * @return True if and only if there are no BreakStatements outside
	 * 			loops and if a variable is assigned before it is read.
	 * 			|result == new.areAllBreaksOutOfLoops() && new.allVariablesAssignedBeforeRead();
	 */
	public boolean isWellFormed(){
		Map<String, Integer> assignMap = new HashMap<>();
		boolean breakOutOfLoop = this.activities.containsBreakOutOfLoop();
		boolean invalidRead = this.activities.containsInvalidRead(assignMap);
		return (!breakOutOfLoop && !invalidRead);
	}
}

