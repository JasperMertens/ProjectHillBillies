package hillbillies.model;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import hillbillies.model.factory.Statement;
import ogp.framework.util.ModelException;

public class Task  {

	private String name;
	private Integer taskPriority;
	private Statement activities;
	private Unit unit;
	private int[] selectedCube;
	private Set<Scheduler> schedulers;

//	TODO name
//	priority
//	activities
//	Assignment to Unit

	public Task(String name, int priority, Statement activity, int[] selectedCube) {
//	TODO task illegalArgument
//		if (activity.getLength() == 0)
//			throw new IllegalArgumentException();
		this.schedulers = new HashSet<>();
		this.setName(name);
		this.setPriority(priority);
		this.setActivities(activity);
		this.selectedCube = selectedCube;
	}

	private void setActivities(Statement givenActivities) {
		this.activities = givenActivities;
	}
	
	public Statement getActivities() {
		return this.activities;
	}

	// Remove and add back to schedulers to keep the right ordering.
	private void setPriority(Integer priority) {
		this.taskPriority = priority;
		Iterator<Scheduler> schedulerIterator = this.getSchedulers().iterator();
		while (schedulerIterator.hasNext()) {
			Scheduler schedule = schedulerIterator.next();
			schedule.replaceTask(this, this);
		}
	}

	public Integer getPriority() {
		return this.taskPriority;
	}

	private void setName(String name) {
		this.name = name; 
	}
	public String getName(){
		return this.name;
	}
	
	public void setUnit(Unit unit){
		this.unit = unit;
		}

	public Unit getUnit() {
		return this.unit;
	}

	public void reducePriority() {
		this.setPriority(this.getPriority()-1);
	}

	public boolean isBeingExecuted() {
		return this.getUnit()!=null;
	}
	
	public void execute() {
		try{
			this.activities.execute(this.getUnit());
		}catch (IllegalArgumentException | UnreachablePositionException ex){
			this.getUnit().getTaskToDo().reducePriority();
			this.getUnit().getFaction().getScheduler().unmarkUnit(this.getUnit());
		}
	}

	public int[] getSelected() {
		return this.selectedCube;
	}

	public void addScheduler(Scheduler scheduler){
		this.schedulers.add(scheduler);
	}
	public Set<Scheduler> getSchedulers() {
		return this.schedulers;
	}
}

