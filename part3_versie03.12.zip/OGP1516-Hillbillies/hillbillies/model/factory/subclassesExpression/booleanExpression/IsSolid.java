package hillbillies.model.factory.subclassesExpression.booleanExpression;

import hillbillies.model.Cube;
import hillbillies.model.Unit;
import hillbillies.model.factory.Expression;
import hillbillies.part3.programs.SourceLocation;

public class IsSolid extends Expression<Boolean> {

	private Expression<int[]> position;

	public IsSolid(Expression<int[]> position, SourceLocation sourceLocation) {
		super(sourceLocation);
		this.position = position;
	}

	@Override
	public Boolean execute(Unit unit) {
		Cube cube = unit.getWorld().getCube(this.position.execute(unit));
		return cube.isSolid();
	}

}
