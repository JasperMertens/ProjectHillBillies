package hillbillies.model.factory.subclassesExpression;

import hillbillies.model.Unit;
import hillbillies.model.factory.Expression;
import hillbillies.part3.programs.SourceLocation;

public class UnitExpression<T> extends Expression<Unit, T> {

	protected UnitExpression(SourceLocation sourceLocation) {
		super(sourceLocation);
	}

	@Override
	public Unit execute(T t) {
		return null;
	}

}
