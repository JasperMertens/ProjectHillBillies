package hillbillies.model;


/**
 * A class for signaling a certain position is unreachable.
 * 
 * @version  1.0
 * @author   Zeno Gillis, Jasper Mertens
 */
public class UnreachablePositionException extends Exception {


	/**
	 * Initialize this new illegal denominator exception with given value.
	 * 
	 * @param  value
	 *         The value for this new illegal denominator exception.
	 * @post   The value of this new illegal denominator exception is equal
	 *         to the given value.
	 *       | new.getValue() == value
	 */
	public UnreachablePositionException() {
	}

	/**
	 * The Java API strongly recommends to explicitly define a version
	 * number for classes that implement the interface Serializable.
	 * At this stage, that aspect is of no concern to us. 
	 */
	private static final long serialVersionUID = 2003001L;

}
