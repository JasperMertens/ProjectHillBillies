package hillbillies.model;

import java.util.*;

import be.kuleuven.cs.som.annotate.*;
import hillbillies.part2.listener.TerrainChangeListener;
import hillbillies.util.ConnectedToBorder;

/**
 * A class of Worlds with given terrain types and configuration.
 *  
 * @invar A World shall never have more than 5 Factions.
 * @invar A World always has one corner at the origin of the coordinate field.
 *  
 * @version 1.0
 * @author Zeno Gillis, Jasper Mertens
 *
 */
public class World {
	
	/**
	 * Constants for naming the different terrain types.
	 */
	static final int AIR = 0;
	static final int ROCK = 1;
	static final int TREE = 2;
	static final int WORKSHOP = 3;
	
	/**
	 * Constants registering the borders of this World.
	 */
	private final int MAX_X;
	private final int MAX_Y;
	private final int MAX_Z;
	private final static int MIN_X = 0;
	private final static int MIN_Y = 0;
	private final static int MIN_Z = 0;

	/**
	 * A map of this World, with coordinates as its keys and Cubes as its values.
	 */
	private final Map<Integer, Cube> worldMap;
	
	/**
	 * List containing all keys to the worldmap;
	 */
	private final int[][][] keyList;
	
	/**
	 * Sets containing all the active objects of this World.
	 */
	// Aanpassen naar een set met alles in, na double dispatch gezien te hebben in de les.
	private Set<Faction> factionSet;
	private Set<Unit> unitSet;
	private Set<Resource> resourceSet;
	
	/**
	 * Constant registering the terrainchangListener instance for this Cube.
	 */
	private final TerrainChangeListener modelListener;
	/**
	 * Constant registering the connectedToBorder instance for this Cube.
	 */
	private final ConnectedToBorder connectedToBorder;
	
	/**
	 * Initialize a new World with given terrainTypes.
	 * @param terrainTypes
	 * 			A three dimensional array containing the type of terrain for each Cube.
	 * 			Arranged in the following order: x, y, z.
	 * @param modelListener
	 * 			An instance of a helper class to update the terrain type in the GUI.
	 */
	public World(int[][][] terrainTypes, TerrainChangeListener modelListener) {
		this.factionSet = new HashSet<>();
		this.unitSet = new HashSet<>();
		this.resourceSet = new HashSet<>();
		this.MAX_X = terrainTypes.length;
		this.MAX_Y = terrainTypes[0].length;
		this.MAX_Z = terrainTypes[0][0].length;
		this.modelListener = modelListener;
		ConnectedToBorder connectedToBorder = new ConnectedToBorder(MAX_X, MAX_Y, MAX_Z);
		this.connectedToBorder = connectedToBorder;
		
		Map<Integer, Cube> myMap = new HashMap<>();
		this.keyList = new int[this.MAX_X][this.MAX_Y][this.MAX_Z];
		int n=0;
		for (int x=0; x < this.MAX_X; x++) {
			for (int y=0; y < this.MAX_Y; y++) {
				for (int z=0; z < this.MAX_Z; z++) {
					Cube newCube = new Cube(this, x, y, z, terrainTypes[x][y][z]);
					myMap.put(n, newCube);
					keyList[x][y][z] = n;
					n++;
				}
			}
		}
		this.worldMap = myMap;
	}
	
	/**
	 * Return the modelListener instance of this World.
	 */
	@Basic @Immutable
	public TerrainChangeListener getModelListener() {
		return this.modelListener;
	}
	
	/**
	 * Return the connectedToBorder instance of this World.
	 */
	@Basic @Immutable
	public ConnectedToBorder getConnectedToBorder() {
		return this.connectedToBorder;
	}
	
	/**
	 * Return whether the Cube at the given coordinates is solid and connected
	 * to the border of this World.
	 * 
	 * @param x
	 *            The x-coordinate of the cube
	 * @param y
	 *            The y-coordinate of the cube
	 * @param z
	 *            The z-coordinate of the cube
	 * @return true if the given cube is solid and connected to the border of
	 *         this world; false otherwise.
	 */         
	public boolean isSolidConnectedToBorder(int x, int y, int z) {
		return this.getConnectedToBorder().isSolidConnectedToBorder(x, y, z);
	}
	
	/**
	 * Check whether the given  coordinates and terrain are valid arguments for a Cube in this World.
	 * 
	 * @param x
	 * 		The X-coordinate to check.
	 * @param y
	 * 		The Y-coordinate to check.
	 * @param z
	 * 		The Z-coordinate to check.
	 * @param terrain
	 * 		The type of terrain to check.
	 * @return	True if and only if the given coordinates are within the borders of this World 
	 * 				and if the given terrain type is a valid terrain type.
	 * 			|	result == 	((x >= 0) && (y >= 0) && (z >= 0) && 
	 * 			|				(x < MAX_X) && (y < MAX_Y) && (z < MAX_Z) &&
	 *			|				isValidTerrainType(terrain)
	 */
	public boolean canHaveAsCube(int x, int y, int z, int terrain) {
		if ((x >= 0) && (y >= 0) && (z >= 0)&& (x < MAX_X) && (y < MAX_Y) && (z < MAX_Z) &&
				isValidTerrainType(terrain))
			return true;
		return false;
	}
	
	/**
	 * Check whether the given type of terrain is a valid type of terrain.
	 * 
	 * @param terrain
	 * 		The type of terrain to check.
	 * @return	True if and only if the given terrain type is either AIR, ROCK, TREE or WORKSHOP.
	 * 			| result == (terrain == AIR) || (terrain == ROCK) || (terrain == TREE) || (terrain == WORKSHOP)
	 */
	public static boolean isValidTerrainType(int terrain) {
		if ((terrain == AIR) || (terrain == ROCK) || (terrain == TREE) || (terrain == WORKSHOP))
			return true;
		return false;
	}
	
	/**
	 * Return whether the given Cube is above solid ground.
	 * 
	 * @param currentCube
	 * 			The Cube to check.
	 * @return	True if and only if the given Cube is at Z level 0 or if the Cube underneath this
	 * 			one is solid.
	 * 			|result == ((position.getZ() == 0) || cubeUnderCurrent.isSolid())
	 */
	public boolean isAboveSolidGround(Cube currentCube) {
		Vector position = currentCube.getPosition();
		if (position.getZ() == 0)
			return true;
		Vector oneZLevel = new Vector(0, 0, 1);
		Vector positionUnderCurrent = position.subtractVector(oneZLevel);
		Cube cubeUnderCurrent = this.getCube(positionUnderCurrent.getRoundDown());
		return cubeUnderCurrent.isSolid();
	}
	
	/**
	 * Return the number of Cubes in the X-direction.
	 * @return
	 */
	@Basic @Immutable
	public int getNbCubesX() {
		return this.MAX_X;
	}
	
	/**
	 * Return the number of Cubes in the Y-direction.
	 * @return
	 */
	@Basic @Immutable
	public int getNbCubesY() {
		return this.MAX_Y;
	}
	
	/**
	 * Return the number of Cubes in the Z-direction.
	 * @return
	 */
	@Basic @Immutable
	public int getNbCubesZ() {
		return this.MAX_Z;
	}
	
	/**
	 * Return the Cube that lies at the given coordinates in this World.
	 * 
	 * @param coordinates
	 * 			The coordinates of the Cube.
	 * @return	The Cube as value to the coordinates as key in the worldMap of this World.
	 * 			| result ==  this.worldMap.get(coordinates)
	 * @throws	IllegalArgumentException
	 * 			This World does not contain the Cube at the given coordinates.
	 * 			| !this.containsCube(coordinates)
	 */
	@Immutable
	public Cube getCube(int[] coordinates) throws IllegalArgumentException {
		int x = coordinates[0];
		int y = coordinates[1];
		int z = coordinates[2];
		if (!this.containsCube(x, y, z))
			throw new IllegalArgumentException();
		int key = this.keyList[x][y][z];
		return this.worldMap.get(key);
	}
	
	/**
	 * Return the Cube that lies at the given coordinates in this World.
	 * 
	 * @param coordinates
	 * 			The coordinates of the Cube.
	 * @return	The Cube as value to the coordinates as key in the worldMap of this World.
	 * 			| result ==  this.worldMap.get(coordinates)
	 * @throws	IllegalArgumentException
	 * 			This World does not contain the Cube at the given coordinates.
	 * 			| !this.containsCube(coordinates)
	 */
	@Immutable
	public Cube getCube(String coordinates) throws IllegalArgumentException {
		int indexY = 0;
		int indexZ = 0;
		for (int i=2, n = coordinates.length(); i<n; i++) {
			char c = coordinates.charAt(i);
			if (c == 'y')
				indexY = i;
			else if (c == 'z')
				indexZ = i;
		}
		int x = Integer.parseInt(coordinates.substring(1, indexY));
		int y = Integer.parseInt(coordinates.substring(indexY+1, indexZ));
		int z = Integer.parseInt(coordinates.substring(indexZ+1));
		if (!this.containsCube(x, y, z))
			throw new IllegalArgumentException();
		int key = this.keyList[x][y][z];
		return this.worldMap.get(key);
	}
	
	/**
	 * Return whether there's a Cube in this World at the given coordinates.
	 * 
	 * @param coordinates
	 * 			The coordinates to check.
	 * @return	True if and only if the worldMap of this World contains a key equal to 
	 * 				the given coordinates.
	 * 			| result == this.worldMap.containsKey(coordinates)
	 */
	public boolean containsCube(int x, int y, int z) {
		try {
			int key = this.keyList[x][y][z];
			return this.worldMap.containsKey(key);
		} catch (IndexOutOfBoundsException exc) {
			return false;
		}
	}
	
	/**
	 * Create a new Faction with the given Unit in it.
	 * 
	 * @param firstUnit
	 * 			The Unit for the new Faction.
	 * @post If this World hasn't yet reached its maximum capacity of Factions, 
	 * 			a new Faction is created with the given Unit in it.
	 * 		| if (this.factionSet.size() < 5)
	 * 		|	then (new.getActiveFactions() == old.getActiveFactions().add(newFaction)) &&
	 * 		|		 (newFaction.getNbOfUnits() == 1) && (newFaction.getUnits().contains(unit))
	 */
	public void createFaction(Unit firstUnit) {
		if (this.factionSet.size() < 5) {
			Faction newFaction = new Faction(this, firstUnit);
			this.factionSet.add(newFaction);
		}
	}
	
	/**
	 * Remove the given Faction from this World.
	 * 
	 * @param faction
	 * 		The Faction to remove.
	 * @post The given faction is removed from this World.
	 * 		| new.getActiveFactions() == old.getActiveFactions().remove(faction)
	 * @post 
	 * 		| faction = null
	 * @throws IllegalArgumentException
	 * 			The Faction to remove is not an empty faction.
	 * 			| (faction.getNbOfUnits() != 0)
	 */
	public void removeFaction(Faction faction) throws IllegalArgumentException{
		if (faction.getNbOfUnits() != 0)
			throw new IllegalArgumentException();
		this.factionSet.remove(faction);
		faction = null;
	}
	
	/**
	 * Return the active Factions of this World.
	 * @return
	 */
	@Basic @Raw
	public Set<Faction> getActiveFactions() {
		return this.factionSet;
	}
	
	/**
	 * Add the given Unit to this World.
	 * 
	 * @param unit
	 * 		The new Unit to add.
	 * @post If the World hasn't yet reached its maximum capacity of Units 
	 * 			nor its maximum capacity of Factions, the given Unit is added to this World in a new Faction.
	 * 		| if ((this.unitSet.size() < 100) && (this.factionSet.size() < 5))
	 * 		|	then (new.getActiveUnits().contains(unit)) &&
	 * 		|		 (new.getActiveFactions() == old.getActiveFactions().add(newFaction)) &&
	 * 		|		 (newFaction.getNbOfUnits() == 1) && (newFaction.getUnits().contains(unit))
	 */
	public void addUnit(Unit unit) {
		if (this.unitSet.size() < 100) {
			this.unitSet.add(unit);
			unit.addObjectToWorld(this);
			if (this.factionSet.size() < 5)
				this.createFaction(unit);
			else 
				this.getSmallestFaction().addUnit(unit);
		}
	}
	
	/**
	 * Spawn a Unit with random attributes and random position and
	 * 	have its enableDefaultBehaviour as the given enableDefaultBehaviour.
	 * @param enableDefaultBehaviour
	 * 			The boolean to enable or disable this Unit's default behaviour.
	 * @return A new Unit with random attributes, a random position and the given default behaviour boolean.
	 * 			| result == new Unit("default", randomPosition, weight, agility, strength, toughness,
	 *			|					enableDefaultBehaviour)
	 */
	public Unit spawnUnit(boolean enableDefaultBehaviour) throws IllegalArgumentException, IllegalPositionException,
	IllegalNameException {
		Random rand = new Random();
		int weight = rand.nextInt(76)+25;
		int agility = rand.nextInt(76)+25;
		int strength = rand.nextInt(76)+25;
		int toughness = rand.nextInt(76)+25;
		ArrayList<int[]> possiblePositions = this.findPossiblePositions();
		int randomIndex = rand.nextInt(possiblePositions.size());
		int[] randomPosition = possiblePositions.get(randomIndex);

		Unit newUnit = new Unit("Default", randomPosition, weight, agility, strength, toughness,
				enableDefaultBehaviour);
		this.addUnit(newUnit);
		return newUnit;
	}
	
	/**
	 * Return all the possible positions for a Unit in this World.
	 * @return
	 */
	private ArrayList<int[]> findPossiblePositions() {
		ArrayList<int[]> positionList = new ArrayList<>();
		Iterator<Map.Entry<Integer, Cube>> iter = this.worldMap.entrySet().iterator();
		while (iter.hasNext()) {
			Map.Entry<Integer, Cube> entry = iter.next();
			if (this.isValidUnitCube(entry.getValue()))
				positionList.add(entry.getValue().getCoordinates());
		}
		return positionList;
	}
	
	/**
	 * Return whether the given Cube is a valid position in this World for a Unit.
	 * 
	 * @param cube
	 * 			The Cube to check.
	 * @return True if and only if the given Cube is passable, within the borders of
	 * 			this World and is directly above solid ground.
	 * 			| result == !cube.isSolid() && (this.isWithinWorld(x, y, z)) && (this.isAboveSolidGround(cube))
	 */
	private boolean isValidUnitCube(Cube cube) {
		int x = cube.getCoordinates()[0];
		int y = cube.getCoordinates()[1];
		int z = cube.getCoordinates()[2];
		return (!cube.isSolid() && (this.isWithinWorld(x, y, z)) && (this.isAboveSolidGround(cube)));
	}
	
	public Faction getSmallestFaction() {
		Iterator<Faction> iter = this.factionSet.iterator();
		int smallestSoFar = iter.next().getNbOfUnits();
		Faction smallestFaction = iter.next();
		while (iter.hasNext()) {
			if (iter.next().getNbOfUnits() < smallestSoFar) {
				smallestSoFar = iter.next().getNbOfUnits();
				smallestFaction = iter.next();
			}
		}
		return smallestFaction;
	}
	
	/**
	 * Remove the given Unit from this World.
	 * 
	 * @param unit
	 * 		The Unit to remove.
	 */
	public void removeUnit(Unit unit) {
		unit.getFaction().removeUnit(unit);
		this.unitSet.remove(unit);
		unit.removeObjectFromWorld();
	}
	
	/**
	 * Return the active Units of this World.
	 * @return
	 */
	@Basic @Raw
	public Set<Unit> getActiveUnits() {
		return this.unitSet;
	}
	
	public void spawnBoulder(Cube cube) {
		Vector position = cube.getPosition();
		Boulder newBoulder = new Boulder(position);
		this.resourceSet.add(newBoulder);
		newBoulder.addObjectToWorld(this);
	}
	
	public void removeResource(Resource resource) {
		this.resourceSet.remove(resource);
	}
	
	/**
	 * Return the active Resources of this World.
	 * @return
	 */
	@Basic @Raw
	public Set<Resource> getResources() {
		return this.resourceSet;
	}
	
	public void spawnLog(Cube cube) {
		Vector position = cube.getPosition();
		Log newLog = new Log(position);
		this.resourceSet.add(newLog);
		newLog.addObjectToWorld(this);
	}
	
	/**
	 * Return the active Logs of this World.
	 * @return
	 */
	@Basic @Raw
	public Set<Log> getLogs() {
		Log log = new Log(new Vector(0,0,0));
		return (Set<Log>) this.getResourceOfType(log);
	}
	
	public Set<Boulder> getBoulders() {
		Boulder boulder = new Boulder(new Vector(0,0,0));
		return (Set<Boulder>) this.getResourceOfType(boulder);
	}
	
	public Set<? extends Resource> getResourceOfType(Resource r){
		return r.getAll(resourceSet);
	}

	/**
	 * Check whether the given coordinates are within the boundaries of this World.
	 * 
	 * @param x
	 * 			The given X-coordinate to check.
	 * @param y
	 * 			The given Y-coordinate to check.
	 * @param z
	 * 			The given Z-coordinate to check.
	 * @return	Returns true if and only if the coordinates are within the boundaries of this World.
	 * 			|return == ((x < this.MAX_X) && (y < this.MAX_Y) && (z < MAX_Z) &&
	 * 			|			(x >= MIN_X) && (y >= MIN_Y) && (z >= MIN_Z))
	 */
	public boolean isWithinWorld(double x, double y, double z) {
		if ((x < this.MAX_X) && (y < this.MAX_Y) && (z < MAX_Z) &&
				(x >= MIN_X) && (y >= MIN_Y) && (z >= MIN_Z))
			return true;
		else
			return false;
	}
	
	/**
	 * Return whether the given Cube is neighbouring a solid Cube.
	 * 
	 * @param givenCube
	 * 			The Cube to check.
	 * @return True if and only if at least one of the neighbouring Cubes is solid.
	 * 			| boolean bool = false
	 * 			| for (Cube neighbour : neighbours) {
				|	if (neighbour.isSolid())
				|		bool = true
				| }
				| result == bool
	 */
	public boolean isNearToSolid(Cube givenCube) {
		if (this.isAboveSolidGround(givenCube))
			return true;
		ArrayList<Cube> neighbours = givenCube.getNeighbouringCubes();
		for (Cube neighbour : neighbours) {
			if (neighbour.isSolid())
				return true;
		}
		return false;
	}
	

	public void advanceTime(double dt) throws IllegalArgumentException, UnreachablePositionException {
		Iterator<Unit> Units = this.getActiveUnits().iterator();
		Iterator<Log>	Logs = this.getLogs().iterator();
		Iterator<Boulder> Boulder = this.getBoulders().iterator();
		
		while (Units.hasNext()) {
			Unit unit = (Unit) Units.next();
			unit.advanceTime(dt);
		}
		while (Logs.hasNext()) {
			Log log = (Log) Logs.next();
			log.advanceTime(dt);
		}
		while (Boulder.hasNext()) {
			Boulder boulder = (Boulder) Boulder.next();
			boulder.advanceTime(dt);
		}
	}

	public void addResource(Resource resource) {
		this.resourceSet.add(resource);
	}
}
