package hillbillies.model.factory.subclassesExpression;

import hillbillies.model.factory.Expression;
import hillbillies.part3.programs.SourceLocation;

public class TrueExpression<T> extends Expression<Boolean, T> {

	public TrueExpression(SourceLocation sourceLocation) {
		super(sourceLocation);
	}
	
	@Override
	public Boolean execute(T t){
		return true;
	}
}
