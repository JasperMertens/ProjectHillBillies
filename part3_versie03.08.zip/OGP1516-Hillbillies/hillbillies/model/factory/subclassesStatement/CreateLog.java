package hillbillies.model.factory.subclassesStatement;

import hillbillies.model.Unit;
import hillbillies.model.factory.Statement;
import hillbillies.part3.programs.SourceLocation;

public class CreateLog extends Statement {

	public CreateLog(SourceLocation sourceLocation) {
		super(sourceLocation);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void execute(Unit unit) {
		// TODO Auto-generated method stub

	}

}
