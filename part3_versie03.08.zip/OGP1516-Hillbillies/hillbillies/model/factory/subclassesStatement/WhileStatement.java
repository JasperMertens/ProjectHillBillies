package hillbillies.model.factory.subclassesStatement;

import hillbillies.model.Unit;
import hillbillies.model.factory.Expression;
import hillbillies.model.factory.Statement;
import hillbillies.part3.programs.SourceLocation;

public class WhileStatement extends Statement {

	private Expression<Boolean> condition;
	private Statement body;

	public WhileStatement(Expression<Boolean> condition, Statement body, SourceLocation sourceLocation) {
		super(sourceLocation);
		this.condition = condition;
		this.body = body;
	}

	@Override
	public void execute(Unit unit) {
			this.body.execute(unit);
	}

	@Override
	public Statement getNext(Unit unit) {
		if (this.condition.execute(unit))
			return this;
		return null;
	}

}
