package hillbillies.model.factory.subclassesStatement;

import java.util.Arrays;

import hillbillies.model.Unit;
import hillbillies.model.factory.Expression;
import hillbillies.model.factory.Statement;
import hillbillies.part3.programs.SourceLocation;
import ogp.framework.util.ModelException;

public class Follow extends Statement {

	private Expression<Unit> unitToFollow;

	public Follow(Expression<Unit> unit, SourceLocation sourceLocation) {
		super(sourceLocation);
		this.unitToFollow = unit;
	}

	@Override
	public void execute(Unit unit) {
		int[] targetLocation = this.unitToFollow.execute(unit).getCurrentCubeCoordinate();
		try {
			this.getFacade().moveTo(unit, targetLocation);
		} catch (ModelException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public Statement getNext(Unit unit) {
		int[] targetLocation = this.unitToFollow.execute(unit).getCurrentCubeCoordinate();
		if (!Arrays.equals(targetLocation, unit.getCurrentCubeCoordinate()))
			return this;
		return null;
	}

}
