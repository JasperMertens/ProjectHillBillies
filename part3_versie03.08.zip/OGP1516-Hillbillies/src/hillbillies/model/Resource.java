package hillbillies.model;

import java.util.Random;
import java.util.Set;

import be.kuleuven.cs.som.annotate.Basic;

/**
 * A class of Resources, with given position and World where they exist.
 * 
 * @version 2.0
 * @author Zeno Gillis, Jasper Mertens
 */
public abstract class Resource extends WorldObject{

	protected Resource(Vector position) {
		super(position);
		this.setRandomWeight();
	}
	
	/**
	 *
	 * Returns a set of it's current subclass from a set of Resources
	 */
	//filters resources to the wanted resources
	public abstract Set<? extends Resource> getAll(Set<Resource> set);
	
	private void setRandomWeight() {
		Random rand = new Random();
		int randomWeight = rand.nextInt(41) + 10;
		this.setWeight(randomWeight);
	}
	
	@Override
	protected boolean canFall() {
		if (!this.getWorld().isAboveSolidGround(this.getCurrentCube()) || this.isFalling()){
			return true;
		}
		return false;
	}
	
	/**
	 * Add this WorldObject to the given World.
	 * 
	 * @param world
	 * 		The World to add the current WorldObject to.
	 * @throws IllegalPositionException
	 * 			The position of this WorldObject is not a valid position in the given World.
	 */
	@Override
	public void addObjectToWorld(World world) throws IllegalPositionException{
		super.addObjectToWorld(world);
		this.getCurrentCube().addResource(this);
		this.getWorld().addResource(this);
	}
	
	/**
	 * Removes this Resource from its current World.
	 * 
	 * @post This Resource is removed from its World.
	 * 		| new.getWorld() == null
	 * @throws IllegalStateException
	 * 			This Resource doesn't currently belong to a World.
	 * 			| this.getWorld() == null
	 */
	@Override
	public void removeObjectFromWorld() throws IllegalStateException {
		if (this.getWorld() == null)
			throw new IllegalStateException();
		this.getCurrentCube().removeResource(this);
		this.getWorld().removeResource(this);
		super.removeObjectFromWorld();
	}
	@Override
	public void setVectorPosition(Vector position, World world) throws IllegalPositionException {
		Cube oldCube = world.getCube(this.getCurrentCubeCoordinate());
		super.setVectorPosition(position, world);
		Cube newCube = world.getCube(position.getRoundDown());
		if (!oldCube.isEqualTo(newCube)){
			oldCube.removeResource(this);
			newCube.addResource(this);
		}
	}
}
