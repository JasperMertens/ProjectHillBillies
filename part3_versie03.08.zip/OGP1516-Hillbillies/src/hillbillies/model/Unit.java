package hillbillies.model;

import java.util.*;

import be.kuleuven.cs.som.annotate.Basic;
import be.kuleuven.cs.som.annotate.Raw;
import hillbillies.model.factory.Expression;
import hillbillies.model.factory.Statement;

/**
 * A class of Units.
 * 
 * @invar The position of each Unit must be a valid position for any Unit. 
 *        	| isValidPosition(getPosition())
 * @invar The name of each Unit must be a valid name for any Unit. 
 *       	| isValidName(getName())
 * @invar The health of each Unit must be a valid health for any Unit. 
 *       	| isValidCondition(getHealth())
 * @invar The stamina of each Unit must be a valid stamina for any Unit. 
 *       	| isValidCondition(getStamina())
 * @invar The orientation of each Unit must be a valid orientation for any Unit.
 *       	| isValidOrientation(getOrientation())
 * @invar The status of each Unit must be a valid status for any Unit. 
 *      	| isValidStatus(getStatus())
 * @invar A Unit can only carry one Resource at a time.
 * 			| this.resource 
 */
public class Unit extends WorldObject{
// TODO destructor
	/**
	 * Constants for naming the different terrain types.
	 */
	static final int AIR = 0;
	static final int ROCK = 1;
	static final int TREE = 2;
	static final int WORKSHOP = 3;
	
	/**
	 * Variable registering all legal statuses of this Unit.
	 */
	private final static ArrayList<String> legalStatus = new ArrayList<>();
	
	/**
	 * Variable registering the health of this Unit.
	 */
	private int health;
	/**
	 * Variable registering the stamina of this Unit.
	 */
	private int stamina;
	/**
	 * Variable registering the name of this Unit.
	 */
	private String name;
	/**
	 * Variable that multiplies the walking speed.
	 */
	private int sprint = 1;
	/**
	 * Variable registering the velocity of this Unit as a Vector.
	 */
	private Vector currentVelocity = new Vector(0,0,0);
	/**
	 * Variable registering the base velocity of this Unit. This may change when
	 * a Unit develops his strength and/or agility and/or weight.
	 */
	private double baseVelocity;
	/**
	 * Variable registering the weight of this unit.
	 */
	private int weight;
	/**
	 * Variable registering the strength of this unit.
	 */
	private int strength;
	/**
	 * Variable registering the agility of this unit.
	 */
	private int agility;
	/**
	 * Variable registering the toughness of this unit.
	 */
	private int toughness;
	private int maxCondition;
	/**
	 * Variable registering the orientation of this Unit.
	 */
	private float orientation;
	/**
	 * Constant registering the maximal initial value for an attribute of this Unit.
	 */
	private static final int MAX_INIT_ATTR = 100;
	/**
	 * Constant registering the maximal initial value for an attribute of this Unit.
	 */
	private static final int MIN_INIT_ATTR = 25;
	/**
	 * Constant registering the minimal value for an attribute of this Unit.
	 */
	private static final int MIN_ATTR_VALUE = 1;
	/**
	 * Constant registering the maximal value for an attribute of this Unit.
	 */
	private static final int MAX_ATTR_VALUE = 200;
	/**
	 * An enumeration of possible states that a Unit can have.
	 * 
	 * @author Zeno Gillis, Jasper Mertens
	 *
	 */
	private enum Status {
		STANDING, RESTING, MOVING, ATTACKING,
		WORKING, ATTACKED, FALLING
	}
	
	/**
	 * Variable registering the status of this Unit, initially set to standing.
	 */
	private Status currentStatus = Status.STANDING;
	/**
	 * Variable registering the next status for this Unit, initially set to standing.
	 */
	private Status nextStatus = Status.STANDING;
	/**
	 * Variable registering if a Unit is moving to an adjacent cube.
	 */
	// As long as this variable is true, invocations of MoveToAdjacent 
	//	for this Unit shall be ignored.
	private boolean isMovingToAdjacent = false;
	/**
	 * Variable registering the target position where a Unit is moving to, initially set to null.
	 */
	private int[] targetPosition = null;
	/**
	 * Variable registering the centre of the adjacent target Cube of this Unit.
	 */
	private Vector targetAdjacent;
	/**
	 * Constant registering the duration after which a Unit should rest.
	 */
	private double autoRest = 180;
	/**
	 * Variable registering if a Unit has initiated rest, initially set to false.
	 */
	private boolean initialRest = false;
	/**
	 * Variable registering the time for a Unit to retrieve one health point.
	 */
	// Time to gain one HP
	private double healthGain;
	/**
	 * Variable registering the time for a Unit to retrieve one stamina point.
	 */
	// Time to gain one SP
	private double staminaGain;
	/**
	 * Variable registering the time a Unit needs for a certain activity.
	 */
	private float activityTime;
	/**
	 * Variable registering all default behaviors of this Unit.
	 */
	private static final ArrayList<String> defaultBehavior = new ArrayList<>();
	private static final int ARMORWEIGHTBONUS = 4;
	private static final int ARMORTOUGNESSBONUS = 5;

	/**
	 * Variable registering the defaultBehavior of this Unit.
	 */
	private boolean defaultBehaviourEnabled;
	/**
	 * Variable registering the attacking Unit.
	 */
	private Unit attacker;
	/**
	 * Variable registering the defending Unit.
	 */
	private Unit defender;
	/**
	 * Variable registering the time a Unit is resting.
	 */
	private double restTime = 0;
	/**
	 * Variable registering the time a Unit is sprinting.
	 */
	private double sprintTime = 0;
	/**
	 * Variable registering the time a Unit is conducting an activity.
	 */
	private double actionTime = 0;
	/**
	 * Variable registering whether this Unit is currently carrying out a default behaviour.
	 */
	private boolean isBehavingDefault = false;
	
	/**
	 * Variable registering to which Faction this Unit belongs.
	 */
	private Faction faction;
	
	/**
	 * Map registering the cost to go to this Cube as value and the coordinates of this Cube as key,
	 *  for all the Cubes found in the search algorithm.
	 */
	private Map<String, Integer> queueMap = new HashMap<>();
	
	/**
	 * List containing the coordinates of all Cubes found in the search algorithm.
	 */
	private LinkedList<String> queueKeys = new LinkedList<>();
	
	/**
	 * Variable registering the points of experience this Unit has gathered.
	 */
	private int experiencePoints = 0;

	/**
	 * Variable registering the Resource this Unit is carrying.
	 */
	private Resource resource;
	
	/**
	 * Variable registering the Cube on which this Unit is working.
	 */
	private Cube targetWorkingCube;
	
	/**
	 * Variable registering the Task this Unit currently is working on.
	 */
	private Task taskToDo;
	
//	/**
//	 * A map of all variables from a Task.
//	 */
//	private Map<String, Expression<Object>> valueMap = new HashMap<>();
	
	/**
	 * A map of all the types of the variables from a Task.
	 */
	private Map<String, Class<?>> typeMap = new HashMap<>();

	/**
	 * Initialize this new Unit with given position.
	 *
	 * @param position
	 *            The position for this new Unit.
	 * @effect The position of this new Unit is set to the given position as a Vector. 
	 *         	| this.setVectorPositionUnit(position)
	 *         
	 *      Initialize this new Unit with given weight.
	 * 
	 * @param weight
	 *            The weight for this new Unit.
	 * @post If the given weight is a valid weight for any Unit, the weight of
	 *       this new Unit is equal to the given weight. 
	 *       Otherwise, 
	 *       if the weight of this new Unit is less than 25, the weight of this new
	 *       Unit is equal to 25 or
	 *        if the weight of this new Unit is greater
	 *       than 100, the weight of this new Unit is equal to 100 
	 *       | if(isValidWeight(propertyName_Java)) | then new.getWeight() ==
	 *       |	propertyName_Java 
	 *       | else if weight < 25 
	 *       | 	then new.getWeight() == 25
	 *       | else if weight > 100 
	 *       | 	then new.getWeight() == 100
	 * 
	 *       Initialize this new Unit with given strength.
	 * 
	 * @param strength
	 *            The strength for this new Unit.
	 * @post If the given strength is a valid strength for any Unit, the
	 *       strength of this new Unit is equal to the given strength.
	 *       Otherwise,
	 *        if the strength of this new Unit is less than 25, the
	 *       strength of this new Unit is equal to 25 or if the strength of this
	 *       new Unit is greater than 100, the strength of this new Unit is
	 *       equal to 100 
	 *       | if(isValidstrength(propertyName_Java)) 
	 *       | 	then new.getStrength() == propertyName_Java 
	 *       | else if strength < 25 
	 *       | then new.getStrength() == 25 
	 *       | else if strength > 100 
	 *       | then new.getStrength() == 100
	 *       
	 * 
	 *       Initialize this new Unit with given agility.
	 * 
	 * @param agility
	 *            The agility for this new Unit.
	 * @post If the given agility is a valid agility for any Unit, the agility
	 *       of this new Unit is equal to the given agility. Otherwise, if the
	 *       agility of this new Unit is less than 25, the agility of this new
	 *       Unit is equal to 25 or if the agility of this new Unit is greater
	 *       than 100, the agility of this new Unit is equal to 100 
	 *       | if(isValidAgility(propertyName_Java)) 
	 *       | 	then new.getAgility() == propertyName_Java
	 *       | else if Agility < 25 
	 *       |	 then new.getAgility() == 25 
	 *       | else if Agility > 100 
	 *       | 	then new.getAgility() == 100
	 * 
	 *       Initialize this new Unit with given toughness.
	 * 
	 * @param toughness
	 *            The toughness for this new Unit.
	 * @post If the given toughness is a valid toughness for any Unit, the
	 *       toughness of this new Unit is equal to the given toughness.
	 *       Otherwise, if the toughness of this new Unit is less than 25, the
	 *       toughness of this new Unit is equal to 25 or if the toughness of
	 *       this new Unit is greater than 100, the toughness of this new Unit
	 *       is equal to 100 
	 *       | if(isValidToughness(propertyName_Java)) 
	 *       | 	then new.getToughness() == propertyName_Java 
	 *       | else if Toughness < 25 
	 *       |	then new.getToughness() == 25 
	 *       | else if Toughness > 100 
	 *       | 	then new.getToughness() == 100
	 *       
	 *         Initialize this new Unit with given health.
	 * 
	 * @param health
	 *            The health for this new Unit.
	 * @pre The given health must be a valid health for any Unit. 
	 *       | isValidHealth(health)
	 * @post The health of this new Unit is equal to the given health. 
	 *       | new.getHealth() == health
	 *
	 *
	 *       Initialize this new Unit with given stamina.
	 * 
	 * @param stamina
	 *            The stamina for this new Unit.
	 * @pre The given stamina must be a valid stamina for any Unit. 
	 *      | isValidStamina(stamina)
	 * @post The stamina of this new Unit is equal to the given stamina. 
	 *       | new.getStamina() == stamina 
	 *       
	 *       Initialize this new Unit with given name.
	 *
	 * @param name
	 *            The name for this new Unit.
	 * @effect The name of this new Unit is set to the given name.
	 *         | this.setName(name)
	 * 
	 * Initialize this new Unit with a default orientation.
	 *
	 * @effect The orientation of this new Unit is set to PI/2. 
	 *         	| this.setOrientation(Math.PI/2)
	 *         
	 * Initialize this new Unit with a default baseVelocity depending on strength,
	 * 	weight and agility.
	 * @effect The baseVelocity is set to 0.75 * (getStrength() + getAgility()) / (getWeight())
	 * 			| this.updateBaseVelocity(); 
	 * 
	 * Initialize this new Unit with a set of legal statuses which the Unit can assume.
	 * @effect The list of legal statuses is appended with legal statuses.
	 * 			| setLegalStatus();
	 *
	 * Initialize this new Unit with a set of default behaviors which the Unit can assume.
	 * @effect The list of default behaviors is appended with legal default behaviors.
	 * 			| setDefaultBehavior();
	 * 		
	 * Initialize this new Unit with a health gain when it needs to rest depending on the 
	 * 	Unit's toughness.
	 * @effect The health gain is set to (40.0 / (this.getToughness()))
	 * 			| this.resetHealthGain();
	 * 
	 * Initialize this new Unit with a stamina gain when it needs to rest depending on the 
	 * 	Unit's toughness.
	 * @effect The health gain is set to (20.0 / (this.getToughness()))
	 * 			| this.resetStaminaGain();
	 */
	@Raw
	public Unit(String name, int[] position, int weight, int agility, int strength, int toughness,
			boolean enableDefaultBehavior) throws IllegalArgumentException, IllegalPositionException,
				IllegalNameException {
		super(new Vector(position));
		
		this.setOrientation((float) (Math.PI/2));
		this.setName(name);
		
		
		
		
		this.setStrength(ConstrainAttribute(strength));
		this.setAgility(ConstrainAttribute(agility));
		this.setToughness(ConstrainAttribute(toughness));
		this.setWeight(ConstrainAttribute(weight));
		
		this.updateMaxCondition();
		
		this.setHealth(getMaxCondition());
		this.setStamina(getMaxCondition());
		
		
		
		this.resetHealthGain();
		this.resetStaminaRate();
		
		setLegalStatus();
		setDefaultBehavior();
		
		this.updateBaseVelocity();

	}
	
	public boolean isValidAttribute(Integer attribute){
		if ((attribute >= this.getMinAttrValue()) && (attribute <=this.getMaxAttrValue())){
			return true;
		}
		return false;
	}

	/**
	 * Return the weight of this Unit.
	 */
	@Basic
	@Raw
	public int getWeight() {
		return this.weight;
	}

	/**
	 * Set the weight of this Unit to the given weight.
	 * 
	 * @param weight
	 *            The new weight for this Unit.
	 *
	 * @post If the given weight is a valid weight, the weight of this Unit is
	 *       equal to the given weight. 
	 *       | if (isValidWeight(weight)) 
	 *       | then new.getWeight() == weight
	 * @post If the given weight is not a valid weight, the weight of this Unit
	 *       is set to the mean value of the strength and agility of this Unit.
	 *       | if (! isValidWeight(weight)) 
	 *       | then new.getWeight() == (this.strength + this.agility)/2
	 */
	@Basic @Raw @Override
	public void setWeight(int weight) {
		if (!isValidWeight(weight))
			this.weight = (this.getStrength() + this.getAgility()) / 2;
		else
			this.weight = weight;
		// UPDATE MaxHealth & MaxStamina via MaxCondition
		this.updateMaxCondition();
	}

	/**
	 * Return the given attribute, constrained to the legal initial values.
	 * 
	 * @param attribute
	 *            The new attribute for a Unit.
	 * @post If the given attribute exceeds the maximal initial value, the
	 *       attribute is set to the maximal initial value. 
	 *       | if(attribute>MAX_INITIAL) 
	 *       | 	then return MAX_INITIAL ........
	 * @post If the given attribute is smaller then the minimal initial value, the
	 *       attribute is set to the minimal initial value.
	 *       | if(attribute<MIN_INITIAL)
	 *       |	then return MIN_INITAL
	 * @post If the given attribute adheres to the legal initial values, simply return the
	 * 			attribute.
	 * 		 | if( MIN_INITIAL<=attribute<= MAX_INITIAL)
	 * 		 |	then return attribute
	 * @return The constrainedAttribute if necessary, otherwise the given attribute.
	 * 			|result == attribute;
	 */
	@Raw
	// Not static because in the future there might be a hero Unit that starts with bigger values
	// 		as attributes.
	private int ConstrainAttribute(int attribute) {
		if (attribute < this.getMinInitAttr())
			return this.getMinInitAttr();
		if (attribute > this.getMaxInitAttr())
			return this.getMaxInitAttr();
		else
			return attribute;
	}
	/**
	 * Return the minimal value for an attribute.
	 * @return The minimal value that is possible for an attribute.
	 * 			| result == MIN_INIT_ATTR;
	 */
	@Basic
	private int getMinInitAttr() {
		return Unit.MIN_INIT_ATTR;
	}
	/**
	 * Return the maximal value for an attribute.
	 * @return The maximal value that is possible for an attribute.
	 * 			| result == MAX_INIT_ATTR;
	 */
	@Basic
	private int getMaxInitAttr() {
		return Unit.MAX_INIT_ATTR;
	}
	/**
	 * Return the minimal value for an attribute.
	 * @return The minimal value that is possible for an attribute.
	 * 			| result == MIN_ATTR_VALUE;
	 */
	@Basic
	private int getMinAttrValue() {
		return Unit.MIN_ATTR_VALUE;
	}
	/**
	 * Return the maximal value for an attribute.
	 * @return The maximal value that is possible for an attribute.
	 * 			| result == MAX_ATTR_VALUE;
	 */
	@Basic
	private int getMaxAttrValue() {
		return Unit.MAX_ATTR_VALUE;
	}

	/**
	 * Check whether the given weight is a valid weight.
	 * @param weight
	 * @return True if and only if the given weight is greater than
	 * 			the mean value of the Unit's strength and agility.
	 * 			| result == (weight >= (this.strength + this.agility) / 2)
	 */		
	private boolean isValidWeight(int weight) {
		if (weight >= (this.getStrength() + this.getAgility()) / 2)
			return true;
		else
			return false;
	}
	/**
	 * Return the strength of this Unit.
	 */
	@Basic @Raw
	public int getStrength() {
		return this.strength;
	}
	/**
	 * Set the strength of this Unit to the given strength.
	 * 
	 * @param strength
	 * 			The new strength of this Unit.
	 * @post If the given strength is a valid strength, the strength of this Unit is
	 *       equal to the given strength. 
	 *       | if (isValidAttribute(strength)) 
	 *       | then new.getStrength() == strength
	 *       
	 * @post If the given strength is not a valid strength and is smaller than
	 * 		 the minimal attribute value , the strength of this Unit
	 *       is set to the minimal attribute value.
	 *       | if (! isValidAttribute(strength) && (strength < MIN_ATTR_VALUE) ) 
	 *       | then new.getStrength() == MIN_ATTR_VALUE;
	 * @post If the given strength is not a valid strength and is greater than
	 * 		 the maximal attribute value , the strength of this Unit
	 *       is set to the maximal attribute value.
	 *       | if (! isValidAttribute(strength) && (strength < MAX_ATTR_VALUE) ) 
	 *       | then new.getStrength() == MAX_ATTR_VALUE;
	 */
	@Basic @Raw 
	public void setStrength(int strength) {
		if ((!this.isValidAttribute(strength)) && (strength < this.getMinAttrValue()))  {
			this.strength = this.getMinAttrValue();
		}
		else if (!this.isValidAttribute(strength) && strength > this.getMaxAttrValue())  {
			this.strength = this.getMaxAttrValue();
		}
		else{
			this.strength = strength;
		}
		//UPDATE WEIGHT
		this.setWeight(this.getWeight());
		
	}
	/**
	 * Return the agility of this Unit.
	 */
	@Basic @Raw
	public int getAgility() {
		return this.agility;

	}
	/**
	 * Set the agility of this Unit to the given strength.
	 * 
	 * @param strenagilitygth
	 * 			The new agility of this Unit.
	 * @post If the given agility is a valid agility, the agility of this Unit is
	 *       equal to the given agility. 
	 *       | if (isValidAttribute(agility)) 
	 *       | then new.getAgility() == agility
	 *       
	 * @post If the given agility is not a valid agility and is smaller than
	 * 		 the minimal attribute value , the agility of this Unit
	 *       is set to the minimal attribute value.
	 *       | if (! isValidAttribute(agility) && (agility < MIN_ATTR_VALUE) ) 
	 *       | then new.getAgility() == MIN_ATTR_VALUE;
	 * @post If the given agility is not a valid agility and is greater than
	 * 		 the maximal attribute value , the agility of this Unit
	 *       is set to the maximal attribute value.
	 *       | if (! isValidAttribute(agility) && (agility < MAX_ATTR_VALUE) ) 
	 *       | then new.getAgility() == MAX_ATTR_VALUE;
	 */
	@Basic @Raw
	public void setAgility(int agility) {
		if ((!this.isValidAttribute(agility)) && (agility < this.getMinAttrValue()))  {
			this.agility = this.getMinAttrValue();
		}
		else if (!this.isValidAttribute(agility) && agility > this.getMaxAttrValue())  {
			this.agility = this.getMaxAttrValue();
		}
		else{
			this.agility = agility;
		}
		//UPDATE WEIGHT
		this.setWeight(this.getWeight());
	}
	/**
	 * Return the strength of this Unit.
	 */
	@Basic @Raw
	public int getToughness() {
		return this.toughness;
	}
	/**
	 * Set the toughness of this Unit to the given strength.
	 * 
	 * @param strentoughnessgth
	 * 			The new toughness of this Unit.
	 * @post If the given toughness is a valid toughness, the toughness of this Unit is
	 *       equal to the given toughness. 
	 *       | if (isValidAttribute(toughness)) 
	 *       | then new.getToughness() == toughness
	 *       
	 * @post If the given toughness is not a valid toughness and is smaller than
	 * 		 the minimal attribute value , the toughness of this Unit
	 *       is set to the minimal attribute value.
	 *       | if (! isValidAttribute(toughness) && (toughness < MIN_ATTR_VALUE) ) 
	 *       | then new.getToughness() == MIN_ATTR_VALUE;
	 * @post If the given toughness is not a valid toughness and is greater than
	 * 		 the maximal attribute value , the toughness of this Unit
	 *       is set to the maximal attribute value.
	 *       | if (! isValidAttribute(toughness) && (toughness < MAX_ATTR_VALUE) ) 
	 *       | then new.getToughness() == MAX_ATTR_VALUE;
	 */
	@Basic @Raw
	public void setToughness(int toughness) {
		if ((!this.isValidAttribute(toughness)) && (toughness < this.getMinAttrValue()))  {
			this.toughness = this.getMinAttrValue();
		}
		else if (!this.isValidAttribute(toughness) && toughness > this.getMaxAttrValue())  {
			this.toughness = this.getMaxAttrValue();
		}
		else{
			this.toughness = toughness;
		}
		// UPDATE MaxHealth & MaxStamina via MaxCondition
		this.updateMaxCondition();
	}
	/**
	 * Return the maximum value for health and stamina for this Unit.
	 * @return The maximum value for health and stamina for this Unit
	 * 			is equal to (0.02 * (getWeight() * getToughness())) rounded up.
	 * 			| result == Math.ceil(0.02 * (getWeight() * getToughness())).
	 */
	//Not immutable because Weight and Toughness are mutable.
	@Basic @Raw 
	public int getMaxCondition() {
		return this.maxCondition;
	}
	/**
	 * 
	 * @param maxCondition
	 * 			The new maxCondition for this Unit.
	 * @post The maxCondition of this Unit is equal to the given maxCondition
	 * 		 | new.getMaxCondition() == maxCondition 
	 */
	private void updateMaxCondition() {
		int max = (int) (Math.ceil((0.02 * (this.getWeight() * this.getToughness()))));
		this.maxCondition = max;
		
	}

	/**
	 * Return the name of this Unit.
	 */
	@Basic
	@Raw
	public String getName() {
		return this.name;
	}

	/**
	 * Check whether the given name is a valid name for any Unit.
	 * 
	 * @param name
	 *            The name to check.
	 * @return True if the name starts with a Capital letter and is at least 2 characters long
	 * 			and if every character of the name 
	 * 			is or a letter or a space or an ' or an ", false otherwise.
	 * 			| if (name.charAt(0) == UpperCase && name.length >= 2)
	 * 			| 	then 
	 * 			| 		changeableResult == false
	 * 			| 		for character in name
	 * 			| 			do if (Character.isLetter(name.charAt(i)))
	 * 			|					then changeableResult == true
	 * 			|				else if  (Character.isSpaceChar(name.charAt(i)))
	 * 			|					then changeableResult == true
	 * 			|				else if  (name.charAt(i) == ')
	 * 			|					then changeableResult == true
	 *  		|				else if  (name.charAt(i) == ")
	 * 			|					then changeableResult == true
	 * 			|				else result == false
	 * 			| 		endFor result == changebleResult
	 * 			| result == false
	 */
	public static boolean isValidName(String name) {
		
		if (Character.isUpperCase(name.charAt(0)) && (name.length() >= 2)) {
			boolean result = false;
			for (int i = 0; i < name.length(); i++) {
				if (Character.isLetter(name.charAt(i))){
					result = true;
				}
				else if (Character.isSpaceChar(name.charAt(i))){
					result = true;
				}
				else if (name.charAt(i) == '\''){
					result = true;
				}
				else if (name.charAt(i) == '\"') {
					result = true;
				}
				else{
					return false;
				}
			}
			return result;
		}
		return false;

	}

	/**
	 * Set the name of this Unit to the given name.
	 * 
	 * @param name
	 *            The new name for this Unit.
	 * @post The name of this Unit is equal to the given name. 
	 *       | new.getName() == name
	 * @throws IllegalNameException
	 *             The given name is not a valid name for any Unit.
	 *             | !isValidName(getName())
	 */
	@Raw
	public void setName(String name) throws IllegalNameException {
		if (!isValidName(name))
			throw new IllegalNameException(name);
		this.name = name;
	}
	
	/**
	 * Set the Faction for this Unit to the given Faction.
	 * 
	 * @param faction
	 * 			The new faction for this Unit.
	 * @post The faction to which this Unit belongs is equal to the given faction.
	 * 		 | new.getFaction() == faction
	 */
	@Basic @Raw
	public void setFaction(Faction faction) {
		this.faction = faction;
	}
	
	/**
	 * Return the Faction of this Unit.
	 */
	@Basic @Raw
	public Faction getFaction() {
		return this.faction;
	}

	/**
	 * Check whether the given condition is a valid condition for any Unit.
	 * 
	 * @param condition
	 *            The condition to check.
	 * @return True if the given condition is not negative and is smaller or equal to the 
	 * 			maximal value for a Condition.
	 * 			 |return == (condition >= 0) && (condition <= this.getMaxCondition())
	 */
	@Basic
	public boolean isValidCondition(int condition) {
		return((condition >= 0) && (condition <= this.getMaxCondition()));
	}

	/**
	 * Return the health of this Unit.
	 */
	@Basic
	@Raw
	public int getHealth() {
		return this.health;
	}

	/**
	 * Set the health of this Unit to the given health.
	 * 
	 * @param health
	 *            The new health for this Unit.
	 * @pre The given health must be a valid health for any Unit. 
	 *      | isValidHealth(health)
	 * @post The health of this Unit is equal to the given health. 
	 *       | new.getHealth() == health
	 */
	@Basic
	@Raw
	public void setHealth(int health) {
		assert isValidCondition(health) : 
			"Precondition was violated, health is not a valid condition.";
		this.health = health;
		if (health <= 0)
			this.getWorld().removeUnit(this);
	}

	/**
	 * Return the stamina of this Unit.
	 */
	@Basic
	@Raw
	public int getStamina() {
		return this.stamina;
	}

	/**
	 * Set the stamina of this Unit to the given stamina.
	 * 
	 * @param stamina
	 *            The new stamina for this Unit.
	 * @pre The given stamina must be a valid stamina for any Unit.
	 *      | isValidStamina(stamina)
	 * @post The stamina of this Unit is equal to the given stamina.
	 *       | new.getStamina() == stamina
	 */
	@Raw
	public void setStamina(int stamina) {
		assert isValidCondition(stamina);
		this.stamina = stamina;
	}


	/**
	 * Return the orientation of this Unit.
	 */
	@Basic
	@Raw
	public float getOrientation() {
		return this.orientation;
	}

	/**
	 * Check whether the given orientation is a valid orientation for any Unit.
	 * 
	 * @param orientation
	 *            The orientation to check.
	 * @return 	Returns true if and only if the value of the orientation lies between
	 * 				0 and 2*PI.
	 * 			| result == (orientation <= 2 * Math.PI) && (orientation >= 0)
	 */
	public static boolean isValidOrientation(float orientation) {
		if ((orientation <= 2 * Math.PI) && (orientation >= 0))
			return true;
		else
			return false;
	}

	/** 
	 * Set the orientation of this Unit to the given orientation.
	 * 
	 * @param orientation
	 *            The new orientation for this Unit.
	 * @post If the given orientation is a valid orientation for any Unit, the
	 *       orientation of this new Unit is equal to the given orientation.
	 *       | if (isValidOrientation(orientation)) 
	 *       | 	then new.getOrientation() == orientation
	 */
	@Raw
	public void setOrientation(float orientation) {
		if (isValidOrientation(orientation))
			this.orientation = orientation;
		else
			this.orientation = (float) (orientation % (2 * Math.PI));
	}


	/**
	 /**
	 * Update the status and the position of this Unit. 
	 * Advance the time for this Unit.
	 * 
	 * @param time
	 * 			The amount of time to advance the game time with.
	 *
	 * @throws IllegalArgumentException
	 * 			| if ((!isValidAdvanceTime(time)) {
	 *			|	then throw new IllegalArgumentException();
	 * 
	 * If 3 minutes of game time have passed the Unit starts resting to recover its lost 
	 * 	Health and Stamina else the 3 minutes will be diminished with the time given in the
	 * 	argument.
	 * If the Unit is interrupted, update the status of this Unit to the interrupting activity.
	 * If the Unit's status is resting, count the time the Unit is resting and start the initial rest
	 * 	in which the Unit cannot be interrupted. Else continue resting to regain lost Health and 
	 * 	Stamina.
	 * Else if the Unit's status is moving, check if the default behavior is enabled, if this is enabled
	 * 	give the Unit a chance to start sprinting.
	 * 	If the Unit is sprinting while moving, diminish his current stamina until he stops moving
	 * 		or the Stamina pool reaches 0, if his pool reaches 0 the Unit stops sprinting.
	 * 	While the Unit has not arrived at the target Adjacent cube keep updating the position and
	 * 		orientation of the Unit. If the Unit has arrived at the target Adjacent cube, and 
	 * 		there is no further destination than this target Adjacent, stop moving. If there is  
	 * 		a further destination than this target Adjacent, keep on moving towards that destination.
	 * 
	 */
	@Override
	public void advanceTime(double time) throws IllegalArgumentException, UnreachablePositionException{
		if (!isValidAdvanceTime(time)) {
			throw new IllegalArgumentException();
		}
		super.advanceTime(time);
		// Let the Unit rest automatically if three minutes of game time have passed.
		if ((this.autoRest - time) <= 0) {
			this.rest();
			this.updateStatus();
			this.autoRest = 180 + this.autoRest - time;
		} 
		else {
			this.autoRest -= time;
		}
		// Update the status of this Unit.
		if (this.isInterrupted()) {
			this.updateStatus();
		}
		if (this.isResting()){
			this.restTime += time;
			// If the Unit wants to rest, see to it that the initial rest period is complete.
			if (this.initialRest){
				if (this.restTime >= this.getHealthGain()) {
					this.initialRest = false;
					if (this.getHealth() != this.getMaxCondition()) {
						this.setHealth(this.getHealth() + 1);
						this.restTime -= this.getHealthGain();
					}
					else if (this.getStamina() != this.getMaxCondition()) {
						if (this.restTime >= this.getStaminaRate()) {
							int multiple_int = (int) (this.restTime/this.getStaminaRate());
							if ((this.getStamina() + multiple_int) > this.getMaxCondition()) {
								this.setStamina(this.getMaxCondition());
							}
							else {
								this.setStamina(this.getStamina() + multiple_int);
							}
							this.restTime -= this.getStaminaRate();
						} 
					}
				}
			}
			else {
				// Continue to let the Unit rest until he is full health, or does something else.
				if (this.getHealth() != this.getMaxCondition()) {
					if (this.restTime >= this.getHealthGain()) {
						this.setHealth(this.getHealth() + 1);
						this.restTime -= this.getHealthGain();
					}
				}
				// Continue to let the Unit rest until he is full stamina, or does something else.
				else if (this.getStamina() != this.getMaxCondition()) {
					if (this.restTime >= this.getStaminaRate()) {
						// niet per se +1 stamina maar ook meerdere.
						int multiple_int = (int) (this.restTime/this.getStaminaRate());
						if ((this.getStamina() + multiple_int) > this.getMaxCondition()) {
							this.setStamina(this.getMaxCondition());
						}
						else {
							this.setStamina(this.getStamina() + multiple_int);
						}
						this.restTime -= this.getStaminaRate();
					} 
				}
				else {
					this.standStill();
				}
			}
		}
		// Update the position of a moving Unit, can be interrupted by other tasks
		// 			after the Unit has reached the center of his target cube.
		else if (this.isMoving()) {
			if (this.isBehavingDefault) {
				Random rn = new Random();
				int chance = rn.nextInt(100);
				if (chance == 0){
					this.startSprint();
				}
			}
			if (this.isSprinting()) {
				if (this.getStamina() > 0) {
					this.sprintTime += time;
					if (this.sprintTime >= 0.1) {
						int multiple_int = (int) (this.sprintTime*10);
						if ((this.getStamina() - multiple_int) < 0) {
							this.setStamina(0);
						}
						else {
							this.setStamina(this.getStamina() - multiple_int);
						}
						this.sprintTime -= 0.1;
					}
				}
				else {
					this.stopSprint();
				}
			}
			double distanceToMove = this.getCurrentVelocityVector().getMultipleVector(time*this.sprint).getMagnitude();
			if (!hasArrived(this.getTargetAdjacent(), distanceToMove)) {
					this.updatePosition(time);
					this.updateOrientation();
			}
			else{
				// give experience because the Unit reached TargetAdjacent
				this.setExperiencePoints(this.getExperiencePoints() + 1);
				if ((this.getTargetPosition() == null) || 
						(Arrays.equals(this.getCurrentCubeCoordinate(), this.getTargetPosition()))) {
					this.standStill();
					this.setVectorPosition(this.getTargetAdjacent(), this.getWorld());
					this.setTargetPosition(null);
				}
				else {
					this.queueMap.clear();
					this.queueKeys.clear();
					this.moveTo(this.getTargetPosition());
				}
			}
		}
//		else if (this.unitIsFalling()){
//			double distanceToMove = this.getCurrentVelocityVector().getMultipleVector(time).getMagnitude();
//			if (!hasArrived(this.getTargetAdjacent(), distanceToMove)) {
//				try{
//					this.updatePosition(time);
//					this.updateOrientation();
//				}
//				catch(IllegalPositionException exc){
//					double x = this.getCurrentCube().getCentreCube().getX();
//					double y = this.getCurrentCube().getCentreCube().getY();
//					double z = this.getCurrentCube().getCentreCube().getZ();
//					Vector position = new Vector(x,y,z-1);
//					this.setVectorPosition(position, this.getWorld());
//				}
//			}
//			else{
//				// IF the Unit has fallen to an adjacentCube, it shall lose 10 Hp. 
//				if (this.getHealth() <= 10)
//					this.setHealth(0);
//				this.setHealth(this.getHealth()-10);
//				if ((this.getTargetPosition() == null) || 
//						(Arrays.equals(this.getCurrentCubeCoordinate(), this.getTargetPosition()))) {
//					this.standStill();
//					this.setVectorPosition(this.getTargetAdjacent(), this.getWorld());
//					this.setTargetPosition(null);
//					this.setNextStatus(Status.STANDING);
//				}
//				else {
//					this.queueMap.clear();
//					this.queueKeys.clear();
//					this.moveTo(this.getTargetPosition());
//				}
//			}
//			
//		}
		// Let the Unit perform it's task for a certain time.
		else if (this.isWorking() || this.isAttacking()) {
			this.actionTime += time;
			if (this.actionTime >= this.getActivityTime()) {
				if (this.isWorking()){
					// Unit has completed a working task, give proper completions:
					if ((this.isCarryingResource()) && (!this.targetWorkingCube.isSolid())){
						// drop Resource at target position, decrease weight
						// give 10 experience points!!
						// check in WorkAt if the resource can be dropped at the targetCube 
						// then drop it if it's possible, weight decrease in dropResource()
						this.setWeight(this.getWeight() - this.resource.getWeight());
						this.dropResource();
						this.setExperiencePoints(this.getExperiencePoints() + 10);
						this.updateBaseVelocity();
						System.out.println("drop");
					}
					else if ((this.targetWorkingCube.getTerrainType() == WORKSHOP) && 
							(this.targetWorkingCube.containsLog() && this.targetWorkingCube.containsBoulder())){
						//						 improve equipment, consume Boulder and Log from workshop,
						//						 		increase weight + toughness of Unit.
						//						 give 10 experience points!!
						this.targetWorkingCube.pickUpBoulder();
						this.targetWorkingCube.pickUpLog();
						this.resource = null;
						this.setWeight(this.getWeight() + ARMORWEIGHTBONUS);
						this.setToughness(this.getToughness() + ARMORTOUGNESSBONUS);
						this.updateBaseVelocity();
						this.setExperiencePoints(this.getExperiencePoints() + 10);
						System.out.println("improve");
					}
					else if (this.targetWorkingCube.containsBoulder()){
						// pick up Boulder, increase weight(in pickUpResource()
						// give 10 experience points!!
						this.resource = this.targetWorkingCube.pickUpBoulder();
						this.setWeight(this.getWeight() + this.resource.getWeight());
						this.updateBaseVelocity();
						this.setExperiencePoints(this.getExperiencePoints() + 10);
						System.out.println("pick up boulder");
					}
					else if (this.targetWorkingCube.containsLog()){
						// pick up Log, increase weight(in pickUpResource()
						// give 10 experience points!!
						this.resource = this.targetWorkingCube.pickUpLog();
						this.setWeight(this.getWeight() + this.resource.getWeight());
						this.updateBaseVelocity();
						this.setExperiencePoints(this.getExperiencePoints() + 10);
						System.out.println("pick up log");
					}
					else if (this.targetWorkingCube.getTerrainType() == TREE) {
						// caveIn, spawn Log
						// give 10 experience points!!
						this.targetWorkingCube.collapse();
						this.setExperiencePoints(this.getExperiencePoints() + 10);
						System.out.println("chop tree");
					}
					else if (this.targetWorkingCube.getTerrainType() == ROCK) {
						// caveIn, spawn Boulder
						// give 10 experience points!!
						this.targetWorkingCube.collapse();
						this.setExperiencePoints(this.getExperiencePoints() + 10);
						System.out.println("mine rock");
					}
				}
				this.standStill();
			}
		}
		// Check if the standing Unit still has a target position to move to.
		if (this.isStanding()) {
			if (this.getTargetPosition() != null) {
				this.moveTo(this.getTargetPosition());
			}
//			// Check if the Unit needs to fall.
//			else if (!this.getWorld().isNearToSolid(this.getCurrentCube()) && !this.getWorld().isAboveSolidGround(this.getCurrentCube())){
////				this.setFalling(true);
////				this.setNextStatus(Status.FALLING);
////				this.updateStatus();
//				this.fall(time);
//			}
			// Check whether default behavior is enabled.
			else if (this.defaultBehaviourEnabled == true) {
				this.startDefaultBehaviour();
			}
			
		}
		int gatheredExp = this.getExperiencePoints();
		if (gatheredExp >= 10){
			Random rand = new Random();
			int randomNumber = rand.nextInt(3);
			if (randomNumber == 0 ){
				// if attribute is full -> add to other.
				this.setStrength(this.getStrength() + (int) gatheredExp/10);
			}
			else if (randomNumber == 1){
				this.setAgility(this.getAgility() + (int) gatheredExp/10);
			}
			else if (randomNumber == 2){
				this.setToughness(this.getToughness() + (int) gatheredExp/10);
			}
			this.setExperiencePoints(gatheredExp-10);
		}
	}

	
	/**
	 * Return the total weight of this Unit and its load.
	 * 
	 * @return
	 * 		| result == (this.getWeight() + carryWeight)
	 */
	public int getTotalWeight() {
		int carryWeight = 0;
		if (this.resource != null)
			carryWeight = this.resource.getWeight();
		return (this.getWeight() + carryWeight);
	}
	
	/**
	 * Return whether this Unit is carrying a Resource.
	 * 
	 * @return True if and only if the variable resource is active.
	 * 		| result == (this.resource != null)
	 */
	public boolean isCarryingResource() {
		if (Log.class.isInstance(this.resource)){
			return true;
		}
		else if (Boulder.class.isInstance(this.resource)){
			return true;
		}
		return false;
	}
	public boolean isCarryingLog(){
		return (Log.class.isInstance(this.resource));
	}
	public boolean isCarryingBoulder(){
		return (Boulder.class.isInstance(this.resource));
	}
	
	/**
	 * Drop the Resource that this Unit is currently carrying at the target working position.
	 * 
	 * @post The Resource is dropped at the centre of the target working Cube in the World of this Unit.
	 * 		| new.resource.getVectorPosition() == this.targetWorkingCube.getCentreCube()
	 * @post This Unit is no longer carrying the Resource.
	 * 		| new.isCarryingResource() == false
	 * @throws IllegalStateException
	 * 		This Unit isn't currently carrying a Resource.
	 *		| !this.isCarryingResource() 			
	 */
	private void dropResource() throws IllegalStateException {
		if (!this.isCarryingResource())
			throw new IllegalStateException();
		this.resource.setVectorPosition(this.targetWorkingCube.getCentreCube(), this.getWorld());
		this.resource.addObjectToWorld(this.getWorld());
		this.resource = null;
	}
	
	/**
	 * Halt the current actions of this Unit.
	 */
	private void stopAction() {
		if (this.isResting()) {
			this.initialRest = false;
			this.restTime = 0;
		}
		else if (this.isMoving()) {
			this.stopSprint();
			this.setIsMovingToAdjacent(false);
			this.currentVelocity = new Vector(0,0,0);
			this.queueMap.clear();
			this.queueKeys.clear();
		}
		else if (this.isWorking()) {
			this.actionTime = 0;
			this.targetWorkingCube = null;
		}
		else if (this.isAttacking()) {
			this.getDefender().standStill();
			this.getDefender().setAttacker(null);
			this.setDefender(null);
			this.actionTime = 0;
		}
		this.isBehavingDefault = false;
	}
	
	private void setExperiencePoints(int gainedExperiencePoints) {
		this.experiencePoints = gainedExperiencePoints;
	}

	public int getExperiencePoints() {
		return this.experiencePoints ;
	}

	/**
	 * Checks if the given time is a valid time.
	 * @param time
	 * 			The time to check
	 * @return Returns true if and only if the given time lies between 0 and 0.2.
	 * 			|result == (0<=time<=0.2)
	 */
	private boolean isValidAdvanceTime(double time) {
		return ((time>= 0) && (time <= 0.2));
	}
	/**
	 * Returns the time which is needed by this Unit to regain 1 health while resting.
	 * @return
	 */
	@Basic
	public double getHealthGain() {
		return this.healthGain;
	}
	/**
	 * Set the time this Unit needs to regain 1 health while resting.
	 * @param healthRate
	 * 			The time this Unit needs to regain 1 health while resting.
	 */
	@Basic
	private void setHealthGain(double healthRate) {
		this.healthGain = healthRate;
	}
	/**
	 * Reset the time this Unit needs to regain 1 health while resting.
	 */
	@Basic
	private void resetHealthGain() {
		this.healthGain =  (40.0 / (this.getToughness()));
	}
	/**
	 * Returns the time which is needed by this Unit to regain 1 stamina while resting.
	 * @return
	 */
	@Basic
	public double getStaminaRate() {
		return this.staminaGain;
	}
	/**
	 * Set the time this Unit needs to regain 1 stamina while resting.
	 * @param staminaRate
	 * 				The time this Unit needs to regain 1 stamina while resting.
	 */
	@Basic
	private void setStaminaRate(double staminaRate) {
		this.staminaGain = staminaRate;
	}
	/**
	 * Reset the time this Unit needs to regain 1 stamina while resting.
	 */
	@Basic
	private void resetStaminaRate() {
		this.staminaGain = (20.0 / (this.getToughness()));
	}
	
	/**
	 * Return the time it still takes for this Unit to complete his
	 * 				current activity. 
	 * @return
	 */
	@Basic
	public float getActivityTime() {
		return this.activityTime;
	}
	
	/**
	 * Set the time it will take for this Unit to complete his activity
	 * @param activityTime 
	 * 				The time it will takes for this Unit to complete his
	 * 				current activity. 
	 */
	private void setActivityTime(float activityTime) {
		this.activityTime = activityTime;
	}
	
	/**
	 * Update the orientation of the Unit according to the Unit's velocity.
	 */
	private void updateOrientation() {
		double xVelocity = this.getCurrentVelocity()[0];
		double yVelocity = this.getCurrentVelocity()[1];
		float orientation = (float) (Math.atan2(yVelocity, xVelocity));

		this.setOrientation(orientation);
	}

	/**
	 * Update the position of the Unit according to the Unit's velocity.
	 * @param unit
	 * @param time
	 */
	private void updatePosition(double time) {

		Vector distanceToMove = this.getCurrentVelocityVector().getMultipleVector(time);
		Vector newPosition = this.getVectorPosition().addVector(distanceToMove);
		this.setVectorPosition(newPosition, this.getWorld());
	}

	/**
	 * Return the base velocity of this Unit.
	 */
	@Basic
	@Raw
	public double getBaseVelocity() {
		return this.baseVelocity;
	}
	
	/**
	 * Update the base velocity of this Unit.
	 */
	@Basic
	@Raw
	public void updateBaseVelocity() {
		this.baseVelocity = 0.75 * (getStrength() + getAgility()) / (getWeight());
	}
	
	/**
	 * Let the Unit start sprinting.
	 */
	public void startSprint() {
		if ((this.currentStatus == Status.MOVING) && (this.stamina > 0) && (!this.getFalling())){
			this.sprint = 2;
		}
	}
	
	/**
	 * Let the Unit stop sprinting.
	 */
	public void stopSprint() {
		this.sprint = 1;
		this.sprintTime = 0;
	}
	
	/**
	 * Return whether this Unit is sprinting.
	 * @return
	 */
	public boolean isSprinting() {
		return this.sprint == 2;
	}
	
	/**
	 * Return the currentVelocity of this Unit as an array of coordinates.
	 */
	@Basic
	@Raw
	public double[] getCurrentVelocity() {
		return this.currentVelocity.getCoordinates();
	}
	
	/**
	 * Return the currentVelocity of this Unit as a Vector.
	 */
	@Basic
	@Raw
	public Vector getCurrentVelocityVector() {
		return this.currentVelocity;
	}

	/**
	 * Set the currentVelocity of this Unit using the given adjacentPosition.
	 * 
	 * @param adjacentPosition
	 *            The new adjacentPosition for this Unit.
	 * @post The currentVelocity of this new Unit is equal to 
	 * 			the vector between the current position of the Unit 
	 * 			and the given adjacentPosition multiplied with a factor. 
	 * 			This factor includes a multiplier if the Unit is moving upwards
	 * 			or downwards, another multiplier if the unit is sprinting 
	 * 			and the distance between the Unit's position and the adjacentPosition.
	 *       | new.getCurrentVelocity() == vectorCurrentAdjacent*factor;
	 * @throws IllegalArgumentException
	 *             The given adjacentPosition is not a valid adjacentPosition
	 *             for any Unit.
	 *             | !canHaveAsAdjacentPosition(adjacentPosition))
	 */
	@Raw
	// Sprinting is done in advanceTime -> updatePosition.
	public void setCurrentVelocity(double[] adjacentPosition) {
		if (this.unitIsFalling()){
			this.currentVelocity = new Vector(adjacentPosition);
		}
		else{
			Vector adjPosVector = new Vector(adjacentPosition);
			Vector subtractedVector = adjPosVector.subtractVector(this.getVectorPosition());
			double distance = subtractedVector.getMagnitude();

			double Tempcte = 1;
			if (subtractedVector.getZ() > 0)
				Tempcte = 0.5;
			else if (subtractedVector.getZ() < 0)
				Tempcte = 1.2;

			double factor = Tempcte*this.sprint/distance*this.getBaseVelocity();

			this.currentVelocity = subtractedVector.getMultipleVector(factor);
		}
	}
	
	/**
	 * Return whether the given position is a valid position for this Unit,
	 * 	within the given World.
	 * 
	 * @param position
	 * 			The position to check.
	 * @param world
	 * 			The World in which the position must be checked.
	 * @return True if and only if the Cube at the given position is within the boundaries of the given World
	 * 			, isn't a solid Cube and has at least one neighbouring solid Cube.
	 * 			| return == (this.world.isWithinWorld(x, y, z) && (!cube.isSolid())
	 */
	@Override
	public boolean canHaveAsPosition(Vector position, World world) {
		Cube cube = world.getCube(position.getRoundDown());
		return (super.canHaveAsPosition(position, world) && world.isNearToSolid(cube));
	}
	
	/**
	 * Check whether this Unit can have the given position as an adjacent position.
	 * 
	 * @param adjacentPosition
	 *            The position to check.
	 * @return False if the distance between all corresponding coordinates of the given position
	 * 				and the Unit's current position are greater than one.
	 * 		   True otherwise.
	 * 			| if (xValueGivenPosition - xValueCurrentPosition > 1) or 
	 * 			|  		(yValueGivenPosition - yValueCurrentPosition > 1) or
	 * 			|  		(zValueGivenPosition - zValueCurrentPosition > 1)
	 * 			|	result == false;
	 * 			| else result == true;
	 * @throws IllegalArgumentException
	 * 			| !isValidPosition(adjacentPosition, this.world)
	 */
	@Raw
	public boolean canHaveAsAdjacentPosition(Vector adjacentPosition) throws IllegalArgumentException{
		if (!canHaveAsPosition(adjacentPosition, this.getWorld())){
			throw new IllegalArgumentException();
		}
		int[] unitCube = (this.getCurrentCubeCoordinate());
		int[] adjCube = (adjacentPosition.getRoundDown());
		for (int i = 0; i < 3; i++) {
			if (Math.abs(adjCube[i] - unitCube[i]) > 1 ){
				return false; 
			}
		}
		return true;
	}

	/**
	 * Returns whether the Unit is moving to an adjacent cube.
	 * 
	 * @return |this.isMovingToAdjacent
	 */
	@Basic
	public boolean getIsMovingToAdjacent() {
		return this.isMovingToAdjacent;
	}

	/**
	 * Move this Unit to an adjacent cube.
	 * 
	 * @param dx
	 * 		The amount to move in the x-direction.
	 * @param dy
	 * 		The amount to move in the y-direction.
	 * @param dz
	 * 		The amount to move in the z-direction.
	 * @post The new position of the Unit is equal to the old position plus the given steps.
	 * 		| new.getVectorPosition() == old.getPosition.addVector(new Vector(dx, dy, dz))
	 * @throws IllegalArgumentException
	 * 			The target position is not an adjacent position
	 * 			|!this.canHaveAsAdjacentPosition(adjacentPosition)
	 * @throws IllegalPositionException
	 * 			The target position is not a legal position
	 * 			|!isValidPosition(adjacentPosition)
	 */
	public void moveToAdjacent(int dx, int dy, int dz) throws IllegalArgumentException, IllegalPositionException {
		Vector lengthVector = new Vector(dx,dy,dz);
		Vector adjacentPosition = getVectorPosition().addVector(lengthVector);
		int [] integerAdjacentPosition = adjacentPosition.getRoundDown();
		Cube cubeAdjacentPosition = this.getWorld().getCube(integerAdjacentPosition);
		if (!this.getIsMovingToAdjacent() 
				&& ((dx != 0) || (dy != 0) || (dz != 0))
				&& (!cubeAdjacentPosition.isSolid())
				) {
			
			if (!canHaveAsAdjacentPosition(adjacentPosition)) {
				throw new IllegalArgumentException();
			}
			Vector centreAdjacentCube = this.getWorld().getCube(integerAdjacentPosition).getCentreCube();
			this.setTargetAdjacent(centreAdjacentCube);
			this.setIsMovingToAdjacent(true);
			this.setCurrentVelocity(centreAdjacentCube.getCoordinates());
			if (this.unitIsFalling()){
				this.setCurrentVelocity(new double[]{0,0,-3});
				this.setNextStatus(Status.FALLING);
			}
			else
				this.setNextStatus(Status.MOVING);
				
		}
	}

	/**
	 * Set the variable isMovingToAdjacent to the given boolean.
	 * 
	 * @param bool
	 * 
	 */
	@Basic
	public void setIsMovingToAdjacent(boolean bool) {
		this.isMovingToAdjacent = bool;
	}

	public void moveTo(int[] targetPosition) throws IllegalArgumentException, UnreachablePositionException {
		Vector vectorPosition = new Vector(targetPosition);
		if (!canHaveAsPosition(vectorPosition, this.getWorld())) {
			throw new IllegalArgumentException();
		}
		this.setIsMovingToAdjacent(false);
		this.setTargetPosition(targetPosition);
		Cube targetCube = this.getWorld().getCube(targetPosition);
		if (!Arrays.equals(getCurrentCubeCoordinate(), targetPosition)){
			this.queueMap.put(targetCube.getStringPosition(), 0);
			this.queueKeys.add(targetCube.getStringPosition());
			String currentPosition = this.getCurrentCube().getStringPosition();
			while ((!this.queueMap.containsKey(currentPosition)) && (!this.queueKeys.isEmpty())) {
				String keyString = this.queueKeys.removeFirst();
				int n = this.queueMap.get(keyString);
				this.search(keyString, n);
			}
			if (this.queueMap.containsKey(currentPosition)) {
				ArrayList<Cube> neighbouringCubes = this.getWorld().getCube(this.getCurrentCubeCoordinate()).getNeighbouringCubes();
				int smallestNSoFar = -1;
				double smallestDetourSoFar = -1;
				Vector targetVector = new Vector(this.getTargetPosition());
				Vector targetDirection = targetVector.subtractVector(this.getCurrentCubePosition());
				ArrayList<Vector> directions = new ArrayList<>();
				for (Cube cube : neighbouringCubes) {
					String cubeKey = cube.getStringPosition();
					Vector currentDirection = cube.getPosition().subtractVector(this.getCurrentCubePosition());
					if (	(this.queueMap.containsKey(cube.getStringPosition()))
							&& ((this.queueMap.get(cubeKey) <= smallestNSoFar) || (smallestNSoFar == -1))
							&& ((targetDirection.subtractVector(currentDirection).getMagnitude() <= smallestDetourSoFar)
									|| (smallestDetourSoFar == -1))){
						smallestDetourSoFar = targetDirection.subtractVector(currentDirection).getMagnitude();
						smallestNSoFar = this.queueMap.get(cubeKey);
						directions.add(currentDirection);
					}
				}
				double smallestZDeviation = 1;
				Vector adjacentTarget = null;
				for (Vector direction : directions) {
					if (	(targetDirection.subtractVector(direction).getMagnitude() == smallestDetourSoFar)
							&& (direction.getZ() <= smallestZDeviation)) {
						smallestZDeviation = Math.abs(direction.getZ());
						adjacentTarget = direction;
					}
				}
				int x = (int) adjacentTarget.getX();
				int y = (int) adjacentTarget.getY();
				int z = (int) adjacentTarget.getZ();
				this.moveToAdjacent(x, y, z);
			}
			else {
				this.standStill();
				throw new UnreachablePositionException();
			}
		}
	}
	
	
	private void search(String position, int n) {
		ArrayList<Cube> neighbouringCubes = this.getWorld().getCube(position).getNeighbouringCubes();
		for (Cube cube : neighbouringCubes) {
			if ((this.canHaveAsPosition(cube.getPosition(), this.getWorld())) &&
				(!this.queueMap.containsKey(cube.getStringPosition()) || this.queueMap.get(cube.getStringPosition()) > n + 1)) {
				this.queueKeys.addLast(cube.getStringPosition());
				this.queueMap.put(cube.getStringPosition(), n+1);
			}
		}
	}
	
	private int[] getTargetPosition() {
		if (this.targetPosition == null){
			return null;
		}
		else {
		int x = (this.targetPosition[0]);
		int y = (this.targetPosition[1]);
		int z = (this.targetPosition[2]);
		int[] copy = new int[]{x,y,z};
		return copy;
		}
	}

	private void setTargetPosition(int[] targetPosition) {
		if (targetPosition == null){
			this.targetPosition = null;
		}
		else {
		int x = (targetPosition[0]);
		int y = (targetPosition[1]);
		int z = (targetPosition[2]);
		int[] copy = new int[]{x,y,z};
		this.targetPosition = copy;
		}

	}
	private Vector getTargetAdjacent() {
		return this.targetAdjacent.getCopy();
	}

	private void setTargetAdjacent(Vector targetAdjacent) {
		Vector copy = targetAdjacent.getCopy();
		this.targetAdjacent = copy;
	}

	/**
	 * Check whether the given status is a valid status for any Unit.
	 * 
	 * @param status
	 *            The status to check.
	 * @return | result == legalStatus.contains(status)
	 */
	public static boolean isValidStatus(String status) {
		if (legalStatus.contains(status))
			return true;
		return false;
	}
	
	/**
	 * Set the next status of this Unit to the given status.
	 * 
	 * @param status
	 *            The next status for this Unit.
	 */
	@Raw @Basic
	public void setNextStatus(Status status) {
		this.nextStatus = status;
	}
	
	/**
	 * Make this Unit stand still.
	 */
	public void standStill() {
		this.stopAction();
		this.currentStatus = Status.STANDING;
		this.setNextStatus(Status.STANDING);
	}
	
	/**
	 * Updates the status of this Unit.
	 */
	@Raw
	public void updateStatus(){
		this.stopAction();
		this.currentStatus = this.nextStatus;
	}
	/**
	 * Check if the status of this Unit is interrupted.
	 * 
	 * @return
	 * 		| result == ((this.nextStatus == "attacked") ||	(this.isStanding()) ||
			|			(this.isWorking()) ||
			|			((this.isMoving()) && (this.targetPosition != null)) ||
			|			((this.isResting()) && (this.initialRest == false))
	 */
	// if a Unit is about to fall this count as an interrupt.
	public boolean isInterrupted(){
		if (this.nextStatus==this.currentStatus){
			return false;
		}
		else if ((this.nextStatus == Status.ATTACKED) ||
				(this.isStanding()) ||
				(this.isWorking()) ||
				((this.isMoving()) && (this.targetPosition != null)) ||
				((this.isResting()) && (this.initialRest == false))	 ||
				(this.unitIsFalling())) {
			return true;
		}
		else {
			return false;
		}
	}
	
	private void setLegalStatus() {
		legalStatus.add("standing");
		legalStatus.add("resting");
		legalStatus.add("moving");
		legalStatus.add("attacking");
		legalStatus.add("working");
		legalStatus.add("attacked");
	}

	public boolean isWorking() {
		return this.currentStatus == Status.WORKING;
	}

	public boolean isAttacking() {
		return this.currentStatus == Status.ATTACKING;
	}

	public boolean isResting() {
		return this.currentStatus == Status.RESTING;
	}

	public boolean isMoving() {
		return this.currentStatus == Status.MOVING;
	}

	public boolean isStanding() {
		return this.currentStatus == Status.STANDING;
	}
	public boolean unitIsFalling() {
		return this.currentStatus == Status.FALLING;
	}
	
	/**
	 * Start working.
	 * 
	 * @post The status of this Unit is set to working, this Unit's orientation is set towards the given position
	 * 			and activityTime is set to the activity time needed for a work task 
	 * 		| new.getStatus() == WORKING
	 * 		| new.getActivityTime = (500 / this.getStrength())
	 */
	public void work() {
			this.setNextStatus(Status.WORKING);
			this.setActivityTime(500 / this.getStrength());
	}

	/**
	 * Start working on the given position.
	 * 
	 * @param x
	 * 			The x-coordinate of the given position.
	 * @param y
	 * 			The y-coordinate of the given position.
	 * @param z
	 * 			The z-coordinate of the given position.
	 * @throws IllegalArgumentException
	 * 			Throws an IllegalArgumentException if the position at x,y,z where the Unit 
	 * 			should work is not a reachable position.
	 * @post The status of this Unit is set to working, this Unit's orientation is set towards the given position
	 * 			and activityTime is set to the activity time needed for a work task 
	 *    			if the given position equals the current position of this Unit 
	 *    			or if the given position is a neighboring position of this Unit's current position.
	 * 		 	If not, throw and IllegalArgumentException
	 * 			|if (!neighboringPositions.contains(position) && !position.isEqualTo(this.getPosition()){
	 * 			|	then throw new IllegalArgumentException();
	 * 			|else 	
	 * 			| 	new.getStatus() == WORKING;
	 * 			|	new.getOrientation() == towardsPosition
	 * 			| 	new.getActivitytime() ==  500 / this.getStrength();
	 */
	public void workAt(int x, int y, int z) throws IllegalArgumentException{
		int[] workPosition = new int[]{x,y,z};
		Cube cubeWorkPosition = this.getWorld().getCube(workPosition);
		Vector centreTargetCube = cubeWorkPosition.getCentreCube();
		
		ArrayList<Cube> neighbouringCubes = this.getCurrentCube().getNeighbouringCubes();
		if (!neighbouringCubes.contains(cubeWorkPosition) && !cubeWorkPosition.isEqualTo(this.getCurrentCube())){
			throw new IllegalArgumentException();
		}
		else{
			this.targetWorkingCube = cubeWorkPosition;
			float newOrientation = centreTargetCube.subtractVector(this.getVectorPosition()).getAngle();
			this.setOrientation(newOrientation);
			this.setNextStatus(Status.WORKING);
			this.setActivityTime((float) ((double)500 / this.getStrength()));
		}
	}

	public void defend(Unit attackUnit) {
			double dodgeConstant = (0.2 * getAgility() / attackUnit.getAgility());
			double blockConstant = (0.25
					* ((getStrength() + getAgility()) / (attackUnit.getStrength() + attackUnit.getAgility())));
			if (dodgeConstant >= Math.random()) {
				// !!CHECK IF dodgePosition is passable terrain! 
				this.setRandomPosition();
				// Successful dodge, give defendUnit GIVE 20 EXP!
				this.setExperiencePoints(this.getExperiencePoints() + 20);
			}
			else if (blockConstant >= Math.random()) {
				// Successful block, give defendUnit 20 EXP!
				this.setExperiencePoints(this.getExperiencePoints() + 20);
			} 
			else{
				this.setHealth(this.getHealth() - attackUnit.getStrength() / 10);
				// Successful ATTACK, give !!attackUnit!! 20 EXP!
				attackUnit.setExperiencePoints(this.getExperiencePoints() + 20);
			}
	}

	/**
	 * 
	 * @param defendUnit
	 * @note The defender's orientation depends on the attacker's orientation.
	 */
	public void attack(Unit defendUnit) {
		if ((canHaveAsAdjacentPosition(defendUnit.getVectorPosition())) &&
				this.getFaction() != defendUnit.getFaction()) {
	
			this.setNextStatus(Status.ATTACKING);
			defendUnit.setAttacker(this);
			defendUnit.setNextStatus(Status.ATTACKED);
			this.setDefender(defendUnit);
			this.setActivityTime(1);
			double xValueDefender = defendUnit.getPosition()[0];
			double yValueDefender = defendUnit.getPosition()[1];
			double xValueAttacker = getPosition()[0];
			double yValueAttacker = getPosition()[1];
	
			float orientationAttacker = (float) (Math.atan2((yValueDefender - yValueAttacker),
					(xValueDefender - xValueAttacker)));
			this.setOrientation(orientationAttacker);
			defendUnit.setDefenderOrientation();
		}
	}

	private void setAttacker(Unit attackUnit) {
		this.attacker = attackUnit;
		
	}
	private Unit getAttacker(){
		if (this.attacker == null){
			return null;
		}
		else{
		return this.attacker;
		}
	}
	
	private void setDefender(Unit defendUnit) {
		this.defender = defendUnit;
		
	}
	@Raw
	private Unit getDefender(){
		if (this.defender == null){
			return null;
		}
		else{
		return this.defender;
		}
	}
	
	private boolean isValidFight() {
		Unit attacker = this.getAttacker();
		if (attacker == null) {
			return false;
		}
		Unit defender = attacker.getDefender();
		return (defender != null) && (defender == this);
	}
	
	private void setDefenderOrientation(){
		if (isValidFight()){
		this.setOrientation((float) (this.getAttacker().getOrientation() + (Math.PI)));
		}
	}

	private void setRandomPosition() {
		try {
			Vector dodgeDistance = new Vector((2 * Math.random() - 1),(2 * Math.random() - 1),0);
			Vector vectorDefenderPosition = this.getVectorPosition().addVector(dodgeDistance);
			this.setVectorPosition(vectorDefenderPosition, this.getWorld());
		} catch (IllegalPositionException exc) {
			this.setRandomPosition();
		}
	}

	public void rest() {
		if ((this.getHealth() < this.getMaxCondition()) || this.getStamina() < this.getMaxCondition()) {
			this.initialRest = true;
			this.setNextStatus(Status.RESTING);
		}
	}
	
	private void setDefaultBehavior() {
		defaultBehavior.add("moveToRandom");
		defaultBehavior.add("working");
//		defaultBehavior.add("attack");
		defaultBehavior.add("resting");
	}

	/**
	 * Return if the default behavior of this Unit is enabled.
	 */
	@Basic @Raw
	public boolean getDefaultBehavior() {
		return this.defaultBehaviourEnabled;
	}

	/**
	 * Set the defaultBehavior of this Unit to the given defaultBehavior.
	 * 
	 * @param  defaultBehavior
	 *         The new defaultBehavior for this Unit.
	 * @post   The defaultBehavior of this new Unit is equal to
	 *         the given defaultBehavior.
	 *       | new.getDefaultBehavior() == defaultBehavior
	 */
	@Raw
	public void setDefaultBehaviour(boolean defaultBehavior) {
		this.defaultBehaviourEnabled = defaultBehavior;
	}

	
	/**
	 * Select a random activity for the Unit to conduct.
	 * 
	 * @return A random activity selected from the list of defaultBehaviors.
	 * 			If this random activity is resting but his HP and Stamina are full
	 * 			select another random activity by reinvoking this method.
	 * 			If this random activity is attack but there is no unit to attack
	 * 			select another random activity by reinvoking this method.
	 * 			If this random activity is attack and there is another unit from a different faction
	 * 			attack the other unit.
	 * 			
	 * 			| randomIndex
	 * 			| randomActivity = defaultBehavior.get(randomIndex)
	 * 			| if (randomActivity == "resting" && (this.getHealth() == this.getMaxCondition()) &&
     *			|		(this.getStamina() == this.getMaxCondition()))
	 *			|	result == this.selectRandomActivity();
	 *			| 
	 * 			| if (randomActivity == "attack")
	 * 			| 	then create ArrayList of neighboring Units that belong to a different faction than
	 * 			|		the current Unit.
	 * 			|		if (neighboringUnits.size() == 0)
	 * 			|			then result == selectRandomActivity();
	 * 			|		if (neighboringUnits.size() > 0)
	 * 			|			then 
	 * 			| 				attack(neighboringUnits.get(randomUnit))
	 * 			|				result == randomActivity.
	 * 			| else return randomActivity.
	 */
	public void startDefaultBehaviour(){
		
		if (this.getTaskToDo() != null) {
			Statement nextActivity = this.getTaskToDo().getActivities().getNext(this);
			if (nextActivity != null){
				System.out.println("executing next activity");
				this.isBehavingDefault = true;
				nextActivity.execute(this);
			}
			else {
				this.getFaction().getScheduler().removeTask(this.getTaskToDo());
				this.setTaskToDo(null);
			}
		}
		
		// search highest priority task, assign this task to this unit and execute this task.
		if (this.getTaskToDo() == null) {
			Scheduler scheduler = this.getFaction().getScheduler();
			if (scheduler.returnHighestPriorityTask()!=null) {
				System.out.println("executing task");
				this.isBehavingDefault = true;
				scheduler.giveTask(this);
				this.getTaskToDo().execute();
			}
		}

//		else {
//			Random random = new Random();
//
//			ArrayList<String> possibleActivities = new ArrayList<>();
//			possibleActivities.add("working");
//			possibleActivities.add("moveToRandom");
//
//			if ((this.getHealth() != this.getMaxCondition()) || (this.getStamina() != this.getMaxCondition()))
//				possibleActivities.add("resting");
//			ArrayList<Cube> neighbouringCubes = this.getCurrentCube().getNeighbouringCubes();
//			Set<Unit> unitSet = this.getWorld().getActiveUnits();
//			ArrayList<Unit> neighbouringAttackableUnitList = new ArrayList<>();
//			Iterator<Unit> iter = unitSet.iterator(); 
//			while (iter.hasNext()) {
//				Unit unit = (Unit) iter.next();
//				Boolean isNeighbouringCube = unit.getCurrentCube().containsCube(neighbouringCubes);
//				if (isNeighbouringCube && (this.getFaction() != unit.getFaction()))
//					neighbouringAttackableUnitList.add(unit);
//			}
//			if (neighbouringAttackableUnitList.size()>0)
//				possibleActivities.add("attack");
//			int randomIndex = random.nextInt(possibleActivities.size());
//			String randomActivity = possibleActivities.get(randomIndex);
//
//			if ((randomActivity == "resting"))
//				this.rest();
//			else if ((randomActivity == "attack")){
//				int randomUnitIndex = random.nextInt(neighbouringAttackableUnitList.size());
//				this.attack(neighbouringAttackableUnitList.get(randomUnitIndex));
//			}
//			else if ((randomActivity == "working")){
//				ArrayList<Cube> solidNeighbouringCubes = new ArrayList<>();
//				for (Cube cube : neighbouringCubes) {
//					if (cube.isSolid())
//						solidNeighbouringCubes.add(cube);
//				}
//				int randomCube = random.nextInt(solidNeighbouringCubes.size());
//				Cube workCube = solidNeighbouringCubes.get(randomCube);
//				int xCoordinateWork = workCube.getCoordinates()[0];
//				int yCoordinateWork = workCube.getCoordinates()[1];
//				int zCoordinateWork = workCube.getCoordinates()[2];
//				this.workAt(xCoordinateWork,yCoordinateWork,zCoordinateWork);
//			}
//			else if ((randomActivity == "moveToRandom")){
//				int[] randomPosition = this.getRandomPosition();
//				try {
//					this.moveTo(randomPosition);
//				} catch (UnreachablePositionException exc) {
//					this.startDefaultBehaviour();
//				}
//			}
//		}
	}
	
	public void stopDefaultBehaviour() {
		this.setNextStatus(Status.STANDING);
		this.isBehavingDefault = false;
	}
	
	/**
	 * Returns a random position in this World where a Unit can stand.
	 * 
	 * @return
	 */
	private int[] getRandomPosition() {
		Random random = new Random();
		int randomXIndex = (random.nextInt(this.getWorld().getNbCubesX()));
		int randomYIndex = (random.nextInt(this.getWorld().getNbCubesY()));
		int randomZIndex = (random.nextInt(this.getWorld().getNbCubesZ()));
		int[] randomPosition = new int[]{randomXIndex,randomYIndex,randomZIndex};
		Vector position = new Vector(randomPosition);
		if (!canHaveAsPosition(position, this.getWorld()))
			return this.getRandomPosition();
		else
			return randomPosition;
	}
	
	// isNearToSolid also checks if the unit is standing on a solid cube so it doesn't have to be implemented in this if-statement.
	@Override
	protected boolean canFall() {
		if (!this.getWorld().isNearToSolid(this.getCurrentCube())){
			return true;
		}
		return false;
	}
	/**
	 * The Unit falls until it reaches solid ground via a special case in moveTo.
	 * @throws IllegalArgumentException
	 * @throws UnreachablePositionException
	 * 
	 * @post The Unit falls towards a cube at a lower Z level that is above a solid cube.
	 * 			|new.MoveTo(LowerZlevel)
	 */
	@Override
	public void fall(double time) throws IllegalArgumentException{
//	}, UnreachablePositionException{
//		if (this.unitIsFalling()) {
//			int targetZLevel = (int) this.getCurrentCubePosition().getZ();
//			int xCoordinate = (int) this.getCurrentCubePosition().getX();
//			int yCoordinate = (int) this.getCurrentCubePosition().getY();
//			int[] newCoordinates = new int[]{xCoordinate,yCoordinate,targetZLevel}; 
//			Cube cubeToFallTo = this.getWorld().getCube(newCoordinates);
//			double[] newVelocity = new double[]{newCoordinates[0],newCoordinates[1],newCoordinates[2] - 3};
//			while (!this.getWorld().isAboveSolidGround(cubeToFallTo) && targetZLevel != 0) {
//				targetZLevel -= 1;
//				newCoordinates = new int[]{xCoordinate,yCoordinate,targetZLevel}; 
//				cubeToFallTo = this.getWorld().getCube(newCoordinates);
//			}
//			this.setCurrentVelocity(newVelocity);
//
//			this.moveTo(new int[]{xCoordinate,yCoordinate,targetZLevel});
//		}
		this.stopAction();
		this.setNextStatus(Status.FALLING);
		Cube oldCube = this.getCurrentCube();
		super.fall(time);
		Cube newCube = this.getCurrentCube();
		if (!oldCube.isEqualTo(newCube)){
			this.setHealth(this.getHealth()- 10);;
		}
	}

	public boolean isAlive() {
		return this.getWorld().getActiveUnits().contains(this);
	}

	public Task getTaskToDo() {
		return taskToDo;
	}

	public void setTaskToDo(Task taskToDo) {
		this.taskToDo = taskToDo;
	}
	
	public void executeTask() throws IllegalStateException{
		if (this.getTaskToDo()==null)
			throw new IllegalStateException();
		this.getTaskToDo().execute();
	}
	
	// TODO Geen nested class van maken.
	public class NearestResource<T extends Resource>{
		
		public T getNearestResource(T t){
			T result = null;
			Set<T> resourceSet = (Set<T>) Unit.this.getWorld().getResourceOfType(t);
			Iterator<T> iter = resourceSet.iterator();
			double shortesDist = -1;
			while (iter.hasNext()) {
				T resource = (T) iter.next();
				double distanceToCurrent = resource.getCurrentCubePosition().
											subtractVector(Unit.this.getCurrentCubePosition()).getMagnitude();
				if (distanceToCurrent < shortesDist || shortesDist == -1){
					result = resource;
					shortesDist = distanceToCurrent;
				}
			}
			return result;
			
		}
		
	}
	
	//TODO GENERISCH
	public static class VariableMapper<T> {
		/**
		 * A map of all variables from a Task.
		 */
		private Map<String, Object> valueMap = new HashMap<>();
		
		public boolean contains(String variableName) {
			return this.valueMap.containsKey(variableName);
		}
		
		public Expression<T> get(String variableName){
			return (Expression<T>) valueMap.get(variableName);
			}
		
		public void put(String variableName, Expression<T> variable) {
			valueMap.put(variableName, variable);
		}
	}
	
//	public class Variable<T> {
//		
//		public void addVariable(String variableName, Expression<T> value) throws IllegalArgumentException{
////			Class<T> type = (Class<T>) value.execute(this).getClass();
////			if (Unit.this.typeMap.containsKey(variableName) 
////					&& (Unit.this.typeMap.get(variableName) != type))
////				throw new IllegalArgumentException();
////			Unit.this.valueMap.put(variableName, value);
////			Unit.this.typeMap.put(variableName, type);
//			VariableMapper<T>.put(variableName, value)
//		}
//		
//		public void assign(Expression<T> value2) {
//			this.value = value2;
//		}
//
//		public  Expression<Object> getVariable(String variableName) {
//			return Unit.this.valueMap.get(variableName);
//		}
//	}
}
