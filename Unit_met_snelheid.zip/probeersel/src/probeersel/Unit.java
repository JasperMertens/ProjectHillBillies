package probeersel;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;

import be.kuleuven.cs.som.annotate.*;

// Niet vergeten | goed te zetten
/**
 * 
 * @invar The position of each Unit must be a valid position for any Unit. |
 *        isValidPosition(getPosition())
 * @invar The position of each Unit must be a valid position for any Unit. |
 *        isValidPosition(getPosition())
 * @invar The name of each Unit must be a valid name for any Unit. |
 *        isValidName(getName())
 * @invar The health of each Unit must be a valid health for any Unit. |
 *        isValidHealth(getHealth())
 * @invar The stamina of each Unit must be a valid stamina for any Unit. |
 *        isValidStamina(getStamina())
 * @invar Each Unit can have its orientation as orientation . |
 *        canHaveAsOrientation(this.getOrientation())
 *
 *
 * 
 */

public class Unit {

	/**
	 * Variable registering the position of this Unit.
	 */
	private double[] position;

	/**
	 * A list containing all Units.
	 */
	private static ArrayList<Unit> Unitlist = new ArrayList<>();

	/**
	 * Constants marking the borders of the game world.
	 */
	private static final int MAX_X = 50;
	private static final int MIN_X = 0;
	private static final int MAX_Y = 50;
	private static final int MIN_Y = 0;
	private static final int MAX_Z = 50;
	private static final int MIN_Z = 0;

	/**
	 * Variable registering the health of this Unit.
	 */
	private int health;
	/**
	 * Variable registering the stamina of this Unit.
	 */
	private int stamina;
	/**
	 * Variable registering the name of this Unit.
	 */
	private String name;
	/**
	 * Variable that multiplies the walking speed.
	 */
	private int sprint = 1;
	private boolean stop_sprinting = false;
	/**
	 * Variable registering the velocity of this Unit.
	 */
	private double[] velocity;
	private int weight;
	private int strength;
	private int agility;
	private int toughness;

	/**
	 * Variable registering the orientation of this Unit.
	 */
	private float orientation = (float) (Math.PI / 2);;

	private int MAX_CONDITION = (int) (200 * (this.weight * this.toughness / 10000) + 1);
	private final int MAX_INIT_ATTR = 100;
	private final int MIN_INIT_ATTR = 25;
	private double BASE_VELOCITY;

	private String status = "default";

	/**
	 * Initialize this new Unit with given position.
	 *
	 * @param position
	 *            The position for this new Unit.
	 * @effect The position of this new Unit is set to the given position. |
	 *         this.setPosition(position)
	 * 
	 *         Initialize this new Unit with given health.
	 * 
	 * @param health
	 *            The health for this new Unit.
	 * @pre The given health must be a valid health for any Unit. |
	 *      isValidHealth(health)
	 * @post The health of this new Unit is equal to the given health. |
	 *       new.getHealth() == health
	 *
	 *
	 *       Initialize this new Unit with given stamina.
	 * 
	 * @param stamina
	 *            The stamina for this new Unit.
	 * @pre The given stamina must be a valid stamina for any Unit. |
	 *      isValidStamina(stamina)
	 * @post The stamina of this new Unit is equal to the given stamina. |
	 *       new.getStamina() == stamina Initialize this new Unit with given
	 *       name.
	 *
	 * @param name
	 *            The name for this new Unit.
	 * @effect The name of this new Unit is set to the given name. |
	 *         this.setName(name)
	 * 
	 *         Adds this Unit to a list of all Units.
	 * 
	 */
	// @Raw?
	public Unit(String name, int weight, int strength, int agility, int toughness, double[] position)
			throws IllegalArgumentException {
		setPosition(position);
		setWeight(ConstrainAttribute(weight));
		setStrength(ConstrainAttribute(strength));
		setAgility(ConstrainAttribute(agility));
		setToughness(ConstrainAttribute(toughness));
		Unitlist.add(this);
		SetBaseVelocity(strength,agility,weight);
	}

	/**
	 * Removes a Unit from the list of all Units.
	 */
	void kill() {
		Unitlist.remove(this);
	}

	/**
	 * Return the position of this Unit.
	 */
	@Basic
	@Raw
	public double[] getPositionUnit() {
		return Arrays.copyOf(position, position.length);
	}

	/**
	 * Check whether the given position is a valid position for any Unit.
	 * 
	 * @param position
	 *            The position to check.
	 * @return | result == (Array.getDouble(position, 0) < MAX_X) &&
	 *         (Array.getDouble(position, 1) < MAX_Y) &&
	 *         (Array.getDouble(position, 2) < MAX_Z) &&
	 *         (Array.getDouble(position, 0) >= MIN_X) &&
	 *         (Array.getDouble(position, 1) >= MIN_Y) &&
	 *         (Array.getDouble(position, 2) >= MIN_Z)
	 */
	public static boolean isValidPosition(double[] position) {
		if ((Array.getDouble(position, 0) < MAX_X) && (Array.getDouble(position, 1) < MAX_Y)
				&& (Array.getDouble(position, 2) < MAX_Z) && (Array.getDouble(position, 0) >= MIN_X)
				&& (Array.getDouble(position, 1) >= MIN_Y) && (Array.getDouble(position, 2) >= MIN_Z))
			return true;
		else
			return false;
	}

	/**
	 * Set the position of this Unit to the given position.
	 * 
	 * @param position
	 *            The new position for this Unit.
	 * @post The position of this new Unit is equal to the given position. |
	 *       new.getPosition() == position
	 * @throws Illegal
	 *             The given position is not a valid position for any Unit. | !
	 *             isValidPosition(getPosition())
	 */
	@Raw
	public void setPosition(double[] position) throws IllegalArgumentException {
		if (!isValidPosition(position))
			throw new IllegalArgumentException();
		this.position = Arrays.copyOf(position, position.length);
	}

	/**
	 * Return the position of the cube in which the Unit rests.
	 * 
	 * @return
	 */
	@Basic
	// Raw ook?
	public int[] getPositionCube() {
		int[] roundedPosition = new int[3];
		for (int i = 0; i < position.length; i++) {
			roundedPosition[i] = (int) (getPositionUnit()[i]);
		}
		return roundedPosition;
	}

	/**
	 * Return the weight of this Unit.
	 */
	@Basic
	public int getWeight() {
		return this.weight;
	}

	// @effect gebruiken?
	/**
	 * Set the weight of this Unit to the given weight.
	 * 
	 * @param weight
	 *            The new weight for this Unit.
	 *
	 * @post If the given weight is a valid weight, the weight of this Unit is
	 *       equal to the given weight. | if (isValidWeight(weight)) | then
	 *       new.getWeight() == weight
	 * @post If the given weight is not a valid weight, the weight of this Unit
	 *       is set to the mean value of the strength and agility of this Unit.
	 *       | if (! isValidWeight(weight)) | then new.getWeight() ==
	 *       (this.strength + this.agility)/2
	 */
	@Basic
	public void setWeight(int weight) {
		if (!isValidWeight(weight))
			this.weight = (this.strength + this.agility) / 2;
		else
			this.weight = weight;
	}

	/**
	 * Return the given attribute, constrained to the legal initial values.
	 * 
	 * @param attribute
	 *            The new attribute for a Unit.
	 * @post If the given attribute exceeds the maximal initial value, the
	 *       attribute is set to the maximal initial value. |
	 *       if(attribute>MAX_INITIAL) | then return MAX_INITIAL ........
	 * @return
	 */
	// WAT ALS null?
	// Reden niet static: Hero.
	public int ConstrainAttribute(int attribute) {
		if (attribute < this.getMinInitAttr())
			return this.getMinInitAttr();
		if (attribute > this.getMaxInitAttr())
			return this.getMaxInitAttr();
		else
			return attribute;
	}

	public int getMinInitAttr() {
		return this.MIN_INIT_ATTR;
	}

	public int getMaxInitAttr() {
		return this.MAX_INIT_ATTR;
	}

	/**
	 * 
	 * @param weight
	 * @return
	 */
	private boolean isValidWeight(int weight) {
		if (weight >= (this.strength + this.agility) / 2)
			return true;
		else
			return false;
	}

	@Basic
	public int getStrength() {
		return this.strength;

	}

	@Basic
	public void setStrength(int strength) {
		this.strength = ConstrainAttribute(strength);
	}

	@Basic
	public int getAgility() {
		return this.agility;

	}

	@Basic
	public void setAgility(int agility) {

		this.agility = ConstrainAttribute(agility);
	}

	@Basic
	public int getToughness() {
		return this.toughness;
	}

	@Basic
	public void setToughness(int toughness) {

		this.toughness = ConstrainAttribute(toughness);
	}

	// NOMINAAL
	@Basic
	public int getMaxCondition() {
		return this.MAX_CONDITION;
	}

	/**
	 * Return the name of this Unit.
	 */
	@Basic
	@Raw
	public String getName() {
		return this.name;
	}

	/**
	 * Check whether the given name is a valid name for any Unit.
	 * 
	 * @param name
	 *            The name to check.
	 * @return | result ==
	 */
	public static boolean isValidName(String name) {
		if (Character.isUpperCase(name.charAt(0)) && (name.length() >= 2)) {

			for (int i = 0; i < name.length(); i++) {
				if ((!Character.isLetter(name.charAt(i))) && (!Character.isSpaceChar(name.charAt(i)))
						&& (name.charAt(i) != '\''))
					return false;
			}

			return true;
		}
		return false;

	}

	/**
	 * Set the name of this Unit to the given name.
	 * 
	 * @param name
	 *            The new name for this Unit.
	 * @post The name of this new Unit is equal to the given name. |
	 *       new.getName() == name
	 * @throws IllegalNameException
	 *             The given name is not a valid name for any Unit. | !
	 *             isValidName(getName())
	 */
	@Raw
	public void setName(String name) throws IllegalNameException {
		if (!isValidName(name))
			throw new IllegalNameException(name);
		this.name = name;
	}

	/**
	 * Return the health of this Unit.
	 */
	@Basic
	@Raw
	public int getHealth() {
		return this.health;
	}

	/**
	 * Check whether the given condition is a valid condition for any Unit.
	 * 
	 * @param condition
	 *            The condition to check.
	 * @return ..............
	 */
	@Basic
	public boolean isValidCondition(int condition) {
		if ((condition >= 0) && (condition <= this.getMaxCondition()))
			return true;
		else
			return false;
	}

	/**
	 * Set the health of this Unit to the given health.
	 * 
	 * @param health
	 *            The new health for this Unit.
	 * @pre The given health must be a valid health for any Unit. |
	 *      isValidHealth(health)
	 * @post The health of this Unit is equal to the given health. |
	 *       new.getHealth() == health
	 */
	@Basic
	@Raw
	public void setHealth(int health) {
		assert isValidCondition(health);
		this.health = health;
	}

	/**
	 * Return the stamina of this Unit.
	 */
	@Basic
	@Raw
	public int getStamina() {
		return this.stamina;
	}

	/**
	 * Set the stamina of this Unit to the given stamina.
	 * 
	 * @param stamina
	 *            The new stamina for this Unit.
	 * @pre The given stamina must be a valid stamina for any Unit. |
	 *      isValidStamina(stamina)
	 * @post The stamina of this Unit is equal to the given stamina. |
	 *       new.getStamina() == stamina
	 */
	@Raw
	public void setStamina(int stamina) {
		assert isValidCondition(stamina);
		this.stamina = stamina;
	}

	/**
	 * @invar The orientation of each Unit must be a valid orientation for any
	 *        Unit. | isValidOrientation(getOrientation())
	 */

	/**
	 * Return the orientation of this Unit.
	 */
	@Basic
	@Raw
	public float getOrientation() {
		return this.orientation;
	}

	/**
	 * Check whether the given orientation is a valid orientation for any Unit.
	 * 
	 * @param orientation
	 *            The orientation to check.
	 * @return | result ==
	 */
	public static boolean isValidOrientation(float orientation) {
		if (orientation <= 2 * Math.PI)
			return true;
		else
			return false;
	}

	/**
	 * Set the orientation of this Unit to the given orientation.
	 * 
	 * @param orientation
	 *            The new orientation for this Unit.
	 * @post If the given orientation is a valid orientation for any Unit, the
	 *       orientation of this new Unit is equal to the given orientation. |
	 *       if (isValidOrientation(orientation)) | then new.getOrientation() ==
	 *       orientation
	 */
	@Raw
	public void setOrientation(float orientation) {
		if (isValidOrientation(orientation))
			this.orientation = orientation;
		else
			this.orientation = (float) (orientation % (2 * Math.PI));
	}

	private static void advanceTime(double time) {
		//// for (int i = list.size() - 1; i >= 0; i--)
		// { update_Position(time);
		// update_Status(time);
	}


	
	 /**
	 * Check whether the given velocity is a valid base velocity for any Unit.
	 *
	 * @param velocity
	 * The velocity to check.
	 * @return | result ==
	 */
	 public static boolean isValidBaseVelocity(double velocity) {
	 if (velocity >=0)
		 return true;
	 return false;
	 }

	 /**
	 * Return the base velocity of this Unit.
	 */
	 @Basic
	 @Raw
	 public double getBaseVelocity() {
		 return this.BASE_VELOCITY;
	 }
	// DOCUMENTATIE AANPASSEN
	 /**
	 * Set the base velocity of this Unit to the given velocity.
	 *
	 * @param velocity
	 * The new velocity for this Unit.
	 * @post The base velocity of this new Unit is equal to the given
	 velocity. |
	 * new.getVelocity() == velocity
	 * @throws IllegalArgumentException
	 * The given velocity is not a valid velocity for any Unit. | !
	 * isValidVelocity(getVelocity())
	 */
	 @Raw
	 public void setBaseVelocity() throws
	 IllegalArgumentException {
		 double tempVelocity = 1.5*(getStrength()+getAgility())/(2*getWeight());
	 if (!isValidBaseVelocity(tempVelocity)) 
		 throw new IllegalArgumentException();
	 else
		 this.BASE_VELOCITY = tempVelocity;
	 }

	public void startSprint() {
		this.stop_sprinting = false;
		while ((this.status == "moving") && (this.stamina > 0) && (!this.stop_sprinting)) {
			this.sprint = 2;
			this.stamina -= 1;
			advanceTime(0.1);
		}
		stopSprint();

	}

	public void stopSprint() {
		this.sprint = 1;
		this.stop_sprinting = true;
	}

	/**
	 * Return the velocity of this Unit.
	 */
	@Basic
	@Raw
	public double[] getVelocity(double[] targetPosition) {
		
		double TempDistance = Math.sqrt(Math.pow((targetPosition[0]- getPositionUnit()[0]), 2) 
				+ Math.pow((targetPosition[1]- getPositionUnit()[1]), 2)
				+ Math.pow((targetPosition[2]- getPositionUnit()[2]), 2));
		
		double Tempcte;
		if (this.getPositionUnit()[2] - targetPosition[2] == -1)
			Tempcte = 0.5;
		else if (this.getPositionUnit()[2] - targetPosition[2] == 1)
			Tempcte = 1.2;
		else
			Tempcte = 1;
		return new double[]{( (Tempcte/TempDistance) * this.sprint*(targetPosition[0]-getPositionUnit()[0]))};
	}

}